import { spawn, type ChildProcess } from 'node:child_process'
import path from 'node:path'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The backend that resolves the registry-of-pointers manifest and serves
// /content and /api. In dev we spawn it as a child of Vite so a single
// `npm run dev` (with any `--port`/`--strictPort` flags) still works, and
// proxy the content/api routes to it.
const API_PORT = Number(process.env.API_PORT || process.env.VITE_API_PORT || 8787)

function backendPlugin() {
  let child: ChildProcess | null = null

  function startBackend() {
    child = spawn('node', ['server/index.js'], {
      stdio: 'inherit',
      env: { ...process.env, PORT: String(API_PORT) },
    })
    child.once('exit', (code) => {
      // Don't restart if it exited cleanly (e.g. killed intentionally).
      if (code !== 0 && code !== null) {
        console.error(`[insights-hub] backend exited with code ${code}`)
      }
    })
  }

  return {
    name: 'insights-hub-backend',
    apply: 'serve' as const,
    configureServer(server: { watcher: { add: (p: string) => void; on: (e: string, cb: (f: string) => void) => void } }) {
      startBackend()

      // Watch server/ so any change to backend files restarts the process,
      // exactly like nodemon would. Vite's watcher is chokidar under the hood.
      const serverDir = path.resolve('server')
      server.watcher.add(serverDir)
      server.watcher.on('change', (file) => {
        if (!file.startsWith(serverDir)) return
        console.log(`[insights-hub] ${path.relative(serverDir, file)} changed — restarting backend`)
        child?.kill()
        startBackend()
      })

      const stop = () => { child?.kill(); child = null }
      process.once('exit', stop)
      process.once('SIGINT', () => { stop(); process.exit(0) })
      process.once('SIGTERM', stop)
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), backendPlugin()],
  server: {
    proxy: {
      '/content': `http://localhost:${API_PORT}`,
      '/api': `http://localhost:${API_PORT}`,
    },
  },
})
