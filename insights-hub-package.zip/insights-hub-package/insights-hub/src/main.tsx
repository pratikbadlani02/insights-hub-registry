import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import "github-markdown-css/github-markdown.css";
import "./styles/theme.css";
import "./styles/global.css";
import "./styles/markdown.css";
import App from "./App";
import { ThemeProvider } from "./hooks/useTheme";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider>
      <BrowserRouter basename={import.meta.env.BASE_URL.replace(/\/$/, "") || "/"}>
        <App />
      </BrowserRouter>
    </ThemeProvider>
  </StrictMode>,
);
