/**
 * Manifest schema (schemaVersion 1) — the contract between the
 * insights-hub-generator skill and this viewer.
 *
 * Location at runtime: `${BASE_URL}content/manifest.json`.
 */

export const KNOWN_STACKS = ["java-spring", "react"] as const;
export type KnownStack = (typeof KNOWN_STACKS)[number];

export const KNOWN_ARCHETYPES = [
  "rest-api",
  "kafka-consumer",
  "batch",
  "gateway",
  "react-spa",
  "react-mfe",
] as const;
export type KnownArchetype = (typeof KNOWN_ARCHETYPES)[number];

export interface ServiceSource {
  /** "github" for registry-of-pointers entries; "local"/"git" for older seeds. */
  type: "local" | "git" | "github";
  /** Local path (local/git) or the docs subpath within the repo (github). */
  path: string;
  repoUrl: string | null;
  /** github pointers only: where the markdown physically lives. */
  owner?: string;
  repo?: string;
  ref?: string;
}

export interface ServiceEntry {
  /** URL-safe kebab-case slug; equals the folder name under content/services/. */
  id: string;
  /** Human display name. */
  name: string;
  /** "java-spring" | "react" — unknown values tolerated (neutral badge). */
  stack: string;
  /** Known archetypes above — unknown values tolerated (fallback badge). */
  archetype: string;
  /** "spring-analysis" | "react-analysis". */
  skill: string;
  /** ISO-8601 UTC timestamp. */
  analyzedAt: string;
  /** File stems (no .md) actually present on disk, in order. Never a fixed set. */
  pages: string[];
  /** Free-form, hub-curated labels (e.g. team, domain) — never derived from analysis. */
  tags: string[];
  /**
   * "local" = generated straight into public/content/ (e.g. by the generator
   * skill run without the app's API) — not in the shared registry, so the
   * Edit/Delete API 404s until it's synced in. "registry" = manageable
   * normally. Absent on statically-hosted deployments with no backend.
   */
  origin?: "local" | "registry";
  source: ServiceSource | null;
}

export interface Manifest {
  schemaVersion: number;
  generatedAt: string;
  generator: string;
  services: ServiceEntry[];
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

/** Tags are decoration, not identity — malformed input degrades to [] rather than failing the entry. */
function parseTags(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v.filter(isNonEmptyString).map((t) => t.trim());
}

/**
 * Hand-rolled validation: returns null when the document as a whole is
 * unusable; individually invalid services are skipped with a console.warn.
 * Unknown stack/archetype values pass through (badges fall back to neutral).
 */
export function validateManifest(raw: unknown): Manifest | null {
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return null;
  const m = raw as Record<string, unknown>;
  if (m["schemaVersion"] !== 1 || !Array.isArray(m["services"])) return null;

  const services: ServiceEntry[] = [];
  for (const candidate of m["services"] as unknown[]) {
    const e = (typeof candidate === "object" && candidate !== null ? candidate : {}) as Record<string, unknown>;
    const valid =
      isNonEmptyString(e["id"]) &&
      isNonEmptyString(e["name"]) &&
      isNonEmptyString(e["stack"]) &&
      isNonEmptyString(e["archetype"]) &&
      isNonEmptyString(e["skill"]) &&
      isNonEmptyString(e["analyzedAt"]) &&
      Array.isArray(e["pages"]) &&
      (e["pages"] as unknown[]).length > 0 &&
      (e["pages"] as unknown[]).every(isNonEmptyString);
    if (!valid) {
      console.warn("[insights-hub] Skipping invalid service entry in manifest:", candidate);
      continue;
    }
    const src = e["source"];
    services.push({
      id: e["id"] as string,
      name: e["name"] as string,
      stack: e["stack"] as string,
      archetype: e["archetype"] as string,
      skill: e["skill"] as string,
      analyzedAt: e["analyzedAt"] as string,
      pages: e["pages"] as string[],
      tags: parseTags(e["tags"]),
      origin: e["origin"] === "local" || e["origin"] === "registry" ? e["origin"] : undefined,
      source: typeof src === "object" && src !== null ? (src as ServiceSource) : null,
    });
  }

  return {
    schemaVersion: 1,
    generatedAt: isNonEmptyString(m["generatedAt"]) ? m["generatedAt"] : "",
    generator: isNonEmptyString(m["generator"]) ? m["generator"] : "",
    services,
  };
}
