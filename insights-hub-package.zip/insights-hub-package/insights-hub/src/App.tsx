import { Navigate, Route, Routes, useParams } from "react-router-dom";
import { AppShell } from "./components/layout/AppShell";
import { CatalogPage } from "./components/catalog/CatalogPage";
import { HelpPage } from "./components/help/HelpPage";
import { SettingsPage } from "./components/settings/SettingsPage";
import { ServiceLayout } from "./components/service/ServiceLayout";
import { ErrorState } from "./components/common/ErrorState";
import { LoadingSkeleton } from "./components/common/LoadingSkeleton";
import { NotFoundPage } from "./components/common/NotFoundPage";
import { useManifest } from "./hooks/useManifest";
import { defaultPage } from "./lib/pages";

/** /services/:serviceId → redirect to the service's default page. */
function ServiceIndexRedirect() {
  const { serviceId = "" } = useParams();
  const { data, error, loading, retry } = useManifest();

  if (loading) return <LoadingSkeleton variant="doc" />;
  if (error !== null || data === null) {
    return (
      <ErrorState
        title="Catalog unavailable"
        message="No manifest found at content/manifest.json — run the insights-hub-generator skill to publish services"
        detail={error?.message}
        onRetry={retry}
      />
    );
  }

  const entry = data.services.find((s) => s.id === serviceId);
  if (entry === undefined) {
    return (
      <NotFoundPage
        title="Service not found"
        message={`No service with id "${serviceId}" is published in the catalog.`}
      />
    );
  }

  return <Navigate to={`/services/${entry.id}/${defaultPage(entry).slug}`} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<CatalogPage />} />
        <Route path="/help" element={<HelpPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/services/:serviceId" element={<ServiceIndexRedirect />} />
        <Route path="/services/:serviceId/:pageSlug" element={<ServiceLayout />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
