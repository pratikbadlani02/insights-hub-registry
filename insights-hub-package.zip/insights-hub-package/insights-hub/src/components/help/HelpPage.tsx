import { useEffect } from "react";
import { MarkdownView } from "../markdown/MarkdownView";
import { useServerConfig } from "../../hooks/useServerConfig";
import { uploadsAvailable } from "../../lib/api";

const GUIDE = `# Insights Hub — User Guide

Insights Hub is a shared catalog of reverse-engineered service documentation.
Each project has a set of pages (architecture, entry points, data model, and
more) generated from its source code. This guide covers how to browse projects
and how to add your own — no redeploy required.

## Browsing

- The **home page** is the catalog. Every documented project appears as a card
  with its stack (Java/Spring, React), archetype (REST API, gateway, SPA, …),
  and any **tags** it's been given.
- **Search** by name, id, or tag, and filter with the **stack**, **archetype**,
  and **tags** chips. Selecting more than one tag narrows to projects that
  have *all* of them.
- Click a card to open the project. Use the **left sidebar** to move between
  pages; diagrams, tables, and code are rendered inline.
- Toggle **light/dark** with the switch in the top bar.

## Seeing only your team's services

There's no separate "favorites" list — use **tags** instead. Tag your team's
projects (e.g. \`team-checkout\`) via the **Edit** dialog, then select that tag
in the **Tags** filter chips above the catalog grid.

Your tag selection is remembered per browser and restored the next time you
open the hub, so once you've picked your team's tag it stays selected across
visits — click the chip again to deselect it and see everything.

## Editing or removing a project

If the hub backend is configured, the sidebar on a project's page shows
**Edit** and **Delete** buttons next to its badges.

- **Edit** updates the display name, stack, archetype, skill, and **tags**
  shown in the catalog. Tags are free-form and comma-separated (e.g.
  \`team-a, billing, tier-1\`) — they're hub-curated labels, not derived from
  the source code, so they're never overwritten by re-analyzing a project.
  Editing never touches the id or the published pages.
- **Delete** unregisters the project from the catalog. If its pages were
  committed into the registry repo (uploaded files, or a GitHub pointer whose
  headers had to be auto-injected), those files are deleted too. If it's a
  GitHub pointer to an already-valid doc set that the hub only reads in
  place, only the catalog entry is removed — your source repo is never
  touched.

Both act on the shared registry immediately, so changes are visible to
**everyone**, not just you.

### Locally-generated projects

Running the **insights-hub-generator** skill directly against a workspace
writes pages straight into this app's \`public/content/\` folder on your
machine — it doesn't call the shared registry. Those projects still show up
in the catalog, but **Edit** and **Delete** don't work on them yet (you'll
see a "generated locally" note and a **Sync to registry** button instead).
Syncing commits the project's pages into the registry repo and removes the
local copy — after that it behaves like any other project, and everyone
else sees it too.

## Adding a project

If the hub backend is configured, the catalog shows a **"+ Add project"** button.
Adding a project publishes it to the shared registry and makes it visible to
**everyone immediately** — nothing is rebuilt or redeployed.

There are two ways to add one.

### Option 1 — From GitHub (recommended)

Use this when your project's documentation already lives in a GitHub repo (for
example, produced by the analysis skills into a \`docs/\` folder).

1. Click **+ Add project → From GitHub**.
2. Enter the **repo URL** (e.g. \`https://github.com/your-org/your-service\`).
3. Enter the **docs path** in that repo (e.g. \`docs/backend-analysis\`).
4. Optionally set the **branch/ref** — defaults to the repo's default branch.
5. Click **Publish to hub**.

If every page already has the header block described below, the hub reads the
markdown **in place** — it does not copy your files, and always shows the
latest committed version. If any page is missing the header (e.g. raw
\`react-frontend-analysis\` output, which has none by design), the hub injects
it into a **copy** and commits that copy to the shared registry repo instead —
it never writes back into your source repo. In that case you must also supply
a **Display name** under "Metadata" below, since there's no existing header to
read a project id from.

### Option 2 — Upload files

Use this when you just have the generated \`.md\` files on your machine.

1. Click **+ Add project → Upload files**.
2. Select the doc-set markdown files.
3. Click **Publish to hub**.

The files are committed into the shared registry repo and published to the hub.

### What makes a valid doc set

Each markdown page must open with the standard **header block** — a title line
followed by a metadata quote block:

\`\`\`markdown
# Overview

> Project: my-service
> Type: rest-api
> Skill: spring-analysis
> Analyzed: 2026-07-20T00:00:00Z
> Tags: team-a, tier-1

---
\`\`\`

The hub reads this block to fill in the project's **name, stack, archetype,
analyzed date, and tags** automatically (the \`Tags:\` line is optional). You
can override any of these under **"Metadata"** in the Add-project dialog.
Pages are ordered by their filename number (\`00-overview.md\`,
\`01-architecture.md\`, …).

> Tip: the **insights-hub-generator** skill produces doc sets in exactly this
> format. Point Option 1 at the repo/folder it wrote to, or upload those files
> with Option 2.

## Troubleshooting

| Symptom | Likely cause & fix |
|---|---|
| No **"+ Add project"** button | The backend isn't configured with a registry repo and GitHub token. Ask your hub admin. |
| *"Could not inject a valid header block into: …"* | The hub tried to add the header automatically and still failed. Add the header block to those pages yourself (see above) and retry. |
| *"Could not determine a project id — …"* | None of the pages have an existing header to read a project id from, and no **Display name** was supplied. Expand "Metadata" and fill in **Display name**. |
| *"No markdown files found at …"* | The repo/path/branch is wrong, or the token can't read that repo. Check the docs path and the token's read access. |
| *"Registry repo not configured"* | The server is missing \`REGISTRY_OWNER\`/\`REGISTRY_REPO\` or \`GITHUB_TOKEN\`. |
| New project doesn't appear | Give it a moment and refresh — the catalog caches the manifest briefly. |

## For hub administrators

The backend needs a common **registry repo** on github.com and a **GitHub token**
with write access to it (and read access to any repo you point projects at).
Configure these in \`.env\` (see \`.env.example\`) and run \`npm start\`. Full details
are in the project \`README.md\` and \`SETUP.md\`.
`;

export function HelpPage() {
  const serverConfig = useServerConfig();

  useEffect(() => {
    document.title = "Help — Insights Hub";
  }, []);

  const body = uploadsAvailable(serverConfig)
    ? GUIDE
    : GUIDE.replace(
        "If the hub backend is configured, the catalog shows a **\"+ Add project\"** button.",
        "> **Uploads are not enabled on this hub** — the steps below apply once an admin configures the backend (see the last section).\n\nWhen enabled, the catalog shows a **\"+ Add project\"** button.",
      );

  return (
    <div className="catalog">
      <MarkdownView body={body} />
    </div>
  );
}
