import { useState } from "react";
import type { ServiceEntry } from "../../types/manifest";
import { updateProject } from "../../lib/api";
import { parseTagsInput } from "../../lib/tags";

interface Props {
  entry: ServiceEntry;
  onClose: () => void;
  onSaved: (entry: ServiceEntry) => void;
}

export function EditProjectDialog({ entry, onClose, onSaved }: Props) {
  const [name, setName] = useState(entry.name);
  const [stack, setStack] = useState(entry.stack);
  const [archetype, setArchetype] = useState(entry.archetype);
  const [skill, setSkill] = useState(entry.skill);
  const [tagsInput, setTagsInput] = useState(entry.tags.join(", "));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError("Display name is required.");
      return;
    }
    setBusy(true);
    try {
      const updated = await updateProject(entry.id, {
        name: name.trim(),
        stack: stack.trim(),
        archetype: archetype.trim(),
        skill: skill.trim(),
        tags: parseTagsInput(tagsInput),
      });
      onSaved(updated);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  return (
    <div className="dialog-overlay" role="dialog" aria-modal="true" aria-label="Edit project" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <div className="dialog-header">
          <h2>Edit project</h2>
          <button type="button" className="dialog-close" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>

        <form className="dialog-body" onSubmit={submit}>
          <p className="dialog-hint">
            Updates the catalog metadata for <strong>{entry.id}</strong>. The id and its published
            pages are unaffected.
          </p>
          <label className="field">
            <span>Display name</span>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </label>
          <label className="field">
            <span>Stack</span>
            <input type="text" placeholder="java-spring | react" value={stack} onChange={(e) => setStack(e.target.value)} />
          </label>
          <label className="field">
            <span>Archetype</span>
            <input
              type="text"
              placeholder="rest-api | react-spa | …"
              value={archetype}
              onChange={(e) => setArchetype(e.target.value)}
            />
          </label>
          <label className="field">
            <span>Skill</span>
            <input
              type="text"
              placeholder="spring-analysis | react-analysis"
              value={skill}
              onChange={(e) => setSkill(e.target.value)}
            />
          </label>
          <label className="field">
            <span>Tags (comma-separated)</span>
            <input
              type="text"
              placeholder="team-a, billing, tier-1"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
            />
          </label>

          {error && <p className="dialog-error">{error}</p>}

          <div className="dialog-actions">
            <button type="button" className="button" onClick={onClose} disabled={busy}>
              Cancel
            </button>
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? "Saving…" : "Save changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
