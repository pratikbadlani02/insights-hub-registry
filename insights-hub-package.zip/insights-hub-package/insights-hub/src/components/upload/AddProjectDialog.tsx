import { useState } from "react";
import { Link } from "react-router-dom";
import { addProject, type AddProjectPayload } from "../../lib/api";
import { parseTagsInput } from "../../lib/tags";

type Mode = "pointer" | "files";

interface Props {
  onClose: () => void;
  onAdded: (id: string) => void;
}

async function readFiles(fileList: FileList): Promise<{ name: string; content: string }[]> {
  const md = Array.from(fileList).filter((f) => f.name.toLowerCase().endsWith(".md"));
  return Promise.all(md.map(async (f) => ({ name: f.name, content: await f.text() })));
}

export function AddProjectDialog({ onClose, onAdded }: Props) {
  const [mode, setMode] = useState<Mode>("pointer");
  const [repoUrl, setRepoUrl] = useState("");
  const [pathInput, setPathInput] = useState("");
  const [ref, setRef] = useState("");
  const [files, setFiles] = useState<{ name: string; content: string }[]>([]);
  const [name, setName] = useState("");
  const [stack, setStack] = useState("");
  const [archetype, setArchetype] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const tags = parseTagsInput(tagsInput);
  const meta = {
    ...(name.trim() ? { name: name.trim() } : {}),
    ...(stack.trim() ? { stack: stack.trim() } : {}),
    ...(archetype.trim() ? { archetype: archetype.trim() } : {}),
    ...(tags.length > 0 ? { tags } : {}),
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    let payload: AddProjectPayload;
    if (mode === "pointer") {
      if (!repoUrl.trim()) {
        setError("A GitHub repo URL is required.");
        return;
      }
      payload = {
        mode: "pointer",
        repoUrl: repoUrl.trim(),
        path: pathInput.trim(),
        ref: ref.trim(),
        ...meta,
      };
    } else {
      if (files.length === 0) {
        setError("Select the doc-set markdown files to upload.");
        return;
      }
      payload = { mode: "files", files, ...meta };
    }

    setBusy(true);
    try {
      const entry = await addProject(payload);
      onAdded(entry.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  return (
    <div className="dialog-overlay" role="dialog" aria-modal="true" aria-label="Add a project" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <div className="dialog-header">
          <h2>Add a project</h2>
          <button type="button" className="dialog-close" aria-label="Close" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="dialog-tabs">
          <button
            type="button"
            className={`dialog-tab${mode === "pointer" ? " is-active" : ""}`}
            onClick={() => setMode("pointer")}
          >
            From GitHub
          </button>
          <button
            type="button"
            className={`dialog-tab${mode === "files" ? " is-active" : ""}`}
            onClick={() => setMode("files")}
          >
            Upload files
          </button>
        </div>

        <form className="dialog-body" onSubmit={submit}>
          {mode === "pointer" ? (
            <>
              <p className="dialog-hint">
                Point at a doc set that already lives on GitHub. The hub reads it in place — nothing is copied.
              </p>
              <label className="field">
                <span>GitHub repo URL</span>
                <input
                  type="text"
                  placeholder="https://github.com/org/my-service"
                  value={repoUrl}
                  onChange={(e) => setRepoUrl(e.target.value)}
                  autoFocus
                />
              </label>
              <label className="field">
                <span>Docs path in repo</span>
                <input
                  type="text"
                  placeholder="docs/backend-analysis"
                  value={pathInput}
                  onChange={(e) => setPathInput(e.target.value)}
                />
              </label>
              <label className="field">
                <span>Branch / ref (optional)</span>
                <input
                  type="text"
                  placeholder="defaults to the repo's default branch"
                  value={ref}
                  onChange={(e) => setRef(e.target.value)}
                />
              </label>
            </>
          ) : (
            <>
              <p className="dialog-hint">
                Drop the generated <code>.md</code> pages. They're committed into the registry repo and published to the hub.
              </p>
              <label className="field">
                <span>Markdown files</span>
                <input
                  type="file"
                  multiple
                  accept=".md,text/markdown"
                  onChange={(e) => {
                    if (e.target.files) readFiles(e.target.files).then(setFiles);
                  }}
                />
              </label>
              {files.length > 0 && (
                <p className="dialog-hint">
                  {files.length} markdown {files.length === 1 ? "file" : "files"} selected.
                </p>
              )}
            </>
          )}

          <details className="dialog-advanced">
            <summary>
              Metadata (auto-detected from headers — override if needed; required if the source has no header block yet)
            </summary>
            <label className="field">
              <span>Display name</span>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label className="field">
              <span>Stack</span>
              <input type="text" placeholder="java-spring | react" value={stack} onChange={(e) => setStack(e.target.value)} />
            </label>
            <label className="field">
              <span>Archetype</span>
              <input type="text" placeholder="rest-api | react-spa | …" value={archetype} onChange={(e) => setArchetype(e.target.value)} />
            </label>
            <label className="field">
              <span>Tags (comma-separated)</span>
              <input
                type="text"
                placeholder="team-a, billing, tier-1"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
              />
            </label>
          </details>

          {error && <p className="dialog-error">{error}</p>}

          <div className="dialog-actions">
            <Link to="/help" className="dialog-help-link" onClick={onClose}>
              Need help?
            </Link>
            <button type="button" className="button" onClick={onClose} disabled={busy}>
              Cancel
            </button>
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? "Publishing…" : "Publish to hub"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
