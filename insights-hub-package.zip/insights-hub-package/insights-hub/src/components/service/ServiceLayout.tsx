import { Link, useParams } from "react-router-dom";
import type { ServiceEntry } from "../../types/manifest";
import { defaultPage, resolveSlug } from "../../lib/pages";
import { useManifest } from "../../hooks/useManifest";
import { ErrorState } from "../common/ErrorState";
import { LoadingSkeleton } from "../common/LoadingSkeleton";
import { NotFoundPage } from "../common/NotFoundPage";
import { PageNav } from "./PageNav";
import { DocPage } from "./DocPage";

/**
 * Rendered in the content pane when the slug doesn't resolve to a page this
 * service publishes (e.g. /overview on a React service, or a typo'd slug).
 * The sidebar stays fully usable.
 */
function PageNotInSet({ entry }: { entry: ServiceEntry }) {
  const fallback = defaultPage(entry);
  return (
    <div className="page-not-in-set">
      <h1>Page not available</h1>
      <p>
        This page isn&apos;t part of the <strong>{entry.skill}</strong> documentation set
        for <strong>{entry.name}</strong>.
      </p>
      <Link className="button" to={`/services/${entry.id}/${fallback.slug}`}>
        Go to {fallback.title}
      </Link>
    </div>
  );
}

export function ServiceLayout() {
  const { serviceId = "", pageSlug = "" } = useParams();
  const { data, error, loading, retry } = useManifest();

  if (loading) {
    return (
      <div className="service-layout service-layout-loading">
        <LoadingSkeleton variant="doc" />
      </div>
    );
  }

  if (error !== null || data === null) {
    return (
      <div className="service-layout service-layout-loading">
        <ErrorState
          title="Catalog unavailable"
          message="No manifest found at content/manifest.json — run the insights-hub-generator skill to publish services"
          detail={error?.message}
          onRetry={retry}
        />
      </div>
    );
  }

  const entry = data.services.find((s) => s.id === serviceId);
  if (entry === undefined) {
    return (
      <NotFoundPage
        title="Service not found"
        message={`No service with id "${serviceId}" is published in the catalog.`}
      />
    );
  }

  const resolution = resolveSlug(entry, pageSlug);

  return (
    <div className="service-layout">
      <PageNav entry={entry} currentSlug={pageSlug} />
      <section className="doc-pane">
        {resolution.kind === "found" ? (
          <DocPage entry={entry} page={resolution.page} />
        ) : (
          <PageNotInSet entry={entry} />
        )}
      </section>
    </div>
  );
}
