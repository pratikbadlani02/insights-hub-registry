import { useEffect } from "react";
import type { ServiceEntry } from "../../types/manifest";
import type { PageDef } from "../../lib/pages";
import { useMarkdownPage } from "../../hooks/useMarkdownPage";
import { ErrorState } from "../common/ErrorState";
import { LoadingSkeleton } from "../common/LoadingSkeleton";
import { MarkdownView } from "../markdown/MarkdownView";
import { DocMetaBar } from "./DocMetaBar";

interface DocPageProps {
  entry: ServiceEntry;
  page: PageDef;
}

export function DocPage({ entry, page }: DocPageProps) {
  const { doc, error, loading, path, retry } = useMarkdownPage(entry.id, page.stem);

  useEffect(() => {
    document.title = `${page.title} · ${entry.name} · Insights Hub`;
  }, [page.title, entry.name]);

  if (loading) {
    return <LoadingSkeleton variant="doc" />;
  }

  // Errors render inside the content pane; the sidebar stays usable.
  if (error !== null || doc === null) {
    return (
      <ErrorState
        title="Couldn't load this page"
        message={error?.message ?? "Unknown error"}
        detail={`Attempted path: ${path}`}
        onRetry={retry}
      />
    );
  }

  return (
    <article className="doc-page">
      {doc.meta !== null && (
        <header className="doc-page-header">
          <h1 className="doc-page-title">{doc.title ?? page.title}</h1>
          <DocMetaBar meta={doc.meta} entry={entry} />
        </header>
      )}
      <MarkdownView body={doc.body} />
    </article>
  );
}
