import type { DocMeta } from "../../lib/docHeader";
import type { ServiceEntry } from "../../types/manifest";
import { absoluteTime, shortDate } from "../../lib/time";

interface DocMetaBarProps {
  meta: DocMeta;
  entry: ServiceEntry;
}

function norm(v: string | undefined): string {
  return (v ?? "").trim().toLowerCase();
}

function WarningIcon({ note }: { note: string }) {
  return (
    <svg
      className="meta-warning"
      viewBox="0 0 16 16"
      width="12"
      height="12"
      role="img"
      aria-label={note}
    >
      <title>{note}</title>
      <path
        fill="currentColor"
        d="M8 1.5a1.4 1.4 0 0 1 1.22.71l5.6 9.8A1.4 1.4 0 0 1 13.6 14H2.4a1.4 1.4 0 0 1-1.22-2l5.6-9.79A1.4 1.4 0 0 1 8 1.5Zm0 3.75a.75.75 0 0 0-.75.75v3a.75.75 0 0 0 1.5 0V6a.75.75 0 0 0-.75-.75ZM8 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
      />
    </svg>
  );
}

function MetaBadge({
  label,
  value,
  title,
  warning,
}: {
  label: string;
  value: string;
  title?: string;
  warning?: string;
}) {
  return (
    <span className="meta-badge" title={title}>
      <span className="meta-badge-label">{label}</span>
      <span className="meta-badge-value">
        {value}
        {warning !== undefined && <WarningIcon note={warning} />}
      </span>
    </span>
  );
}

/**
 * Renders the parsed doc header as a badge row. If the header's Project/Type
 * disagree with the manifest entry, a subtle warning icon flags the drift.
 */
export function DocMetaBar({ meta, entry }: DocMetaBarProps) {
  const projectMismatch =
    meta.project !== undefined && norm(meta.project) !== norm(entry.id)
      ? `Header says "${meta.project}" but the manifest entry is "${entry.id}"`
      : undefined;
  const typeMismatch =
    meta.type !== undefined && norm(meta.type) !== norm(entry.archetype)
      ? `Header says "${meta.type}" but the manifest archetype is "${entry.archetype}"`
      : undefined;

  return (
    <div className="doc-meta-bar">
      {meta.project !== undefined && (
        <MetaBadge label="Project" value={meta.project} warning={projectMismatch} />
      )}
      {meta.type !== undefined && (
        <MetaBadge label="Type" value={meta.type} warning={typeMismatch} />
      )}
      {meta.skill !== undefined && <MetaBadge label="Skill" value={meta.skill} />}
      {meta.analyzed !== undefined && (
        <MetaBadge
          label="Analyzed"
          value={shortDate(meta.analyzed)}
          title={absoluteTime(meta.analyzed)}
        />
      )}
    </div>
  );
}
