import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import type { ServiceEntry } from "../../types/manifest";
import { pagesForService } from "../../lib/pages";
import { useManifest } from "../../hooks/useManifest";
import { useServerConfig } from "../../hooks/useServerConfig";
import { deleteProject, uploadsAvailable } from "../../lib/api";
import { EditProjectDialog } from "../upload/EditProjectDialog";
import { StackBadge } from "../catalog/StackBadge";
import { ArchetypeBadge } from "../catalog/ArchetypeBadge";
import { TagList } from "../catalog/TagBadge";

interface PageNavProps {
  entry: ServiceEntry;
  currentSlug: string;
}

/**
 * Left sidebar navigation; collapses to a <select> under 768px (CSS swaps
 * .page-nav-list and .page-nav-select).
 */
export function PageNav({ entry, currentSlug }: PageNavProps) {
  const navigate = useNavigate();
  const { retry } = useManifest();
  const serverConfig = useServerConfig();
  const canManage = uploadsAvailable(serverConfig);
  const pages = pagesForService(entry);
  const selectValue = pages.some((p) => p.slug === currentSlug) ? currentSlug : "";

  const [editOpen, setEditOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  function handleSaved() {
    setEditOpen(false);
    retry();
  }

  async function handleDelete() {
    if (
      !window.confirm(
        `Remove "${entry.name}" from the catalog? If its pages were committed to the registry repo, they're deleted too — this can't be undone from the hub.`,
      )
    ) {
      return;
    }
    setDeleteError(null);
    setDeleting(true);
    try {
      await deleteProject(entry.id);
      retry();
      navigate("/");
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : String(err));
      setDeleting(false);
    }
  }

  return (
    <aside className="page-nav">
      <div className="page-nav-service">
        <Link to="/" className="page-nav-back">
          ← All services
        </Link>
        <h2 className="page-nav-title">{entry.name}</h2>
        <div className="page-nav-badges">
          <StackBadge stack={entry.stack} />
          <ArchetypeBadge archetype={entry.archetype} />
        </div>
        <TagList tags={entry.tags} />
        {canManage && (
          <div className="page-nav-manage">
            <button type="button" className="button page-nav-manage-btn" onClick={() => setEditOpen(true)}>
              Edit
            </button>
            <button
              type="button"
              className="button button-danger page-nav-manage-btn"
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? "Removing…" : "Delete"}
            </button>
          </div>
        )}
        {deleteError && <p className="dialog-error page-nav-manage-error">{deleteError}</p>}
      </div>
      {editOpen && <EditProjectDialog entry={entry} onClose={() => setEditOpen(false)} onSaved={handleSaved} />}

      <nav className="page-nav-list" aria-label="Documentation pages">
        {pages.map((p) => (
          <NavLink
            key={p.stem}
            to={`/services/${entry.id}/${p.slug}`}
            className={({ isActive }) =>
              isActive ? "page-nav-link page-nav-link-active" : "page-nav-link"
            }
          >
            <span className="page-nav-num">{p.stem.slice(0, 2)}</span>
            {p.title}
          </NavLink>
        ))}
      </nav>

      <div className="page-nav-select">
        <label className="visually-hidden" htmlFor="page-nav-select-input">
          Documentation page
        </label>
        <select
          id="page-nav-select-input"
          value={selectValue}
          onChange={(e) => navigate(`/services/${entry.id}/${e.target.value}`)}
        >
          {selectValue === "" && (
            <option value="" disabled>
              Select a page…
            </option>
          )}
          {pages.map((p) => (
            <option key={p.stem} value={p.slug}>
              {p.title}
            </option>
          ))}
        </select>
      </div>
    </aside>
  );
}
