import { useEffect, useId, useState } from "react";
import mermaid from "mermaid";
import { useTheme, type Theme } from "../../hooks/useTheme";

/**
 * Renders a ```mermaid fence as an SVG diagram.
 *
 * Hazards handled here:
 * - mermaid.initialize() must run once (module-level guard), and again when
 *   the theme flips (MarkdownView remounts blocks on theme change).
 * - mermaid.render() ids must be unique per render attempt or route
 *   changes/StrictMode double-invokes collide (useId + module counter).
 * - On a parse error mermaid appends an orphan error element to
 *   document.body — it must be removed, and the raw code shown instead.
 */

let initializedTheme: string | null = null;

function ensureMermaid(theme: Theme): void {
  const mermaidTheme = theme === "dark" ? "dark" : "default";
  if (initializedTheme !== mermaidTheme) {
    mermaid.initialize({
      startOnLoad: false,
      securityLevel: "strict",
      theme: mermaidTheme,
    });
    initializedTheme = mermaidTheme;
  }
}

/** mermaid leaves temp/error nodes in document.body keyed by render id. */
function removeOrphans(renderId: string): void {
  document.getElementById(renderId)?.remove();
  document.getElementById(`d${renderId}`)?.remove();
}

let renderSeq = 0;

type RenderState =
  | { status: "pending" }
  | { status: "done"; svg: string }
  | { status: "error"; message: string };

export function MermaidBlock({ code }: { code: string }) {
  const { theme } = useTheme();
  const reactId = useId();
  const [state, setState] = useState<RenderState>({ status: "pending" });

  useEffect(() => {
    let cancelled = false;
    ensureMermaid(theme);
    renderSeq += 1;
    // ids must be valid CSS identifiers: strip useId's punctuation, add a
    // counter so StrictMode's double effect never reuses an id.
    const renderId = `mmd${reactId.replace(/[^a-zA-Z0-9]/g, "")}x${renderSeq}`;
    setState({ status: "pending" });

    mermaid.render(renderId, code).then(
      ({ svg }) => {
        if (!cancelled) setState({ status: "done", svg });
      },
      (err: unknown) => {
        removeOrphans(renderId);
        if (!cancelled) {
          setState({
            status: "error",
            message: err instanceof Error ? err.message : String(err),
          });
        }
      },
    );

    return () => {
      cancelled = true;
      removeOrphans(renderId);
    };
  }, [code, theme, reactId]);

  if (state.status === "error") {
    return (
      <div className="mermaid-error" role="alert">
        <p className="mermaid-error-notice">
          <svg className="icon" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true">
            <path
              fill="currentColor"
              d="M8 1.5a1.4 1.4 0 0 1 1.22.71l5.6 9.8A1.4 1.4 0 0 1 13.6 14H2.4a1.4 1.4 0 0 1-1.22-2l5.6-9.79A1.4 1.4 0 0 1 8 1.5Zm0 3.75a.75.75 0 0 0-.75.75v3a.75.75 0 0 0 1.5 0V6a.75.75 0 0 0-.75-.75ZM8 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
            />
          </svg>
          Diagram failed to render — showing the source instead.
        </p>
        <pre className="mermaid-error-source">
          <code>{code}</code>
        </pre>
      </div>
    );
  }

  if (state.status === "done") {
    return (
      <div
        className="mermaid-diagram"
        // Safe: mermaid runs with securityLevel "strict" and produced this SVG.
        dangerouslySetInnerHTML={{ __html: state.svg }}
      />
    );
  }

  return (
    <div className="mermaid-diagram mermaid-pending" aria-busy="true">
      Rendering diagram…
    </div>
  );
}
