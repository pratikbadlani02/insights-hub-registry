import { memo } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import type { PluggableList } from "unified";
import type { Element as HastElement } from "hast";
import { MermaidBlock } from "./MermaidBlock";
import { useTheme } from "../../hooks/useTheme";

const remarkPlugins: PluggableList = [remarkGfm];

// detect stays OFF: the analysis skills emit untagged pseudo-code fences that
// must pass through unhighlighted. plainText keeps rehype-highlight's hands
// off mermaid fences so their children stay raw text for MermaidBlock.
const rehypePlugins: PluggableList = [
  [rehypeHighlight, { detect: false, plainText: ["mermaid"] }],
];

const MERMAID_CLASS = /\blanguage-mermaid\b/;

function isMermaidPre(node: HastElement | undefined): boolean {
  const first = node?.children[0];
  if (!first || first.type !== "element" || first.tagName !== "code") return false;
  const cls = first.properties["className"];
  const list = Array.isArray(cls) ? cls : typeof cls === "string" ? [cls] : [];
  return list.some((c) => typeof c === "string" && MERMAID_CLASS.test(c));
}

const components: Components = {
  code(props) {
    const { className, children, node, ...rest } = props;
    void node;
    if (MERMAID_CLASS.test(className ?? "")) {
      return <MermaidBlock code={String(children ?? "").replace(/\n$/, "")} />;
    }
    return (
      <code className={className} {...rest}>
        {children}
      </code>
    );
  },
  // Unwrap the <pre> around mermaid fences so the diagram isn't boxed in
  // code-block styling (and no <div> ends up inside a <pre>).
  pre(props) {
    const { children, node, ...rest } = props;
    if (isMermaidPre(node)) return <>{children}</>;
    return <pre {...rest}>{children}</pre>;
  },
};

interface MarkdownViewProps {
  body: string;
}

/**
 * Memoized on body (via memo) and theme (via context + key remount so every
 * MermaidBlock re-renders against the re-initialized mermaid theme).
 */
export const MarkdownView = memo(function MarkdownView({ body }: MarkdownViewProps) {
  const { theme } = useTheme();
  return (
    <div className="markdown-body" key={theme}>
      <ReactMarkdown
        remarkPlugins={remarkPlugins}
        rehypePlugins={rehypePlugins}
        components={components}
      >
        {body}
      </ReactMarkdown>
    </div>
  );
});
