import { KNOWN_STACKS } from "../../types/manifest";

const STACK_LABELS: Record<string, string> = {
  "java-spring": "Java · Spring",
  react: "React",
};

export function stackLabel(stack: string): string {
  return STACK_LABELS[stack] ?? stack;
}

export function StackBadge({ stack }: { stack: string }) {
  const known = (KNOWN_STACKS as readonly string[]).includes(stack);
  return (
    <span className="badge stack-badge" data-stack={known ? stack : "unknown"} title={`Stack: ${stack}`}>
      <span className="stack-badge-dot" aria-hidden="true" />
      {stackLabel(stack)}
    </span>
  );
}
