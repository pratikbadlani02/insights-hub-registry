import { Link } from "react-router-dom";
import type { ServiceEntry } from "../../types/manifest";
import { defaultPage } from "../../lib/pages";
import { absoluteTime, relativeTime } from "../../lib/time";
import { StackBadge } from "./StackBadge";
import { ArchetypeBadge } from "./ArchetypeBadge";
import { TagList } from "./TagBadge";

export function ServiceCard({ entry }: { entry: ServiceEntry }) {
  const pageCount = entry.pages.length;
  return (
    <Link className="service-card" to={`/services/${entry.id}/${defaultPage(entry).slug}`}>
      <h3 className="service-card-name">{entry.name}</h3>
      <p className="service-card-id">{entry.id}</p>
      <div className="service-card-badges">
        <StackBadge stack={entry.stack} />
        <ArchetypeBadge archetype={entry.archetype} />
      </div>
      <TagList tags={entry.tags} />
      <div className="service-card-meta">
        <span title={absoluteTime(entry.analyzedAt)}>
          Analyzed {relativeTime(entry.analyzedAt)}
        </span>
        <span>
          {pageCount} {pageCount === 1 ? "page" : "pages"}
        </span>
      </div>
    </Link>
  );
}
