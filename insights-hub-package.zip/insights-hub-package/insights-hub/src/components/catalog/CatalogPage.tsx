import { useEffect, useMemo, useState } from "react";
import { useManifest } from "../../hooks/useManifest";
import { useServerConfig } from "../../hooks/useServerConfig";
import { uploadsAvailable } from "../../lib/api";
import { ErrorState } from "../common/ErrorState";
import { LoadingSkeleton } from "../common/LoadingSkeleton";
import { AddProjectDialog } from "../upload/AddProjectDialog";
import { CatalogFilters } from "./CatalogFilters";
import { ServiceCard } from "./ServiceCard";

function toggleValue(list: string[], value: string): string[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

export function CatalogPage() {
  const { data, error, loading, retry } = useManifest();
  const serverConfig = useServerConfig();
  const [query, setQuery] = useState("");
  const [selectedStacks, setSelectedStacks] = useState<string[]>([]);
  const [selectedArchetypes, setSelectedArchetypes] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);

  const canUpload = uploadsAvailable(serverConfig);

  useEffect(() => {
    document.title = "Insights Hub";
  }, []);

  function handleAdded() {
    setDialogOpen(false);
    retry();
  }

  const addButton = canUpload ? (
    <button type="button" className="button button-primary" onClick={() => setDialogOpen(true)}>
      + Add project
    </button>
  ) : null;

  const dialog = dialogOpen ? (
    <AddProjectDialog onClose={() => setDialogOpen(false)} onAdded={handleAdded} />
  ) : null;

  const services = useMemo(() => data?.services ?? [], [data]);

  const stacks = useMemo(() => [...new Set(services.map((s) => s.stack))], [services]);
  const archetypes = useMemo(() => [...new Set(services.map((s) => s.archetype))], [services]);
  const tags = useMemo(
    () => [...new Set(services.flatMap((s) => s.tags))].sort(),
    [services],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return services.filter(
      (s) =>
        (q === "" ||
          s.name.toLowerCase().includes(q) ||
          s.id.toLowerCase().includes(q) ||
          s.tags.some((t) => t.includes(q))) &&
        (selectedStacks.length === 0 || selectedStacks.includes(s.stack)) &&
        (selectedArchetypes.length === 0 || selectedArchetypes.includes(s.archetype)) &&
        (selectedTags.length === 0 || selectedTags.every((t) => s.tags.includes(t))),
    );
  }, [services, query, selectedStacks, selectedArchetypes, selectedTags]);

  if (loading) {
    return (
      <div className="catalog">
        <LoadingSkeleton variant="catalog" />
      </div>
    );
  }

  if (error !== null || data === null) {
    return (
      <div className="catalog">
        <ErrorState
          title="Catalog unavailable"
          message="No manifest found at content/manifest.json — run the insights-hub-generator skill to publish services"
          detail={error?.message}
          onRetry={retry}
        />
      </div>
    );
  }

  if (services.length === 0) {
    return (
      <div className="catalog">
        <div className="empty-state">
          <h2>No services published yet</h2>
          <p>
            The manifest is valid but lists no services. Run the{" "}
            <code>insights-hub-generator</code> skill against your workspace, or add a project
            directly from GitHub.
          </p>
          {addButton}
        </div>
        {dialog}
      </div>
    );
  }

  return (
    <div className="catalog">
      <div className="catalog-header">
        <div>
          <h1>Service catalog</h1>
          <p className="catalog-subtitle">
            {services.length} {services.length === 1 ? "service" : "services"} documented
          </p>
        </div>
        {addButton}
      </div>
      <CatalogFilters
        query={query}
        onQueryChange={setQuery}
        stacks={stacks}
        archetypes={archetypes}
        tags={tags}
        selectedStacks={selectedStacks}
        selectedArchetypes={selectedArchetypes}
        selectedTags={selectedTags}
        onToggleStack={(s) => setSelectedStacks((prev) => toggleValue(prev, s))}
        onToggleArchetype={(a) => setSelectedArchetypes((prev) => toggleValue(prev, a))}
        onToggleTag={(t) => setSelectedTags((prev) => toggleValue(prev, t))}
      />
      {filtered.length === 0 ? (
        <div className="empty-state">
          <h2>No services match</h2>
          <p>Try a different search or clear the active filters.</p>
          <button
            type="button"
            className="button"
            onClick={() => {
              setQuery("");
              setSelectedStacks([]);
              setSelectedArchetypes([]);
              setSelectedTags([]);
            }}
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="catalog-grid">
          {filtered.map((entry) => (
            <ServiceCard key={entry.id} entry={entry} />
          ))}
        </div>
      )}
      {dialog}
    </div>
  );
}
