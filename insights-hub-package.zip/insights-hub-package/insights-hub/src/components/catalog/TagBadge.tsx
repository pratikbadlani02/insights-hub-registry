export function TagBadge({ tag }: { tag: string }) {
  return <span className="tag-badge">{tag}</span>;
}

export function TagList({ tags }: { tags: string[] }) {
  if (tags.length === 0) return null;
  return (
    <div className="tag-list">
      {tags.map((t) => (
        <TagBadge key={t} tag={t} />
      ))}
    </div>
  );
}
