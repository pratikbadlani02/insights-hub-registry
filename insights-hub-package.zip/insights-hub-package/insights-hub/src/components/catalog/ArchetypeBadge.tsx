import { KNOWN_ARCHETYPES } from "../../types/manifest";

const ARCHETYPE_LABELS: Record<string, string> = {
  "rest-api": "REST API",
  "kafka-consumer": "Kafka Consumer",
  batch: "Batch",
  gateway: "Gateway",
  "react-spa": "React SPA",
  "react-mfe": "React MFE",
};

export function archetypeLabel(archetype: string): string {
  return ARCHETYPE_LABELS[archetype] ?? archetype;
}

/**
 * Colored per known archetype (see theme.css); unknown archetypes get the
 * neutral fallback style but still display their raw value.
 */
export function ArchetypeBadge({ archetype }: { archetype: string }) {
  const known = (KNOWN_ARCHETYPES as readonly string[]).includes(archetype);
  return (
    <span
      className="badge archetype-badge"
      data-archetype={known ? archetype : "unknown"}
      title={`Archetype: ${archetype}`}
    >
      {archetypeLabel(archetype)}
    </span>
  );
}
