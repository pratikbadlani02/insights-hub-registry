import { stackLabel } from "./StackBadge";
import { archetypeLabel } from "./ArchetypeBadge";

interface CatalogFiltersProps {
  query: string;
  onQueryChange: (q: string) => void;
  stacks: string[];
  archetypes: string[];
  tags: string[];
  selectedStacks: string[];
  selectedArchetypes: string[];
  selectedTags: string[];
  onToggleStack: (stack: string) => void;
  onToggleArchetype: (archetype: string) => void;
  onToggleTag: (tag: string) => void;
}

function Chip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={active ? "chip chip-active" : "chip"}
      aria-pressed={active}
      onClick={onClick}
    >
      {label}
    </button>
  );
}

export function CatalogFilters({
  query,
  onQueryChange,
  stacks,
  archetypes,
  tags,
  selectedStacks,
  selectedArchetypes,
  selectedTags,
  onToggleStack,
  onToggleArchetype,
  onToggleTag,
}: CatalogFiltersProps) {
  return (
    <div className="catalog-filters">
      <input
        type="search"
        className="catalog-search"
        placeholder="Search services by name, id, or tag…"
        aria-label="Search services"
        value={query}
        onChange={(e) => onQueryChange(e.target.value)}
      />
      {(stacks.length > 0 || archetypes.length > 0 || tags.length > 0) && (
        <div className="chip-rows">
          {stacks.length > 0 && (
            <div className="chip-row" role="group" aria-label="Filter by stack">
              <span className="chip-row-label">Stack</span>
              {stacks.map((s) => (
                <Chip
                  key={s}
                  label={stackLabel(s)}
                  active={selectedStacks.includes(s)}
                  onClick={() => onToggleStack(s)}
                />
              ))}
            </div>
          )}
          {archetypes.length > 0 && (
            <div className="chip-row" role="group" aria-label="Filter by archetype">
              <span className="chip-row-label">Archetype</span>
              {archetypes.map((a) => (
                <Chip
                  key={a}
                  label={archetypeLabel(a)}
                  active={selectedArchetypes.includes(a)}
                  onClick={() => onToggleArchetype(a)}
                />
              ))}
            </div>
          )}
          {tags.length > 0 && (
            <div className="chip-row" role="group" aria-label="Filter by tag">
              <span className="chip-row-label">Tags</span>
              {tags.map((t) => (
                <Chip key={t} label={t} active={selectedTags.includes(t)} onClick={() => onToggleTag(t)} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
