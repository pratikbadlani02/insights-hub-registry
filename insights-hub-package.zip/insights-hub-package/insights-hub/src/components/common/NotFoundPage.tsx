import { Link } from "react-router-dom";

interface NotFoundPageProps {
  title?: string;
  message?: string;
}

export function NotFoundPage({
  title = "Page not found",
  message = "The page you're looking for doesn't exist.",
}: NotFoundPageProps) {
  return (
    <div className="not-found">
      <p className="not-found-code">404</p>
      <h1>{title}</h1>
      <p className="not-found-message">{message}</p>
      <Link className="button" to="/">
        Back to the catalog
      </Link>
    </div>
  );
}
