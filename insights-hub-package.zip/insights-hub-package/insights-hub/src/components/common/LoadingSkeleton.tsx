interface LoadingSkeletonProps {
  variant?: "catalog" | "doc";
}

export function LoadingSkeleton({ variant = "doc" }: LoadingSkeletonProps) {
  if (variant === "catalog") {
    return (
      <div className="skeleton-grid" aria-busy="true" aria-label="Loading services">
        {[0, 1, 2].map((i) => (
          <div key={i} className="skeleton-card">
            <div className="skeleton-bar" style={{ width: "60%" }} />
            <div className="skeleton-bar" style={{ width: "40%" }} />
            <div className="skeleton-bar" style={{ width: "80%" }} />
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="skeleton-doc" aria-busy="true" aria-label="Loading page">
      <div className="skeleton-bar" style={{ width: "35%", height: "1.6rem" }} />
      <div className="skeleton-bar" style={{ width: "55%" }} />
      <div className="skeleton-bar" style={{ width: "95%" }} />
      <div className="skeleton-bar" style={{ width: "88%" }} />
      <div className="skeleton-bar" style={{ width: "92%" }} />
      <div className="skeleton-bar" style={{ width: "70%" }} />
    </div>
  );
}
