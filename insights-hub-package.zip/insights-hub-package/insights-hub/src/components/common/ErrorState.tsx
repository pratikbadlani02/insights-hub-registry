import type { ReactNode } from "react";

interface ErrorStateProps {
  title: string;
  /** Primary human-readable explanation (may contain the remediation hint). */
  message?: string;
  /** Technical detail, e.g. the underlying error message or attempted path. */
  detail?: string;
  onRetry?: () => void;
  children?: ReactNode;
}

export function ErrorState({ title, message, detail, onRetry, children }: ErrorStateProps) {
  return (
    <div className="error-state" role="alert">
      <svg className="error-state-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true">
        <path
          fill="currentColor"
          d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 5a1 1 0 0 1 1 1v5a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 10.5a1.25 1.25 0 1 1 0-2.5 1.25 1.25 0 0 1 0 2.5Z"
        />
      </svg>
      <h2 className="error-state-title">{title}</h2>
      {message !== undefined && <p className="error-state-message">{message}</p>}
      {detail !== undefined && <p className="error-state-detail">{detail}</p>}
      {children}
      {onRetry && (
        <button type="button" className="button" onClick={onRetry}>
          Retry
        </button>
      )}
    </div>
  );
}
