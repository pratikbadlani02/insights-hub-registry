import { Link, NavLink } from "react-router-dom";
import { ThemeToggle } from "./ThemeToggle";

function Logo() {
  return (
    <svg viewBox="0 0 32 32" width="22" height="22" aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="var(--accent)" />
      <path d="M8 20v5h3.5v-5zM14.25 13v12h3.5V13zM20.5 7v18H24V7z" fill="#fff" />
    </svg>
  );
}

export function TopBar() {
  return (
    <header className="top-bar">
      <Link to="/" className="top-bar-brand">
        <Logo />
        <span className="top-bar-name">Insights Hub</span>
      </Link>
      <div className="top-bar-actions">
        <NavLink
          to="/help"
          className={({ isActive }) => `top-bar-link${isActive ? " is-active" : ""}`}
        >
          Help
        </NavLink>
        <NavLink
          to="/settings"
          className={({ isActive }) => `top-bar-icon-link${isActive ? " is-active" : ""}`}
          aria-label="Settings"
          title="Settings"
        >
          <svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor" aria-hidden="true">
            <path d="M8 0a8.2 8.2 0 0 1 .701.031C9.444.095 9.99.645 10.16 1.29l.288 1.107c.018.066.079.158.212.224.231.114.454.243.668.386.123.082.233.09.299.071l1.103-.303c.644-.176 1.392.021 1.82.63.27.385.506.792.704 1.218.315.675.111 1.422-.364 1.891l-.814.806c-.049.048-.098.147-.088.294.016.257.016.515 0 .772-.01.147.038.246.088.294l.814.806c.475.469.679 1.216.364 1.891a7.977 7.977 0 0 1-.704 1.217c-.428.61-1.176.807-1.82.63l-1.102-.302c-.067-.019-.177-.011-.3.071a5.909 5.909 0 0 1-.668.386c-.133.066-.194.158-.211.224l-.29 1.106c-.168.646-.715 1.196-1.458 1.26a8.006 8.006 0 0 1-1.402 0c-.743-.064-1.289-.614-1.458-1.26l-.289-1.106c-.018-.066-.079-.158-.212-.224a5.738 5.738 0 0 1-.668-.386c-.123-.082-.233-.09-.299-.071l-1.103.303c-.644.176-1.392-.021-1.82-.63a8.12 8.12 0 0 1-.704-1.218c-.315-.675-.111-1.422.363-1.891l.815-.806c.05-.048.098-.147.088-.294a6.214 6.214 0 0 1 0-.772c.01-.147-.038-.246-.088-.294l-.815-.806C.635 6.045.431 5.298.746 4.623a7.92 7.92 0 0 1 .704-1.217c.428-.61 1.176-.807 1.82-.63l1.102.302c.067.019.177.011.3-.071.214-.143.437-.272.668-.386.133-.066.194-.158.211-.224l.29-1.106C6.717.645 7.264.095 8.006.031 8.083.01 8.042 0 8 0Zm0 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2Zm0 3a3 3 0 1 1 0 6 3 3 0 0 1 0-6Z"/>
          </svg>
        </NavLink>
        <ThemeToggle />
      </div>
    </header>
  );
}
