import { useTheme } from "../../hooks/useTheme";

function SunIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path
        fill="currentColor"
        d="M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0-15a1 1 0 0 1 1 1v1.5a1 1 0 1 1-2 0V3a1 1 0 0 1 1-1Zm0 17.5a1 1 0 0 1 1 1V22a1 1 0 1 1-2 0v-1.5a1 1 0 0 1 1-1ZM22 12a1 1 0 0 1-1 1h-1.5a1 1 0 1 1 0-2H21a1 1 0 0 1 1 1ZM4.5 12a1 1 0 0 1-1 1H2a1 1 0 1 1 0-2h1.5a1 1 0 0 1 1 1Zm14.57-7.07a1 1 0 0 1 0 1.41l-1.06 1.07a1 1 0 0 1-1.42-1.42l1.07-1.06a1 1 0 0 1 1.41 0ZM5.99 16.59a1 1 0 0 1 0 1.42l-1.06 1.06a1 1 0 1 1-1.42-1.41l1.07-1.07a1 1 0 0 1 1.41 0Zm13.08 1.07a1 1 0 1 1-1.41 1.41l-1.07-1.06a1 1 0 0 1 1.42-1.42l1.06 1.07ZM6 5.99a1 1 0 0 1-1.42 0L3.51 4.93a1 1 0 0 1 1.42-1.41L5.99 4.58A1 1 0 0 1 6 6Z"
      />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path
        fill="currentColor"
        d="M21.53 15.93a.75.75 0 0 0-.87-.26 7.5 7.5 0 0 1-9.83-9.83.75.75 0 0 0-.97-.97A9 9 0 1 0 21.8 16.8a.75.75 0 0 0-.27-.87Z"
      />
    </svg>
  );
}

export function ThemeToggle() {
  const { theme, toggle } = useTheme();
  const label = theme === "dark" ? "Switch to light theme" : "Switch to dark theme";
  return (
    <button type="button" className="theme-toggle" onClick={toggle} aria-label={label} title={label}>
      {theme === "dark" ? <SunIcon /> : <MoonIcon />}
    </button>
  );
}
