import { useEffect, useState } from "react";
import { fetchHubSettings, saveHubSettings, TOKEN_MASK, type HubSettings } from "../../lib/api";

type SaveState = "idle" | "saving" | "saved" | "error";

function tokenHint(source: HubSettings["tokenSource"] | undefined): string {
  if (source === "saved") return "Saved — leave blank to keep current token, or enter a new one to replace it.";
  if (source === "env")   return "Loaded from environment variable. Enter a value here to override it.";
  return "No token configured. Enter a GitHub personal access token with write access to the registry repo.";
}

export function SettingsPage() {
  const [settings, setSettings] = useState<HubSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Record<string, string>>({});
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Settings — Insights Hub";
    fetchHubSettings().then((s) => {
      setSettings(s);
      if (s) {
        setForm({
          githubToken:    "",              // never pre-fill the token field
          githubApiBase:  s.githubApiBase,
          registryOwner:  s.registryOwner,
          registryRepo:   s.registryRepo,
          registryPath:   s.registryPath,
          registryBranch: s.registryBranch,
        });
      }
      setLoading(false);
    });
  }, []);

  function field(key: keyof typeof form) {
    return {
      value: form[key] ?? "",
      onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
        setForm((prev) => ({ ...prev, [key]: e.target.value })),
    };
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaveState("saving");
    setErrorMsg(null);
    try {
      const saved = await saveHubSettings(form);
      setSettings(saved);
      // Reset token field; keep other fields from the server response.
      setForm((prev) => ({
        ...prev,
        githubToken:    "",
        githubApiBase:  saved.githubApiBase,
        registryOwner:  saved.registryOwner,
        registryRepo:   saved.registryRepo,
        registryPath:   saved.registryPath,
        registryBranch: saved.registryBranch,
      }));
      setSaveState("saved");
      setTimeout(() => setSaveState("idle"), 3000);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : String(err));
      setSaveState("error");
    }
  }

  if (loading) return <div className="catalog"><p className="settings-loading">Loading settings…</p></div>;

  if (!settings) {
    return (
      <div className="catalog">
        <div className="settings-unavailable">
          <h2>Settings unavailable</h2>
          <p>The settings API is not reachable. Make sure the backend server is running.</p>
        </div>
      </div>
    );
  }

  const tokenIsSet = settings.githubToken === TOKEN_MASK;
  const registryOk = Boolean(settings.registryOwner && settings.registryRepo);

  return (
    <div className="catalog">
      <div className="settings-page">
        <div className="settings-header">
          <h1>Hub settings</h1>
          <p className="settings-subtitle">
            Configure the GitHub registry connection. Changes take effect immediately — no restart needed.
          </p>
        </div>

        <form className="settings-form" onSubmit={handleSubmit}>

          {/* ---- Registry status pill ---- */}
          <div className="settings-status">
            <span className={`status-pill ${registryOk && tokenIsSet ? "status-ok" : "status-warn"}`}>
              {registryOk && tokenIsSet ? "Registry connected" : "Registry not configured"}
            </span>
            {registryOk && !tokenIsSet && <span className="status-detail">— token missing</span>}
            {!registryOk && tokenIsSet && <span className="status-detail">— registry repo missing</span>}
          </div>

          {/* ---- GitHub connection ---- */}
          <section className="settings-section">
            <h2>GitHub connection</h2>

            <label className="field">
              <span>
                GitHub token
                <span className={`token-badge ${settings.tokenSource === "none" ? "token-badge-missing" : "token-badge-ok"}`}>
                  {settings.tokenSource === "none" ? "not set" : settings.tokenSource === "env" ? "from env" : "saved"}
                </span>
              </span>
              <input
                type="password"
                placeholder={tokenIsSet ? "Enter new token to replace…" : "ghp_…"}
                autoComplete="new-password"
                {...field("githubToken")}
              />
              <span className="field-hint">{tokenHint(settings.tokenSource)}</span>
              <span className="field-hint">
                Required scopes: <code>repo</code> (write to registry repo, read from private service repos).
              </span>
            </label>

            <label className="field">
              <span>GitHub API base URL</span>
              <input
                type="text"
                placeholder="https://api.github.com"
                {...field("githubApiBase")}
              />
              <span className="field-hint">Change only for GitHub Enterprise. Default: <code>https://api.github.com</code></span>
            </label>
          </section>

          {/* ---- Registry repo ---- */}
          <section className="settings-section">
            <h2>Registry repo</h2>
            <p className="settings-section-desc">
              The common GitHub repo that stores the manifest of registered projects.
              Uploads are recorded here; the hub reads it at runtime.
            </p>

            <div className="field-row">
              <label className="field">
                <span>Owner</span>
                <input type="text" placeholder="your-org" {...field("registryOwner")} />
              </label>
              <label className="field">
                <span>Repo</span>
                <input type="text" placeholder="insights-hub-registry" {...field("registryRepo")} />
              </label>
            </div>

            <div className="field-row">
              <label className="field">
                <span>Branch</span>
                <input type="text" placeholder="main" {...field("registryBranch")} />
              </label>
              <label className="field">
                <span>Manifest path</span>
                <input type="text" placeholder="manifest.json" {...field("registryPath")} />
              </label>
            </div>
          </section>

          {/* ---- Actions ---- */}
          {saveState === "error" && errorMsg && (
            <p className="dialog-error">{errorMsg}</p>
          )}

          <div className="settings-actions">
            {saveState === "saved" && (
              <span className="settings-saved-msg">Settings saved.</span>
            )}
            <button type="submit" className="button button-primary" disabled={saveState === "saving"}>
              {saveState === "saving" ? "Saving…" : "Save settings"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
