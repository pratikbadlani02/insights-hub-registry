import { useCallback, useEffect, useState } from "react";
import { fetchManifest } from "../lib/fetchContent";
import type { Manifest } from "../types/manifest";

/**
 * Module-level promise cache: the manifest is fetched once per app load and
 * shared by every consumer (catalog, service layout, redirects). `retry()`
 * clears the cache and refetches.
 */
let cachedManifest: Promise<Manifest> | null = null;

function loadManifest(): Promise<Manifest> {
  if (cachedManifest === null) {
    cachedManifest = fetchManifest().catch((err: unknown) => {
      cachedManifest = null; // don't cache failures
      throw err;
    });
  }
  return cachedManifest;
}

export interface ManifestState {
  data: Manifest | null;
  error: Error | null;
  loading: boolean;
  retry: () => void;
}

export function useManifest(): ManifestState {
  const [attempt, setAttempt] = useState(0);
  const [data, setData] = useState<Manifest | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    loadManifest().then(
      (manifest) => {
        if (cancelled) return;
        setData(manifest);
        setLoading(false);
      },
      (err: unknown) => {
        if (cancelled) return;
        setData(null);
        setError(err instanceof Error ? err : new Error(String(err)));
        setLoading(false);
      },
    );
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  const retry = useCallback(() => {
    cachedManifest = null;
    setAttempt((a) => a + 1);
  }, []);

  return { data, error, loading, retry };
}
