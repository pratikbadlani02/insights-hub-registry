import { useCallback, useEffect, useState } from "react";
import { fetchManifest } from "../lib/fetchContent";
import type { Manifest } from "../types/manifest";

/**
 * Module-level promise cache: the manifest is fetched once per app load and
 * shared by every consumer (catalog, service layout, redirects). `retry()`
 * clears the cache and notifies every mounted `useManifest()` instance to
 * refetch — a single component calling `retry()` (e.g. after an edit/delete/
 * sync) must refresh siblings too, not just itself.
 */
let cachedManifest: Promise<Manifest> | null = null;
const listeners = new Set<() => void>();

function loadManifest(): Promise<Manifest> {
  if (cachedManifest === null) {
    cachedManifest = fetchManifest().catch((err: unknown) => {
      cachedManifest = null; // don't cache failures
      throw err;
    });
  }
  return cachedManifest;
}

function invalidateManifest() {
  cachedManifest = null;
  listeners.forEach((listener) => listener());
}

export interface ManifestState {
  data: Manifest | null;
  error: Error | null;
  loading: boolean;
  retry: () => void;
}

export function useManifest(): ManifestState {
  const [data, setData] = useState<Manifest | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    function load() {
      setLoading(true);
      setError(null);
      loadManifest().then(
        (manifest) => {
          if (cancelled) return;
          setData(manifest);
          setLoading(false);
        },
        (err: unknown) => {
          if (cancelled) return;
          setData(null);
          setError(err instanceof Error ? err : new Error(String(err)));
          setLoading(false);
        },
      );
    }

    load();
    listeners.add(load);
    return () => {
      cancelled = true;
      listeners.delete(load);
    };
  }, []);

  const retry = useCallback(() => {
    invalidateManifest();
  }, []);

  return { data, error, loading, retry };
}
