import { useCallback, useEffect, useState } from "react";
import { fetchPage, pagePath } from "../lib/fetchContent";
import { parseDocHeader, type ParsedDoc } from "../lib/docHeader";

export interface MarkdownPageState {
  doc: ParsedDoc | null;
  error: Error | null;
  loading: boolean;
  /** The URL we (will) fetch — shown in inline error states. */
  path: string;
  retry: () => void;
}

export function useMarkdownPage(serviceId: string, stem: string): MarkdownPageState {
  const [attempt, setAttempt] = useState(0);
  const [doc, setDoc] = useState<ParsedDoc | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setDoc(null);
    setError(null);
    setLoading(true);
    fetchPage(serviceId, stem).then(
      (raw) => {
        if (cancelled) return;
        setDoc(parseDocHeader(raw));
        setLoading(false);
      },
      (err: unknown) => {
        if (cancelled) return;
        setError(err instanceof Error ? err : new Error(String(err)));
        setLoading(false);
      },
    );
    return () => {
      cancelled = true;
    };
  }, [serviceId, stem, attempt]);

  const retry = useCallback(() => setAttempt((a) => a + 1), []);

  return { doc, error, loading, path: pagePath(serviceId, stem), retry };
}
