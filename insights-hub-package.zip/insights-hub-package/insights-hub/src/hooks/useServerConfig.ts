import { useEffect, useState } from "react";
import { fetchServerConfig, type ServerConfig } from "../lib/api";

let cached: Promise<ServerConfig | null> | null = null;

/** Fetch the backend capability once per load (null = no backend / static host). */
export function useServerConfig(): ServerConfig | null {
  const [config, setConfig] = useState<ServerConfig | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (cached === null) cached = fetchServerConfig();
    cached.then((c) => {
      if (!cancelled) setConfig(c);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return config;
}
