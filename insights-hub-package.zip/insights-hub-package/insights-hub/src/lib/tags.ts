/** Split a comma-separated "Tags" input field into a clean array (trim, drop empties). */
export function parseTagsInput(value: string): string[] {
  return value
    .split(",")
    .map((t) => t.trim())
    .filter((t) => t.length > 0);
}
