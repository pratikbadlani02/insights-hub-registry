import { validateManifest, type Manifest } from "../types/manifest";

/**
 * Runtime content fetching. Everything lives under `${BASE_URL}content/` in
 * public/, so the orchestrator can drop new services in without a rebuild.
 *
 * Critical guard: static hosts (and the Vite dev server with SPA fallback)
 * answer missing files with index.html and HTTP 200 — so a plain res.ok check
 * is not enough. We sniff for HTML and treat it as "not found".
 */

export class ContentFetchError extends Error {
  readonly path: string;
  readonly reason: string;

  constructor(path: string, reason: string) {
    super(`${reason} — ${path}`);
    this.name = "ContentFetchError";
    this.path = path;
    this.reason = reason;
  }
}

const BASE = import.meta.env.BASE_URL;

export function manifestPath(): string {
  return `${BASE}content/manifest.json`;
}

export function pagePath(serviceId: string, stem: string): string {
  return `${BASE}content/services/${encodeURIComponent(serviceId)}/${encodeURIComponent(stem)}.md`;
}

function looksLikeHtmlFallback(res: Response, body: string): boolean {
  const contentType = res.headers.get("content-type") ?? "";
  if (contentType.toLowerCase().includes("text/html")) return true;
  const head = body.trimStart().slice(0, 15).toLowerCase();
  return head.startsWith("<!doctype") || head.startsWith("<html");
}

async function fetchText(path: string, init?: RequestInit): Promise<string> {
  let res: Response;
  try {
    res = await fetch(path, init);
  } catch (err) {
    throw new ContentFetchError(path, `Network error (${err instanceof Error ? err.message : String(err)})`);
  }
  if (!res.ok) {
    // The backend sends { error: "..." } with the actual cause (a GitHub API
    // failure, a bad token, an invalid registry manifest, …) — surface it
    // instead of just the status code, or troubleshooting is a guessing game.
    const detail = await res
      .clone()
      .json()
      .then((body: unknown) => (typeof body === "object" && body !== null ? (body as Record<string, unknown>).error : undefined))
      .catch(() => undefined);
    throw new ContentFetchError(path, typeof detail === "string" && detail ? `HTTP ${res.status}: ${detail}` : `HTTP ${res.status}`);
  }
  const body = await res.text();
  if (looksLikeHtmlFallback(res, body)) {
    // SPA fallback served index.html with a 200 — the file does not exist.
    throw new ContentFetchError(path, "File not found (server returned the app shell instead)");
  }
  return body;
}

export async function fetchManifest(): Promise<Manifest> {
  const path = manifestPath();
  const body = await fetchText(path, { cache: "no-cache" });
  let parsed: unknown;
  try {
    parsed = JSON.parse(body);
  } catch {
    throw new ContentFetchError(path, "Manifest is not valid JSON");
  }
  const manifest = validateManifest(parsed);
  if (manifest === null) {
    throw new ContentFetchError(path, "Manifest failed schema validation (expected schemaVersion 1 with a services array)");
  }
  return manifest;
}

export async function fetchPage(serviceId: string, stem: string): Promise<string> {
  return fetchText(pagePath(serviceId, stem));
}
