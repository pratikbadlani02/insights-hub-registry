import type { ServiceEntry } from "../types/manifest";

/**
 * Client for the hub backend's /api routes. Content itself is still fetched
 * through fetchContent.ts (unchanged); this covers registering/removing
 * projects and reading server capability so the UI can adapt.
 */

const BASE = import.meta.env.BASE_URL;

export interface ServerConfig {
  registryEnabled: boolean;
  hasToken: boolean;
  registry: { owner: string; repo: string; branch: string } | null;
}

/** True when the server can accept uploads (registry repo + token present). */
export function uploadsAvailable(cfg: ServerConfig | null): boolean {
  return Boolean(cfg?.registryEnabled && cfg?.hasToken);
}

async function readError(res: Response): Promise<string> {
  try {
    const body = await res.json();
    return body?.error || `HTTP ${res.status}`;
  } catch {
    return `HTTP ${res.status}`;
  }
}

export async function fetchServerConfig(): Promise<ServerConfig | null> {
  try {
    const res = await fetch(`${BASE}api/config`, { cache: "no-cache" });
    if (!res.ok) return null;
    return (await res.json()) as ServerConfig;
  } catch {
    return null; // static host with no backend — uploads simply unavailable
  }
}

export interface PointerPayload {
  mode: "pointer";
  repoUrl: string;
  path?: string;
  ref?: string;
  name?: string;
  stack?: string;
  archetype?: string;
  id?: string;
  tags?: string[];
}

export interface FilesPayload {
  mode: "files";
  files: { name: string; content: string }[];
  name?: string;
  stack?: string;
  archetype?: string;
  id?: string;
  tags?: string[];
}

export type AddProjectPayload = PointerPayload | FilesPayload;

export async function addProject(payload: AddProjectPayload): Promise<ServiceEntry> {
  const res = await fetch(`${BASE}api/projects`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(await readError(res));
  const body = await res.json();
  return body.entry as ServiceEntry;
}

export async function deleteProject(id: string): Promise<void> {
  const res = await fetch(`${BASE}api/projects/${encodeURIComponent(id)}`, { method: "DELETE" });
  if (!res.ok) throw new Error(await readError(res));
}

export interface ProjectEditPatch {
  name?: string;
  stack?: string;
  archetype?: string;
  skill?: string;
  tags?: string[];
}

export async function updateProject(id: string, patch: ProjectEditPatch): Promise<ServiceEntry> {
  const res = await fetch(`${BASE}api/projects/${encodeURIComponent(id)}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  });
  if (!res.ok) throw new Error(await readError(res));
  const body = await res.json();
  return body.entry as ServiceEntry;
}

/**
 * Commit a locally-generated project's pages into the shared registry repo
 * and drop the local copy, so it becomes editable/deletable like any other
 * registry-origin project. See `ServiceEntry.origin`.
 */
export async function syncProjectToRegistry(id: string): Promise<ServiceEntry> {
  const res = await fetch(`${BASE}api/projects/${encodeURIComponent(id)}/sync`, { method: "POST" });
  if (!res.ok) throw new Error(await readError(res));
  const body = await res.json();
  return body.entry as ServiceEntry;
}

// ---- Settings ---------------------------------------------------------------

export interface HubSettings {
  githubToken: string;      // "••••••••" when set, "" when absent
  githubApiBase: string;
  registryOwner: string;
  registryRepo: string;
  registryPath: string;
  registryBranch: string;
  tokenSource: "saved" | "env" | "none";
}

export const TOKEN_MASK = "••••••••";

export async function fetchHubSettings(): Promise<HubSettings | null> {
  try {
    const res = await fetch(`${BASE}api/settings`, { cache: "no-cache" });
    if (!res.ok) return null;
    return (await res.json()) as HubSettings;
  } catch {
    return null;
  }
}

export async function saveHubSettings(patch: Partial<Omit<HubSettings, "tokenSource">>): Promise<HubSettings> {
  const res = await fetch(`${BASE}api/settings`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  });
  if (!res.ok) throw new Error(await readError(res));
  return (await res.json()) as HubSettings;
}
