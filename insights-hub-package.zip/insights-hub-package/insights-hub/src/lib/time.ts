// No "week" unit on purpose: recency matters here, so 9 days reads as
// "9 days ago" rather than "last week".
const UNITS: readonly [Intl.RelativeTimeFormatUnit, number][] = [
  ["year", 365 * 24 * 3600],
  ["month", 30 * 24 * 3600],
  ["day", 24 * 3600],
  ["hour", 3600],
  ["minute", 60],
];

/** "9 days ago" — falls back to the raw string for unparseable dates. */
export function relativeTime(iso: string, now: number = Date.now()): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  const diffSeconds = (t - now) / 1000;
  const abs = Math.abs(diffSeconds);
  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  for (const [unit, seconds] of UNITS) {
    // trunc, not round: 9.7 elapsed days is still "9 days ago"
    if (abs >= seconds) return rtf.format(Math.trunc(diffSeconds / seconds), unit);
  }
  return "just now";
}

/** "Jun 28, 2026, 12:00 AM UTC" — used for title tooltips. */
export function absoluteTime(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "UTC",
  }).format(t) + " UTC";
}

/** "Jun 28, 2026" — compact date for badges. */
export function shortDate(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return new Intl.DateTimeFormat("en-US", { dateStyle: "medium", timeZone: "UTC" }).format(t);
}
