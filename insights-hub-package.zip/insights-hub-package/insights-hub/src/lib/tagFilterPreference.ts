/**
 * The catalog's tag-chip selection persists per browser, so a team can pick
 * their tag once (e.g. "team-checkout") and have the catalog open scoped to
 * it on every future visit — no separate favorites concept, just the tags
 * that already exist on each project.
 */
const STORAGE_KEY = "insights-hub:default-tags";

export function getDefaultTags(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === "string") : [];
  } catch {
    return []; // storage unavailable (private mode, quota) — filter just won't persist
  }
}

export function setDefaultTags(tags: string[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tags));
  } catch {
    /* ignore — see getDefaultTags */
  }
}
