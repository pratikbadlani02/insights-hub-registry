/**
 * Every published page opens with a header block:
 *
 *   # {Section Title}
 *   (blank line)
 *   > Project: {id}
 *   > Type: {archetype}
 *   > Skill: {spring-analysis|react-analysis}
 *   > Analyzed: {ISO-8601}
 *   (blank line)
 *   ---
 *
 * We parse & strip it so it can be rendered as a styled meta bar instead of
 * raw blockquote markdown. If the block doesn't match, the FULL raw text is
 * returned as the body — content is never dropped.
 */

export interface DocMeta {
  project?: string;
  type?: string;
  skill?: string;
  analyzed?: string;
}

export interface ParsedDoc {
  title: string | null;
  meta: DocMeta | null;
  body: string;
}

const NO_MATCH = (raw: string): ParsedDoc => ({ title: null, meta: null, body: raw });

export function parseDocHeader(raw: string): ParsedDoc {
  const lines = raw.split(/\r?\n/);
  let i = 0;

  // Optional leading blank lines.
  while (i < lines.length && lines[i]!.trim() === "") i++;

  // "# Title"
  const titleMatch = i < lines.length ? /^#[ \t]+(.+)$/.exec(lines[i]!) : null;
  if (!titleMatch) return NO_MATCH(raw);
  const title = titleMatch[1]!.trim();
  i++;

  // At least one blank line.
  const blankStart = i;
  while (i < lines.length && lines[i]!.trim() === "") i++;
  if (i === blankStart) return NO_MATCH(raw);

  // One or more "> Key: value" lines. Keys are case-insensitive.
  const meta: DocMeta = {};
  let quoteLines = 0;
  while (i < lines.length && lines[i]!.startsWith(">")) {
    const m = /^>[ \t]*([A-Za-z][A-Za-z ]*?)[ \t]*:[ \t]*(.*)$/.exec(lines[i]!);
    if (m) {
      const key = m[1]!.trim().toLowerCase();
      const value = m[2]!.trim();
      if (key === "project") meta.project = value;
      else if (key === "type") meta.type = value;
      else if (key === "skill") meta.skill = value;
      else if (key === "analyzed") meta.analyzed = value;
    }
    quoteLines++;
    i++;
  }
  if (quoteLines === 0) return NO_MATCH(raw);

  // The blockquote must actually look like a doc header (at least one known
  // key). Otherwise it's an ordinary callout — fall through to NO_MATCH so
  // content is never dropped.
  if (
    meta.project === undefined &&
    meta.type === undefined &&
    meta.skill === undefined &&
    meta.analyzed === undefined
  ) {
    return NO_MATCH(raw);
  }

  // Optional blank lines, then the "---" rule that closes the header.
  while (i < lines.length && lines[i]!.trim() === "") i++;
  if (i >= lines.length || !/^-{3,}[ \t]*$/.test(lines[i]!)) return NO_MATCH(raw);
  i++;

  const body = lines.slice(i).join("\n").replace(/^\n+/, "");
  return { title, meta, body };
}
