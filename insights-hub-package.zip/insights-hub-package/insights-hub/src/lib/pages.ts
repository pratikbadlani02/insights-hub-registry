import type { ServiceEntry } from "../types/manifest";

/** stem ↔ route slug ↔ display title, per the shared contract. */
export interface PageDef {
  stem: string;
  slug: string;
  title: string;
}

export const PAGE_REGISTRY: readonly PageDef[] = [
  // Spring (java-spring-backend-analysis) stems
  { stem: "00-overview", slug: "overview", title: "Overview" },
  { stem: "01-architecture", slug: "architecture", title: "Architecture" },
  { stem: "02-entry-points", slug: "entry-points", title: "Entry Points" },
  { stem: "03-business-rules", slug: "business-rules", title: "Business Rules" },
  { stem: "04-data-model", slug: "data-model", title: "Data Model" },
  { stem: "05-dependencies", slug: "dependencies", title: "Dependencies" },
  { stem: "06-interactions", slug: "interactions", title: "Interactions" },
  { stem: "07-data-flow", slug: "data-flow", title: "Data Flow" },
  { stem: "08-error-handling", slug: "error-handling", title: "Error Handling" },
  { stem: "09-deployment", slug: "deployment", title: "Deployment" },
  // React (react-frontend-analysis) stems — differ from Spring at 02/03/06/07
  { stem: "02-routing-and-navigation", slug: "routing-and-navigation", title: "Routing And Navigation" },
  { stem: "03-access-and-rules", slug: "access-and-rules", title: "Access And Rules" },
  { stem: "06-runtime-flows", slug: "runtime-flows", title: "Runtime Flows" },
  { stem: "07-state-and-data-fetching", slug: "state-and-data-fetching", title: "State And Data Fetching" },
];

/** Derive a sensible slug/title for a stem the registry doesn't know. */
function pageDefFromStem(stem: string): PageDef {
  const slug = stem.replace(/^\d+-/, "") || stem;
  const title = slug
    .split("-")
    .map((w) => (w ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(" ");
  return { stem, slug, title };
}

/**
 * The pages a service actually publishes, in manifest order.
 * The viewer never assumes a fixed set (Spring = 10 pages, React = 9, and
 * future stems must not break navigation).
 */
export function pagesForService(entry: ServiceEntry): PageDef[] {
  return entry.pages.map(
    (stem) => PAGE_REGISTRY.find((p) => p.stem === stem) ?? pageDefFromStem(stem),
  );
}

/** Default page = first entry of the service's pages[]. */
export function defaultPage(entry: ServiceEntry): PageDef {
  return pagesForService(entry)[0] ?? pageDefFromStem("00-overview");
}

export type SlugResolution =
  /** Slug maps to a page this service publishes. */
  | { kind: "found"; page: PageDef }
  /** Slug is a known registry slug, but not part of this service's set. */
  | { kind: "not-in-service"; page: PageDef }
  /** Slug matches nothing we know about. */
  | { kind: "unknown-slug" };

export function resolveSlug(entry: ServiceEntry, slug: string): SlugResolution {
  const inService = pagesForService(entry).find((p) => p.slug === slug);
  if (inService) return { kind: "found", page: inService };
  const inRegistry = PAGE_REGISTRY.find((p) => p.slug === slug);
  if (inRegistry) return { kind: "not-in-service", page: inRegistry };
  return { kind: "unknown-slug" };
}
