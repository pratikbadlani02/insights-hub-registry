# Insights Hub

A Vite + React + TypeScript single-page app for browsing reverse-engineered service
documentation. Services are analyzed by the `spring-boot-service-analysis` /
`react-frontend-analysis` skills, published into `public/content/` by the
`insights-hub-generator` skill, and rendered here — catalog, per-service page
navigation, GFM tables, syntax highlighting, and rendered Mermaid diagrams, with
light/dark themes.

## Run it

```bash
npm install        # once
npm run dev        # dev: Vite on :5173 + backend on :8787 (auto-spawned)
npm run build      # type-check (tsc) + production bundle in dist/
npm start          # prod: backend serves dist/ + /content + /api on one origin
npm run preview    # serve the static build only (no backend)
```

`npm run dev` starts the backend automatically as a child of Vite and proxies
`/content` and `/api` to it — a single command, unchanged flags. Copy
`.env.example` to `.env` to configure the registry repo and GitHub token (see
[Backend & runtime uploads](#backend--runtime-uploads)); without it the app
still runs and serves the seeded sample.

## How content gets in (no rebuild required)

Documentation is resolved at **runtime** by the backend — nothing in `src/`
imports it, so publishing a project never needs a rebuild or redeploy. Two
sources are merged into one catalog:

1. **Local sample** — `public/content/` (the seeded `spring-petclinic`), served
   directly by the backend. The `insights-hub-generator` skill still publishes
   here for local development.
2. **Registry of pointers** — a common `manifest.json` in a GitHub repo (the
   registry). Each entry points at a GitHub location (`owner`/`repo`/`path`/`ref`)
   where that project's markdown lives; the backend fetches pages from there on
   demand. This is what the **"+ Add project"** button writes to — instantly
   visible to everyone on the shared hub, no redeploy.

```
public/content/                    # local sample (dev)
├── manifest.json
└── services/<id>/
    ├── 00-overview.md             # Spring services: 00…09 (10 pages)
    ├── 01-architecture.md         # React services: 01…09 (9 pages, no 00)
    └── …

<registry-repo>/manifest.json      # shared registry of pointers (runtime)
```

The viewer's fetch contract is unchanged — it still requests
`content/manifest.json` and `content/services/<id>/<stem>.md`; those paths are
now answered by the backend instead of by static files.

## Backend & runtime uploads

`server/` is a small Express app (Node 20+, deps: `express`, `dotenv`; GitHub
access via native `fetch`). Routes:

| Route | Purpose |
|---|---|
| `GET /content/manifest.json` | Effective manifest: local ∪ registry (registry wins on id) |
| `GET /content/services/:id/:stem.md` | Resolve the service's source → fetch the page (local file or GitHub) |
| `GET /api/config` | Whether uploads are available (registry repo + token present) |
| `POST /api/projects` | Register a project — `mode: "pointer"` (GitHub location) or `mode: "files"` (uploaded `.md`) |
| `DELETE /api/projects/:id` | Unregister a project from the registry |

Uploads commit to the registry repo through the GitHub Contents API using the
server's token, retrying on a stale-`sha` conflict so concurrent uploads don't
clobber each other.

### Configuration

Settings are managed through the **in-app Settings page** (`/settings` — gear
icon in the top bar). Changes take effect immediately with no server restart.
Settings are persisted to a JSON file on the server (path from `SETTINGS_FILE`
env var, default `./data/settings.json`).

For local dev, values can also be set in `.env` (see `.env.example`). Settings
saved via the UI take priority over `.env` values.

| Setting | Meaning |
|---|---|
| GitHub token | Write access to the registry repo; read access to pointed-at repos |
| GitHub API base | Default `https://api.github.com`; change for GitHub Enterprise |
| Registry owner / repo | The common registry repo on github.com |
| Registry branch | Default `main` |
| Registry path | Manifest file path in the registry repo; default `manifest.json` |

If the registry isn't configured the app runs read-only on the local sample and
the "+ Add project" button is hidden.

## The manifest contract (schemaVersion 1)

`public/content/manifest.json` is the single contract between the generator and
this viewer — the seeded file in this repo is the reference example. Shape:

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-07-07T15:30:00Z",
  "generator": "insights-hub-generator@1.0.0",
  "services": [
    {
      "id": "spring-petclinic",
      "name": "Spring PetClinic",
      "stack": "java-spring",
      "archetype": "rest-api",
      "skill": "spring-analysis",
      "analyzedAt": "2026-06-28T00:00:00Z",
      "pages": ["00-overview", "01-architecture", "…"],
      "source": { "type": "local", "path": "/abs/path", "repoUrl": null }
    }
  ]
}
```

- `id` — URL-safe kebab-case slug; **must equal** the folder name under
  `content/services/`.
- `stack` — `"java-spring" | "react"`; `archetype` — `rest-api | kafka-consumer |
  batch | gateway | react-spa | react-mfe` (unknown values render with a neutral
  badge instead of breaking); `skill` — `spring-analysis | react-analysis`.
- `pages` — the file stems (no `.md`) actually present, in order. The viewer
  never assumes a fixed set; the first entry is the service's default page.
- Types + validation live in `src/types/manifest.ts`; the stem ↔ URL slug ↔
  title registry lives in `src/lib/pages.ts`.

Every published page opens with a header block (`# Title`, then `> Project:` /
`> Type:` / `> Skill:` / `> Analyzed:` quotes, then `---`) which the viewer
strips and renders as a meta badge bar. Pages without the block render as-is.

## Routes

| Route | Renders |
|---|---|
| `/` | Catalog: search + stack/archetype filter chips |
| `/help` | User guide: browsing + how to add a project (linked from the top bar) |
| `/services/:serviceId` | Redirect to the service's default page |
| `/services/:serviceId/:pageSlug` | Sidebar nav + rendered doc (e.g. `/services/spring-petclinic/data-model`) |
| `*` | Not found |

## Deployment notes

**Recommended: run the backend in production.** `npm run build` then `npm start`
serves the built SPA, `/content`, and `/api` from one origin (the backend's
catch-all route handles SPA deep-link fallback for you). Set the same `.env`
vars in the deploy environment. Runtime uploads require this — a content-only
static host (below) can render docs but cannot accept uploads.

**SPA fallback / HashRouter.** Deep links like `/services/x/overview` require
the host to rewrite unknown paths to `index.html` (the dev server and most SPA
hosts do). On a static host **without** rewrite support, switch to hash-based
URLs: in `src/main.tsx` replace `BrowserRouter` with `HashRouter` (same
`react-router-dom` import) — URLs become `/#/services/x/overview` and need no
server config. Related guard: because SPA fallbacks answer missing files with
`index.html` + HTTP 200, `src/lib/fetchContent.ts` sniffs HTML responses and
treats them as "file not found" — keep that if you touch content fetching.

**Sub-path deploys (Vite `base`).** To serve the app from a sub-path (e.g.
GitHub Pages at `https://host/insights-hub/`), set `base` in `vite.config.ts`:

```ts
export default defineConfig({
  base: "/insights-hub/",
  plugins: [react()],
});
```

Content fetching already uses `import.meta.env.BASE_URL`, so `content/…` URLs
follow the base automatically. No other changes needed.
