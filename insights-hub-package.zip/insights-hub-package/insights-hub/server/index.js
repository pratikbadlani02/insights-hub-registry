/**
 * Insights Hub backend. Two jobs:
 *   1. Serve /content/* by resolving the registry-of-pointers manifest and
 *      fetching each service's markdown from its GitHub location (or the local
 *      sample). The viewer's fetch contract is unchanged.
 *   2. Expose /api/projects so anyone on the shared hub can register a new
 *      project (by GitHub pointer or by uploading files) without a redeploy.
 */

import "dotenv/config";
import express from "express";
import path from "node:path";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

import { getRawText, listDir, getFile, putFile, deleteFile, getDefaultBranch, assertRepoAccess, hasToken } from "./github.js";
import {
  effectiveManifest,
  readRegistry,
  updateRegistry,
  registryConfig,
  registryEnabled,
} from "./registry.js";
import {
  parseHeaderBlock,
  hasValidHeader,
  injectHeaderIfMissing,
  stemsFromFilenames,
  stackFromStems,
  normalizeTags,
  buildEntry,
  kebab,
} from "./docset.js";
import { writeSettings, publicSettings, TOKEN_MASK } from "./settings.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const PORT = Number(process.env.PORT || 8787);
const LOCAL_CONTENT_DIR = process.env.LOCAL_CONTENT_DIR || path.join(ROOT, "public", "content");
const DIST_DIR = process.env.DIST_DIR || path.join(ROOT, "dist");
const CONTENT_CACHE_TTL_MS = Number(process.env.CONTENT_CACHE_TTL_MS || 10_000);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "*";

const app = express();
app.use(express.json({ limit: "25mb" }));

// Minimal CORS so a split-origin dev/deploy works; same-origin needs nothing.
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", ALLOWED_ORIGIN);
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// ---- Effective-manifest cache (short TTL; invalidated on every write) --------
let manifestCache = { value: null, expires: 0 };

async function getManifest() {
  const now = cacheClock();
  if (manifestCache.value && manifestCache.expires > now) return manifestCache.value;
  const manifest = await effectiveManifest(LOCAL_CONTENT_DIR);
  manifestCache = { value: manifest, expires: now + CONTENT_CACHE_TTL_MS };
  return manifest;
}

function invalidateManifest() {
  manifestCache = { value: null, expires: 0 };
}

// Date.now via a helper so the intent (cache TTL only) is explicit.
function cacheClock() {
  return Date.now();
}

// ---- Content routes (the viewer's fetch contract) ---------------------------

app.get("/content/manifest.json", async (_req, res) => {
  try {
    const manifest = await getManifest();
    // Strip the internal _origin tag before handing it to the viewer.
    const services = manifest.services.map(({ _origin, ...s }) => s);
    res.type("application/json").send(JSON.stringify({ ...manifest, services }, null, 2));
  } catch (err) {
    res.status(502).json({ error: String(err?.message ?? err) });
  }
});

app.get("/content/services/:id/:file", async (req, res) => {
  const { id, file } = req.params;
  if (!file.toLowerCase().endsWith(".md")) return res.status(404).send("Not found");
  try {
    const manifest = await getManifest();
    const svc = manifest.services.find((s) => s.id === id);
    if (!svc) return res.status(404).send("Unknown service");

    if (svc._origin === "local") {
      const abs = path.join(LOCAL_CONTENT_DIR, "services", id, file);
      if (!abs.startsWith(path.join(LOCAL_CONTENT_DIR, "services"))) {
        return res.status(400).send("Bad path");
      }
      const text = await readFile(abs, "utf8").catch(() => null);
      if (text === null) return res.status(404).send("Page not found");
      return res.type("text/markdown").send(text);
    }

    const src = svc.source || {};
    if (src.type !== "github" || !src.owner || !src.repo) {
      return res.status(502).send("Service has no resolvable GitHub source");
    }
    const filePath = [src.path, file].filter(Boolean).join("/");
    const text = await getRawText(src.owner, src.repo, filePath, src.ref);
    if (text === null) return res.status(404).send("Page not found in source repo");
    res.type("text/markdown").send(text);
  } catch (err) {
    res.status(502).json({ error: String(err?.message ?? err) });
  }
});

// ---- Config route (drives the UI's add-project affordance) ------------------

app.get("/api/config", (_req, res) => {
  const c = registryConfig();
  res.json({
    registryEnabled: registryEnabled(),
    hasToken: hasToken(),
    registry: registryEnabled() ? { owner: c.owner, repo: c.repo, branch: c.branch } : null,
  });
});

// ---- Settings routes ---------------------------------------------------------

app.get("/api/settings", (_req, res) => {
  res.json(publicSettings());
});

app.post("/api/settings", (req, res) => {
  try {
    const body = req.body || {};
    const patch = {};

    // Only accept known keys; ignore everything else.
    for (const key of ["githubApiBase", "registryOwner", "registryRepo", "registryPath", "registryBranch"]) {
      if (typeof body[key] === "string") patch[key] = body[key].trim();
    }

    // Token: save only when a non-empty, non-mask value is supplied.
    if (typeof body.githubToken === "string" && body.githubToken.trim() && body.githubToken !== TOKEN_MASK) {
      patch.githubToken = body.githubToken.trim();
    } else if (body.githubToken === "") {
      // Explicit empty string means "clear the saved token" (fall back to env var).
      patch.githubToken = "";
    }
    // Mask value → leave existing token untouched (don't write anything for token).

    writeSettings(patch);
    invalidateManifest(); // registry owner/repo may have changed
    res.json(publicSettings());
  } catch (err) {
    res.status(400).json({ error: String(err?.message ?? err) });
  }
});

// ---- Register a project (pointer mode or file-upload mode) ------------------

app.post("/api/projects", async (req, res) => {
  try {
    const body = req.body || {};
    const mode = body.mode === "files" ? "files" : "pointer";
    const nowIso = new Date().toISOString();

    if (!registryEnabled()) {
      return res.status(503).json({ error: "Registry repo not configured on the server." });
    }
    if (!hasToken()) {
      return res.status(503).json({ error: "Server has no GITHUB_TOKEN configured." });
    }

    const result = mode === "files"
      ? await registerFromFiles(body, nowIso)
      : await registerFromPointer(body, nowIso);

    invalidateManifest();
    res.status(201).json({ entry: result });
  } catch (err) {
    res.status(err?.httpStatus || 400).json({ error: String(err?.message ?? err) });
  }
});

app.delete("/api/projects/:id", async (req, res) => {
  try {
    if (!registryEnabled() || !hasToken()) {
      return res.status(503).json({ error: "Registry not configured on the server." });
    }
    const id = req.params.id;
    const { manifest } = await readRegistry();
    const entry = manifest.services.find((s) => s.id === id);
    if (!entry) {
      return res.status(404).json({ error: `No registry entry for "${id}".` });
    }

    // Delete the underlying pages too, but only when they live in the registry
    // repo itself — i.e. this hub committed them there (file-upload mode, or
    // pointer mode that had to inject headers). A pointer-mode service still
    // reading an external repo in place is never written to or deleted from.
    const c = registryConfig();
    const src = entry.source || {};
    if (src.type === "github" && src.owner === c.owner && src.repo === c.repo) {
      for (const stem of entry.pages || []) {
        const filePath = `${src.path}/${stem}.md`;
        const existing = await getFile(c.owner, c.repo, filePath, src.ref || c.branch);
        if (existing) {
          await deleteFile(c.owner, c.repo, filePath, {
            message: `hub: delete ${id}/${stem}.md`,
            sha: existing.sha,
            branch: src.ref || c.branch,
          });
        }
      }
    }

    let removed = false;
    await updateRegistry(
      (m) => {
        const before = m.services.length;
        m.services = m.services.filter((s) => s.id !== id);
        removed = m.services.length < before;
        return m;
      },
      { message: `hub: unregister ${id}`, nowIso: new Date().toISOString() },
    );
    invalidateManifest();
    if (!removed) return res.status(404).json({ error: `No registry entry for "${id}".` });
    res.json({ removed: id });
  } catch (err) {
    res.status(400).json({ error: String(err?.message ?? err) });
  }
});

app.patch("/api/projects/:id", async (req, res) => {
  try {
    if (!registryEnabled() || !hasToken()) {
      return res.status(503).json({ error: "Registry not configured on the server." });
    }
    const id = req.params.id;
    const patch = pickEditableFields(req.body || {});
    if (Object.keys(patch).length === 0) {
      return res.status(400).json({ error: "Nothing to update — supply name, stack, archetype, skill, or tags." });
    }
    let updated = null;
    await updateRegistry(
      (m) => {
        const idx = m.services.findIndex((s) => s.id === id);
        if (idx === -1) return m;
        m.services[idx] = { ...m.services[idx], ...patch };
        updated = m.services[idx];
        return m;
      },
      { message: `hub: update ${id}`, nowIso: new Date().toISOString() },
    );
    invalidateManifest();
    if (updated === null) {
      return res.status(404).json({ error: `No registry entry for "${id}" (seeded/local services can't be edited here).` });
    }
    res.json({ entry: updated });
  } catch (err) {
    res.status(400).json({ error: String(err?.message ?? err) });
  }
});

// ---- Registration helpers ---------------------------------------------------

/** Editing never touches id/pages/source/analyzedAt — only display metadata. */
function pickEditableFields(body) {
  const out = {};
  for (const key of ["name", "stack", "archetype", "skill"]) {
    if (typeof body[key] === "string" && body[key].trim()) out[key] = body[key].trim();
  }
  // Tags are array-valued and `[]` is a meaningful edit (clear all tags), so
  // they can't share the string loop's "empty means not provided" rule.
  if (Array.isArray(body.tags)) out.tags = normalizeTags(body.tags);
  return out;
}

function fail(status, message) {
  const err = new Error(message);
  err.httpStatus = status;
  return err;
}

function parseRepo(input) {
  if (!input) throw fail(400, "A GitHub repo URL or owner/repo is required.");
  const cleaned = String(input).trim().replace(/\.git$/, "");
  const url = cleaned.match(/github\.com[/:]([^/]+)\/([^/]+)/i);
  if (url) return { owner: url[1], repo: url[2] };
  const slug = cleaned.match(/^([^/\s]+)\/([^/\s]+)$/);
  if (slug) return { owner: slug[1], repo: slug[2] };
  throw fail(400, `Could not parse a GitHub repo from "${input}".`);
}

async function registerFromPointer(body, nowIso) {
  const { owner, repo } = parseRepo(body.repoUrl || body.repo);
  const docPath = (body.path || "").replace(/^\/+|\/+$/g, "");

  // Pre-flight: verify the source repo is readable before listing files.
  await assertRepoAccess(owner, repo);

  let ref = body.ref || (await getDefaultBranch(owner, repo)) || "main";

  const entries = await listDir(owner, repo, docPath, ref);
  const stems = stemsFromFilenames(entries.filter((e) => e.type === "file").map((e) => e.name));
  if (stems.length === 0) {
    throw fail(404, `No markdown files found at ${owner}/${repo}/${docPath || "."} @ ${ref}.`);
  }

  // Fetch every page up front — needed either to read an existing header or to
  // inject one. Raw analysis-skill output (e.g. react-frontend-analysis, which
  // emits no header block by spec) has none, so pointer mode must inject just
  // like file-upload mode does — it must not just reject it.
  const pages = [];
  for (const stem of stems) {
    const filePath = [docPath, `${stem}.md`].filter(Boolean).join("/");
    const md = await getRawText(owner, repo, filePath, ref);
    if (md === null) throw fail(404, `${stem}.md not found at ${owner}/${repo}/${docPath || "."} @ ${ref}.`);
    pages.push({ stem, content: md });
  }

  const firstWithHeader = pages.find((p) => hasValidHeader(p.content));
  const earlyHeader = firstWithHeader ? parseHeaderBlock(firstWithHeader.content) : {};
  const overrides = pickOverrides(body);
  const id = kebab(overrides.id || earlyHeader.project || overrides.name || "");
  if (!id) {
    throw fail(400, "Could not determine a project id — the source pages have no header block; supply an id or name.");
  }
  // Page stems are the strongest signal when nothing else is known — a
  // react-frontend-analysis set has none of these fields, but its filenames
  // (e.g. `02-routing-and-navigation.md`) are unambiguous.
  const inferredStack = overrides.stack || stackFromStems(stems);
  const archetype = overrides.archetype || earlyHeader.type || (inferredStack === "react" ? "react-spa" : "rest-api");
  const skill     = overrides.skill     || earlyHeader.skill || (inferredStack === "react" ? "react-analysis" : "spring-analysis");
  const tags      = normalizeTags(overrides.tags !== undefined ? overrides.tags : earlyHeader.tags);

  // Inject the standard header block into any page missing one, then re-validate.
  const prepared = pages.map((p) => ({
    ...p,
    content: injectHeaderIfMissing(p.content, { id, archetype, skill, analyzedAt: nowIso, stem: p.stem, tags }),
  }));
  const stillInvalid = prepared.filter((p) => !hasValidHeader(p.content)).map((p) => `${p.stem}.md`);
  if (stillInvalid.length > 0) {
    throw fail(422, `Could not inject a valid header block into: ${stillInvalid.join(", ")}`);
  }
  const header = parseHeaderBlock(prepared.find((p) => hasValidHeader(p.content)).content);

  let source;
  const anyInjected = prepared.some((p, i) => p.content !== pages[i].content);
  if (anyInjected) {
    // Headers had to be injected — never write them back into the external
    // source repo. Commit the normalized copies into the registry repo
    // (same place file-upload mode writes to) and point the manifest there.
    const c = registryConfig();
    await assertRepoAccess(c.owner, c.repo, { write: true });
    for (const p of prepared) {
      const filePath = `services/${id}/${p.stem}.md`;
      const existing = await getFile(c.owner, c.repo, filePath, c.branch);
      await putFile(c.owner, c.repo, filePath, {
        message: `hub: upload ${id}/${p.stem}.md`,
        text: p.content,
        sha: existing?.sha,
        branch: c.branch,
      });
    }
    source = {
      type: "github",
      owner: c.owner,
      repo: c.repo,
      path: `services/${id}`,
      ref: c.branch,
      repoUrl: `https://github.com/${c.owner}/${c.repo}`,
    };
  } else {
    source = {
      type: "github",
      owner,
      repo,
      path: docPath,
      ref,
      repoUrl: `https://github.com/${owner}/${repo}`,
    };
  }

  const entry = buildEntry({ overrides, header, pages: stems, source, nowIso });
  return upsert(entry, nowIso);
}

async function registerFromFiles(body, nowIso) {
  const files = Array.isArray(body.files) ? body.files : [];
  const md = files.filter(
    (f) => f && typeof f.name === "string" && typeof f.content === "string" && f.name.toLowerCase().endsWith(".md"),
  );
  if (md.length === 0) throw fail(400, "No markdown files were uploaded.");

  const stems = stemsFromFilenames(md.map((f) => f.name));

  // Derive the project id as early as possible so we can inject headers on
  // files that are missing them (raw analysis-skill output has no header block;
  // the generator normally injects it on copy, but file-drop upload skips that).
  const firstWithHeader = md.find((f) => hasValidHeader(f.content));
  const earlyHeader = firstWithHeader ? parseHeaderBlock(firstWithHeader.content) : {};
  const id = kebab(body.id || earlyHeader.project || body.name || "");
  if (!id) {
    throw fail(400, "Could not determine a project id — supply a Name or ID in the metadata fields.");
  }

  // Resolve metadata that will be used for header injection. Page stems are
  // the strongest signal when nothing else is known (see registerFromPointer).
  const overrides = pickOverrides(body);
  const inferredStack = overrides.stack || stackFromStems(stems);
  const archetype = overrides.archetype || earlyHeader.type || (inferredStack === "react" ? "react-spa" : "rest-api");
  const skill     = overrides.skill     || earlyHeader.skill || (inferredStack === "react" ? "react-analysis" : "spring-analysis");
  const tags      = normalizeTags(overrides.tags !== undefined ? overrides.tags : earlyHeader.tags);

  // Inject the standard header block into any file that is missing one, then
  // re-validate. Files that already have a header are left untouched.
  const prepared = md.map((f) => {
    const stem = f.name.replace(/\.md$/i, "");
    const content = injectHeaderIfMissing(f.content, { id, archetype, skill, analyzedAt: nowIso, stem, tags });
    return { ...f, content };
  });

  const stillInvalid = prepared.filter((f) => !hasValidHeader(f.content)).map((f) => f.name);
  if (stillInvalid.length > 0) {
    throw fail(422, `Could not inject a valid header block into: ${stillInvalid.join(", ")}`);
  }

  const header = parseHeaderBlock(prepared.find((f) => hasValidHeader(f.content)).content);

  const c = registryConfig();

  // Pre-flight: verify the registry repo is reachable and the token has write
  // access before committing any files. getFile() returns null on 404 whether
  // the file or the entire repo is missing, so without this check a bad token
  // or wrong repo name causes a cryptic 404 on the first file path.
  await assertRepoAccess(c.owner, c.repo, { write: true });

  // Commit each file (with injected headers where needed) into the registry repo.
  for (const f of prepared) {
    const filePath = `services/${id}/${path.basename(f.name)}`;
    const existing = await getFile(c.owner, c.repo, filePath, c.branch);
    await putFile(c.owner, c.repo, filePath, {
      message: `hub: upload ${id}/${f.name}`,
      text: f.content,
      sha: existing?.sha,
      branch: c.branch,
    });
  }

  const source = {
    type: "github",
    owner: c.owner,
    repo: c.repo,
    path: `services/${id}`,
    ref: c.branch,
    repoUrl: `https://github.com/${c.owner}/${c.repo}`,
  };
  const entry = buildEntry({ overrides, header, pages: stems, source, nowIso });
  return upsert(entry, nowIso);
}

function pickOverrides(body) {
  const { id, name, stack, archetype, skill, analyzedAt, tags } = body;
  return { id, name, stack, archetype, skill, analyzedAt, tags: Array.isArray(tags) ? tags : undefined };
}

async function upsert(entry, nowIso) {
  await updateRegistry(
    (m) => {
      m.services = m.services.filter((s) => s.id !== entry.id);
      m.services.push(entry);
      return m;
    },
    { message: `hub: register ${entry.id}`, nowIso },
  );
  return entry;
}

// ---- Static app + SPA fallback (production) ---------------------------------

app.use(express.static(DIST_DIR));
app.get(/^(?!\/(api|content)).*/, async (_req, res) => {
  const indexHtml = path.join(DIST_DIR, "index.html");
  const html = await readFile(indexHtml, "utf8").catch(() => null);
  if (html === null) {
    return res
      .status(404)
      .send("Built app not found. Run `npm run build`, or use `npm run dev` for development.");
  }
  res.type("text/html").send(html);
});

app.listen(PORT, () => {
  console.log(`[insights-hub] server on http://localhost:${PORT}`);
  console.log(`[insights-hub] registry: ${registryEnabled() ? `${registryConfig().owner}/${registryConfig().repo}@${registryConfig().branch}` : "NOT CONFIGURED (configure via /settings)"}`);
  console.log(`[insights-hub] github token: ${hasToken() ? "present" : "MISSING"}`);
});
