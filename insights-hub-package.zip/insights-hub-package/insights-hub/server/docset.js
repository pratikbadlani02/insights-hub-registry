/**
 * Doc-set rules shared with the insights-hub-generator skill: every page opens
 * with a `# Title` heading followed by a `> Project:` header block. We reuse
 * that block to auto-derive a manifest entry when the uploader omits metadata.
 */

const KNOWN_STACKS = ["java-spring", "react"];

/** Parse the `> Key: value` header block from a markdown page. */
export function parseHeaderBlock(markdown) {
  const out = {};
  const lines = markdown.split(/\r?\n/).slice(0, 15);
  for (const line of lines) {
    const m = /^>\s*([A-Za-z]+)\s*:\s*(.+?)\s*$/.exec(line);
    if (m) out[m[1].toLowerCase()] = m[2];
  }
  return out; // e.g. { project, type, skill, analyzed }
}

/** SETUP's page-OK rule: a `# ` heading plus a `> Project:` line up top. */
export function hasValidHeader(markdown) {
  const head = markdown.trimStart().slice(0, 15).toLowerCase();
  if (head.startsWith("<!doctype") || head.startsWith("<html")) return false;
  const lines = markdown.split(/\r?\n/).slice(0, 12);
  const hasTitle = lines.some((l) => /^#\s+\S/.test(l));
  const hasProject = lines.some((l) => /^>\s*Project\s*:/i.test(l));
  return hasTitle && hasProject;
}

/**
 * Standard page registry (stem → display title). Mirrors src/lib/pages.ts so
 * both the viewer and the server agree on titles.
 */
const PAGE_TITLES = {
  // Spring (java-spring-backend-analysis) stems
  "00-overview":       "Overview",
  "01-architecture":   "Architecture",
  "02-entry-points":   "Entry Points",
  "03-business-rules": "Business Rules",
  "04-data-model":     "Data Model",
  "05-dependencies":   "Dependencies",
  "06-interactions":   "Interactions",
  "07-data-flow":      "Data Flow",
  "08-error-handling": "Error Handling",
  "09-deployment":     "Deployment",
  // React (react-frontend-analysis) stems — differ from Spring at 02/03/06/07
  "02-routing-and-navigation":  "Routing And Navigation",
  "03-access-and-rules":        "Access And Rules",
  "06-runtime-flows":           "Runtime Flows",
  "07-state-and-data-fetching": "State And Data Fetching",
};

/** Derive a human title from any stem (known or non-standard). */
function stemToTitle(stem) {
  if (PAGE_TITLES[stem]) return PAGE_TITLES[stem];
  // Strip leading digits block (e.g. "02-routing-and-navigation" → "routing-and-navigation")
  const slug = stem.replace(/^\d+-/, "") || stem;
  return slug.split("-").map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w)).join(" ");
}

/**
 * Inject the standard header block into a page that is missing one.
 * The generator skill does this for React analysis output; we replicate
 * it here so file-drop uploads work even for raw skill output.
 */
export function injectHeaderIfMissing(markdown, { id, archetype, skill, analyzedAt, stem, tags }) {
  if (hasValidHeader(markdown)) return markdown;
  const title = stemToTitle(stem);
  const tagsLine = Array.isArray(tags) && tags.length > 0 ? `> Tags: ${tags.join(", ")}\n` : "";
  const block = `# ${title}\n\n> Project: ${id}\n> Type: ${archetype}\n> Skill: ${skill}\n> Analyzed: ${analyzedAt}\n${tagsLine}\n---\n\n`;
  // Drop any pre-existing top-level heading — the block above supplies the
  // canonical title — then prepend the header block to the rest of the body.
  const firstHeading = /^#\s+.+\n+/.exec(markdown);
  const body = firstHeading ? markdown.slice(firstHeading[0].length) : markdown;
  return block + body;
}

/** Markdown filenames → ordered stems (numeric-aware, e.g. 02 before 10). */
export function stemsFromFilenames(names) {
  return names
    .filter((n) => n.toLowerCase().endsWith(".md"))
    .map((n) => n.replace(/\.md$/i, ""))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
}

export function stackFromSkillOrArchetype(skill, archetype) {
  const s = (skill || "").toLowerCase();
  if (s.includes("react")) return "react";
  if (s.includes("spring")) return "java-spring";
  const a = (archetype || "").toLowerCase();
  if (a.startsWith("react")) return "react";
  return "java-spring";
}

/** Stems only `react-frontend-analysis` ever produces — proof the set is React. */
const REACT_ONLY_STEMS = new Set([
  "02-routing-and-navigation",
  "03-access-and-rules",
  "06-runtime-flows",
  "07-state-and-data-fetching",
]);

/**
 * Infer the stack from the page stems alone, for doc sets with no header and
 * no explicit override. React sets never include `00-overview` and Spring
 * sets always do, so that absence is a secondary signal; a React-only stem is
 * conclusive. Falls back to `java-spring` only when neither signal fires.
 */
export function stackFromStems(stems) {
  const list = Array.isArray(stems) ? stems : [];
  if (list.some((s) => REACT_ONLY_STEMS.has(s))) return "react";
  if (list.length > 0 && !list.includes("00-overview")) return "react";
  return "java-spring";
}

/**
 * Normalize tags to a de-duplicated array of lowercase, trimmed strings.
 * Accepts either an array (from the UI) or a comma-separated string (from a
 * parsed `> Tags:` header line) so both entry points share one rule.
 */
export function normalizeTags(value) {
  const list = Array.isArray(value) ? value : typeof value === "string" ? value.split(",") : [];
  const seen = new Set();
  for (const raw of list) {
    const tag = String(raw).trim().toLowerCase();
    if (tag) seen.add(tag);
  }
  return [...seen];
}

export function kebab(value) {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/**
 * Build a validated manifest entry from derived + user-supplied fields.
 * `overrides` (from the request body) win over `header`-derived values.
 * Returns { entry } or throws Error with a user-facing message.
 */
export function buildEntry({ overrides, header, pages, source, nowIso }) {
  const id = kebab(overrides.id || header.project || overrides.name || "");
  if (!id) throw new Error("Could not determine a project id — supply `id` or `name`.");
  if (!Array.isArray(pages) || pages.length === 0) {
    throw new Error("Doc set has no markdown pages.");
  }
  const skill = overrides.skill || header.skill || "";
  const archetype = overrides.archetype || header.type || "";
  // Only trust skill/archetype for stack inference when at least one was
  // actually supplied — otherwise stackFromSkillOrArchetype's own fallback
  // would silently claim java-spring. Page stems are stronger evidence.
  const stack =
    overrides.stack ||
    (skill || archetype ? stackFromSkillOrArchetype(skill, archetype) : stackFromStems(pages));
  if (!KNOWN_STACKS.includes(stack)) {
    // tolerated by the viewer, but warn the caller it's non-standard
  }
  return {
    id,
    name: overrides.name || header.project || id,
    stack,
    archetype: archetype || (stack === "react" ? "react-spa" : "rest-api"),
    skill: skill || (stack === "react" ? "react-analysis" : "spring-analysis"),
    analyzedAt: overrides.analyzedAt || header.analyzed || nowIso,
    pages,
    tags: normalizeTags(overrides.tags !== undefined ? overrides.tags : header.tags),
    source,
  };
}
