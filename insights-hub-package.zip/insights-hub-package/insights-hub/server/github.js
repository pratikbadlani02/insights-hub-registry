/**
 * Thin github.com REST client built on Node's global fetch (Node 20+).
 * Only the handful of Contents-API operations the hub needs: read a file,
 * write a file, list a directory, fetch raw text. No SDK dependency.
 */

import { liveConfig } from "./settings.js";

function apiBase() { return (liveConfig().githubApiBase || "https://api.github.com").replace(/\/+$/, ""); }
function token()   { return liveConfig().githubToken || ""; }

export class GitHubError extends Error {
  constructor(status, message, path) {
    super(`GitHub ${status}: ${message} (${path})`);
    this.name = "GitHubError";
    this.status = status;
    this.path = path;
  }
}

export function hasToken() {
  return token().length > 0;
}

function baseHeaders(accept = "application/vnd.github+json") {
  const headers = {
    Accept: accept,
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "insights-hub",
  };
  const tok = token();
  if (tok) headers.Authorization = `Bearer ${tok}`;
  return headers;
}

async function request(method, path, { accept, body } = {}) {
  const url = path.startsWith("http") ? path : `${apiBase()}${path}`;
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: {
        ...baseHeaders(accept),
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (err) {
    throw new GitHubError(0, `network error (${err?.message ?? err})`, path);
  }
  return res;
}

/**
 * Verify the caller can reach (and write to) a repo. Throws a descriptive
 * GitHubError when the repo is not found or the token has no access — so
 * callers get a clear message instead of a cryptic 404 on a file path.
 */
export async function assertRepoAccess(owner, repo, { write = false } = {}) {
  const res = await request("GET", `/repos/${owner}/${repo}`);
  if (res.status === 404) {
    throw new GitHubError(
      404,
      `Repo '${owner}/${repo}' not found or not accessible with the configured GitHub token`,
      `/repos/${owner}/${repo}`,
    );
  }
  if (!res.ok) {
    throw new GitHubError(res.status, await safeText(res), `/repos/${owner}/${repo}`);
  }
  if (write) {
    const json = await res.json();
    const perms = json.permissions ?? {};
    if (!perms.push && !perms.admin) {
      throw new GitHubError(
        403,
        `Token has read-only access to '${owner}/${repo}'. Grant write (push) access.`,
        `/repos/${owner}/${repo}`,
      );
    }
  }
}

/** GET a repo's default branch (e.g. "main"). Returns null if unreadable. */
export async function getDefaultBranch(owner, repo) {
  const res = await request("GET", `/repos/${owner}/${repo}`);
  if (!res.ok) return null;
  const json = await res.json();
  return json.default_branch ?? null;
}

/** GET a file's JSON metadata (content base64 + sha). Returns null when the file does not exist. */
export async function getFile(owner, repo, path, ref) {
  const q = ref ? `?ref=${encodeURIComponent(ref)}` : "";
  const res = await request("GET", `/repos/${owner}/${repo}/contents/${encodePath(path)}${q}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new GitHubError(res.status, await safeText(res), path);
  const json = await res.json();
  if (Array.isArray(json)) throw new GitHubError(422, "path is a directory, not a file", path);
  return {
    sha: json.sha,
    text: Buffer.from(json.content ?? "", json.encoding || "base64").toString("utf8"),
  };
}

/** GET the raw bytes of a file as text. Returns null when the file does not exist. */
export async function getRawText(owner, repo, path, ref) {
  const q = ref ? `?ref=${encodeURIComponent(ref)}` : "";
  const res = await request("GET", `/repos/${owner}/${repo}/contents/${encodePath(path)}${q}`, {
    accept: "application/vnd.github.raw",
  });
  if (res.status === 404) return null;
  if (!res.ok) throw new GitHubError(res.status, await safeText(res), path);
  return res.text();
}

/** List a directory's entries. Returns [] when the path does not exist. */
export async function listDir(owner, repo, path, ref) {
  const q = ref ? `?ref=${encodeURIComponent(ref)}` : "";
  const res = await request("GET", `/repos/${owner}/${repo}/contents/${encodePath(path)}${q}`);
  if (res.status === 404) return [];
  if (!res.ok) throw new GitHubError(res.status, await safeText(res), path);
  const json = await res.json();
  if (!Array.isArray(json)) throw new GitHubError(422, "path is a file, not a directory", path);
  return json.map((e) => ({ name: e.name, path: e.path, type: e.type }));
}

/**
 * Create or update a file. Pass the current `sha` to update; omit to create.
 * Returns the new commit's content sha. Throws GitHubError(409) on a stale sha.
 */
export async function putFile(owner, repo, path, { message, text, sha, branch }) {
  const res = await request("PUT", `/repos/${owner}/${repo}/contents/${encodePath(path)}`, {
    body: {
      message,
      content: Buffer.from(text, "utf8").toString("base64"),
      ...(sha ? { sha } : {}),
      ...(branch ? { branch } : {}),
    },
  });
  if (res.status === 409 || res.status === 422) {
    // 409 conflict / 422 "sha does not match" — caller should re-read and retry.
    throw new GitHubError(409, await safeText(res), path);
  }
  if (res.status === 404) {
    // 404 on a write means the repo doesn't exist or the token has no access —
    // not a file-path issue. Surface the repo so the message is actionable.
    throw new GitHubError(404, `Repo '${owner}/${repo}' not found or token lacks write access`, path);
  }
  if (!res.ok) throw new GitHubError(res.status, await safeText(res), path);
  const json = await res.json();
  return json.content?.sha ?? null;
}

/** Delete a file. Requires its current sha. No-op if it's already gone. */
export async function deleteFile(owner, repo, path, { message, sha, branch }) {
  const res = await request("DELETE", `/repos/${owner}/${repo}/contents/${encodePath(path)}`, {
    body: { message, sha, ...(branch ? { branch } : {}) },
  });
  if (res.status === 404) return; // already gone — fine
  if (!res.ok) throw new GitHubError(res.status, await safeText(res), path);
}

function encodePath(path) {
  return path
    .split("/")
    .filter(Boolean)
    .map((seg) => encodeURIComponent(seg))
    .join("/");
}

async function safeText(res) {
  try {
    const body = await res.json();
    return body?.message || JSON.stringify(body);
  } catch {
    return res.statusText || "request failed";
  }
}
