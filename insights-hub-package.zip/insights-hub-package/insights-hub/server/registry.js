/**
 * The registry manifest (schemaVersion 1) lives in a common GitHub repo and is
 * the source of truth for uploaded projects. The effective manifest served to
 * the viewer merges it with any local sample manifest in public/content/ so the
 * seeded spring-petclinic keeps working with no GitHub setup.
 */

import { readFile } from "node:fs/promises";
import path from "node:path";
import { getFile, putFile } from "./github.js";
import { liveConfig } from "./settings.js";

const GENERATOR_TAG = "insights-hub@upload";

export function registryConfig() {
  const c = liveConfig();
  return {
    owner:    c.registryOwner    || "",
    repo:     c.registryRepo     || "",
    filePath: c.registryPath     || "manifest.json",
    branch:   c.registryBranch   || "main",
  };
}

export function registryEnabled() {
  const c = registryConfig();
  return Boolean(c.owner && c.repo);
}

function emptyManifest() {
  return { schemaVersion: 1, generatedAt: "", generator: GENERATOR_TAG, services: [] };
}

/** Read the registry manifest from GitHub. Returns { manifest, sha }. */
export async function readRegistry() {
  if (!registryEnabled()) return { manifest: emptyManifest(), sha: null };
  const c = registryConfig();
  const file = await getFile(c.owner, c.repo, c.filePath, c.branch);
  if (file === null) return { manifest: emptyManifest(), sha: null };
  let parsed;
  try {
    parsed = JSON.parse(file.text);
  } catch {
    throw new Error(`Registry manifest at ${c.owner}/${c.repo}/${c.filePath} is not valid JSON`);
  }
  if (!parsed || !Array.isArray(parsed.services)) {
    return { manifest: { ...emptyManifest(), ...parsed, services: [] }, sha: file.sha };
  }
  return { manifest: parsed, sha: file.sha };
}

/**
 * Read → mutate → write the registry, retrying on a stale-sha conflict so
 * concurrent uploads from different users don't clobber each other.
 * `mutate(manifest)` edits `manifest.services` in place (or returns a new one).
 */
export async function updateRegistry(mutate, { message, nowIso }) {
  if (!registryEnabled()) {
    throw new Error(
      "Registry repo is not configured — set REGISTRY_OWNER and REGISTRY_REPO in the server environment.",
    );
  }
  const c = registryConfig();
  let lastErr;
  for (let attempt = 0; attempt < 5; attempt++) {
    const { manifest, sha } = await readRegistry();
    const next = mutate(structuredClone(manifest)) || manifest;
    next.schemaVersion = 1;
    next.generator = next.generator || GENERATOR_TAG;
    next.generatedAt = nowIso || next.generatedAt || "";
    try {
      await putFile(c.owner, c.repo, c.filePath, {
        message,
        text: `${JSON.stringify(next, null, 2)}\n`,
        sha: sha || undefined,
        branch: c.branch,
      });
      return next;
    } catch (err) {
      lastErr = err;
      if (err?.status === 409) continue; // stale sha — re-read and retry
      throw err;
    }
  }
  throw new Error(`Could not update registry after retries: ${lastErr?.message ?? "conflict"}`);
}

/** Read the local sample manifest (public/content/manifest.json), or empty. */
export async function readLocalManifest(localContentDir) {
  try {
    const text = await readFile(path.join(localContentDir, "manifest.json"), "utf8");
    const parsed = JSON.parse(text);
    if (parsed && Array.isArray(parsed.services)) return parsed;
  } catch {
    /* no local sample — fine */
  }
  return emptyManifest();
}

/**
 * Effective manifest = local services ∪ registry services, deduped by id
 * (registry wins). Each service is tagged with its origin so the content route
 * knows where to fetch pages from.
 */
export async function effectiveManifest(localContentDir) {
  const local = await readLocalManifest(localContentDir);
  const { manifest: registry } = await readRegistry();
  const byId = new Map();
  for (const s of local.services) byId.set(s.id, { ...s, _origin: "local" });
  for (const s of registry.services) byId.set(s.id, { ...s, _origin: "registry" });
  return {
    schemaVersion: 1,
    generatedAt: registry.generatedAt || local.generatedAt || "",
    generator: registry.generator || local.generator || GENERATOR_TAG,
    services: [...byId.values()],
  };
}
