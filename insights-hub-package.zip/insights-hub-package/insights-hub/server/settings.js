/**
 * Persistent settings store. Settings are saved to a JSON file so they
 * survive server restarts without requiring env-var access.
 *
 * Path resolution: SETTINGS_FILE env var → ./data/settings.json (relative
 * to the server's working directory). In any hosted environment, point
 * SETTINGS_FILE at a path on a writable volume.
 *
 * Resolution order for each value (first truthy wins):
 *   1. Saved settings file (written by the UI)
 *   2. Environment variable (backward-compatible with .env / existing deploys)
 *   3. Empty string / sensible default
 *
 * liveConfig() is called at request time (not module load) so changes saved
 * via the UI take effect immediately without a restart.
 */

import { readFileSync, writeFileSync, mkdirSync, renameSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import os from "node:os";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");

function settingsFile() {
  return process.env.SETTINGS_FILE || path.join(ROOT, "data", "settings.json");
}

function ensureDir(filePath) {
  mkdirSync(path.dirname(filePath), { recursive: true });
}

/** Read the persisted settings file. Returns {} when absent. */
export function readSettings() {
  const file = settingsFile();
  try {
    const raw = readFileSync(file, "utf8");
    const parsed = JSON.parse(raw);
    if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) return parsed;
  } catch (err) {
    if (err.code !== "ENOENT") {
      console.warn(`[insights-hub] Could not read settings file at "${file}": ${err.message}`);
    }
  }
  return {};
}

/** Atomically write settings. Merges with existing file so partial saves work. */
export function writeSettings(partial) {
  const file = settingsFile();
  ensureDir(file);
  const current = readSettings();
  const next = { ...current, ...partial };
  // Atomic write via temp file + rename so a crash mid-write leaves a valid file.
  const tmp = path.join(os.tmpdir(), `insights-hub-settings-${Date.now()}.json`);
  writeFileSync(tmp, JSON.stringify(next, null, 2) + "\n", "utf8");
  renameSync(tmp, file);
}

/**
 * Merged config ready for the server to consume. Saved settings win over env vars.
 * Called at request time so UI changes are immediately effective.
 */
export function liveConfig() {
  const s = readSettings();
  function pick(savedKey, envKey, defaultVal = "") {
    const sv = s[savedKey];
    if (sv !== undefined && sv !== null && String(sv).trim() !== "") return String(sv).trim();
    const ev = process.env[envKey];
    if (ev && ev.trim()) return ev.trim();
    return defaultVal;
  }
  return {
    githubToken:    pick("githubToken",    "GITHUB_TOKEN"),
    githubApiBase:  pick("githubApiBase",  "GITHUB_API_BASE",  "https://api.github.com"),
    registryOwner:  pick("registryOwner",  "REGISTRY_OWNER"),
    registryRepo:   pick("registryRepo",   "REGISTRY_REPO"),
    registryPath:   pick("registryPath",   "REGISTRY_PATH",    "manifest.json"),
    registryBranch: pick("registryBranch", "REGISTRY_BRANCH",  "main"),
  };
}

const TOKEN_MASK = "••••••••";

/** Settings shape returned to the UI — token replaced with a mask if set. */
export function publicSettings() {
  const s = readSettings();
  const live = liveConfig();
  return {
    githubToken:    live.githubToken    ? TOKEN_MASK : "",
    githubApiBase:  live.githubApiBase,
    registryOwner:  live.registryOwner,
    registryRepo:   live.registryRepo,
    registryPath:   live.registryPath,
    registryBranch: live.registryBranch,
    // Surface whether the token came from the saved file vs env var
    tokenSource: s.githubToken ? "saved" : (process.env.GITHUB_TOKEN ? "env" : "none"),
  };
}

export { TOKEN_MASK };
