# Insights Hub — Distribution Package

A reverse-engineering documentation system in a box: two analysis skills that produce standardized documentation sets for Spring Boot and React codebases, an orchestrator skill that runs them across a whole workspace, a Confluence publisher, GitHub Copilot prompt equivalents, and a React viewer app (the **Insights Hub**) to browse it all.

## Usage — one line

Unzip, open Claude Code in this folder, and say: **Follow SETUP.md**

The same works in GitHub Copilot agent mode: open this folder in VS Code and tell the agent to follow `SETUP.md`. The setup agent checks prerequisites, installs the skills and prompts, stands up the hub with a seeded example service, and runs a full verification before printing next steps.

## What's inside

```
insights-hub-package/
├── SETUP.md                           # executable setup prompt — start here
├── README.md                          # this file
├── skills/                            # Claude skills (each: SKILL.md + artifact.yaml)
│   ├── insights-hub-generator/        # orchestrator: detects projects, delegates to the right
│   │                                  #   analysis skill, publishes docs + manifest into the hub
│   ├── confluence-publisher/          # publishes hub content to Confluence (Atlassian MCP)
│   ├── java-spring-backend-analysis/  # Spring Boot analysis, 10-page doc set (unmodified copy)
│   └── react-frontend-analysis/       # React analysis, 9-page doc set (unmodified copy)
├── prompts/                           # GitHub Copilot prompt files
│   ├── generate-insights-hub.prompt.md
│   ├── publish-confluence.prompt.md
│   ├── reverse-engineer-springboot.prompt.md
│   └── reverse-engineer-react.prompt.md
└── insights-hub/                      # viewer app source (Vite + React + TS, no node_modules)
    └── public/content/                # seeded spring-petclinic docs + manifest.json,
                                       #   used by SETUP.md's verification step
```

All four skills ship together on purpose: the generator delegates to the two analysis skills, so they must be installed alongside it.

## Prerequisites

- **Node.js >= 20** and **npm** (for the hub viewer; `SETUP.md` verifies this first)
- **Claude Code** (recommended) or VS Code with **GitHub Copilot agent mode** — to execute `SETUP.md` and later run the skills / prompts
- Optional: the **Atlassian MCP connector**, only if you want Confluence publishing

## What gets installed where

| Package source | Destination | Notes |
|---|---|---|
| `skills/insights-hub-generator/` | `~/.claude/skills/insights-hub-generator/` | orchestrator skill |
| `skills/confluence-publisher/` | `~/.claude/skills/insights-hub-confluence-publisher/` | destination = slug from its `artifact.yaml` |
| `skills/java-spring-backend-analysis/` | `~/.claude/skills/spring-boot-service-analysis/` | destination = slug from its `artifact.yaml` |
| `skills/react-frontend-analysis/` | `~/.claude/skills/react-frontend-analysis/` | |
| `prompts/*.prompt.md` | `<your workspace>/.github/prompts/` | existing files are never overwritten |
| `insights-hub/` | `<your workspace>/insights-hub/` | then `npm install` + `npm run dev` (default http://localhost:5173/) |

Skill destination names come from each skill's `artifact.yaml` `slug`, which is why two differ from their package folder names. During install, a YAML frontmatter block (`name` + `description`) is prepended to each **installed** `SKILL.md` copy; the copies inside this package stay frontmatter-free by design.

## FAQ

**Is it safe to re-run SETUP.md?**
Yes — setup is idempotent. Skills whose slug is already installed and prompt files that already exist are skipped and reported, never overwritten. If a hub folder already exists at the target path, it is automatically **upgraded in place**: the app is replaced while your generated documentation (`public/content/`) and Confluence state (`confluence.json`) are preserved. A full reset back to the seeded sample content only happens if you explicitly ask for a factory reset.

**How do I uninstall?**
- Skills: delete the folders `~/.claude/skills/insights-hub-generator`, `~/.claude/skills/insights-hub-confluence-publisher`, `~/.claude/skills/spring-boot-service-analysis`, and `~/.claude/skills/react-frontend-analysis`.
- Copilot prompts: delete the copied `*.prompt.md` files from `<workspace>/.github/prompts/`.
- Hub: it is fully self-contained — just delete the `<workspace>/insights-hub` folder.

**Port 5173 is already taken on my machine.**
`SETUP.md` detects that, starts the dev server on a free port instead, and uses that port for all verification checks and in the hub URL it prints.

**Do I need Confluence?**
No. Confluence publishing is optional; the analysis skills, generator, and hub viewer all work without it.

**Where does the hub content come from?**
The package ships with one seeded example service (`spring-petclinic`) so verification has something to check. To add your own services, run the **insights-hub-generator** skill against a workspace path or GitHub repo URLs — the viewer fetches content at runtime, so newly published docs appear on refresh with no rebuild. Re-run the generator any time; it only analyzes projects not yet in the manifest.
