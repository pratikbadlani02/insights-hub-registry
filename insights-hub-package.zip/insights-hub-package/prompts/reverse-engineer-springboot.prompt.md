---
mode: agent
description: Reverse-engineer a Spring Boot enterprise application and produce a complete, structured set of Markdown documentation with Mermaid diagrams covering architecture, API, data model, security, integrations, configuration, cross-cutting concerns, and build/deploy.
---

# Reverse-Engineer & Document a Spring Boot Enterprise App

You are a senior backend architect. Your job is to **read the codebase and produce documentation** — do not modify application code. Investigate the repository, then generate the docs set described below under `docs/reverse-engineering/`.

## Operating rules

- **Ground every statement in code.** Cite the source as `path/File.java:line` (or `:Class#method`). Never invent endpoints, beans, tables, or flows. If something is unknown or not found, write `> ⚠️ Not found in codebase` rather than guessing.
- **Read before writing.** Inspect `pom.xml`/`build.gradle`, `application*.yml|properties`, and the `@SpringBootApplication` main class first to establish the Spring Boot version, active starters, and module layout. Adapt depth to the stack you actually find.
- **Be exhaustive on the API and data model.** These are the contracts other systems depend on.
- **All diagrams are Mermaid** in fenced ```mermaid blocks so they render on GitHub.
- Write one file per section listed below. Keep a consistent heading style. Cross-link files with relative links.
- After generating, update `docs/reverse-engineering/README.md` as the index linking every section.

## Discovery checklist (run this analysis first)

1. **Bootstrap & config** — main class, `@Configuration`/`@Bean`, profiles, `application*.yml`, externalized config, `@ConfigurationProperties`.
2. **Build & dependencies** — Spring Boot version, key starters, modules (Maven/Gradle multi-module), Java version.
3. **Layered flow** — `@RestController`/`@Controller` → `@Service` → `@Repository` → `@Entity`/DTO. Trace at least 2–3 representative end-to-end request paths.
4. **Data layer** — JPA entities + relationships, Flyway/Liquibase migrations, custom `@Query`/native SQL/QueryDSL, datasource & connection pool.
5. **Security** — `SecurityFilterChain`/filters, auth mechanism (JWT/OAuth2/session/LDAP), `@PreAuthorize`/method security, CORS/CSRF.
6. **API surface** — every endpoint (method, path, params, request/response DTO, validation), `@ControllerAdvice` error handling, OpenAPI/springdoc if present.
7. **Cross-cutting** — `@Transactional` boundaries, AOP `@Aspect`, caching (`@Cacheable`), `@Scheduled`/Quartz, logging/auditing.
8. **Integrations** — `RestTemplate`/`WebClient`/Feign clients, messaging (Kafka/RabbitMQ/JMS) producers & listeners, external services.
9. **Build & deploy** — profiles, `Dockerfile`, K8s/Helm, Actuator endpoints, env-specific config.
10. **Testing** — `@SpringBootTest`/`@WebMvcTest`/`@DataJpaTest` slices, Testcontainers, mocking approach.

## Documentation set to produce

Create these files under `docs/reverse-engineering/`:

### `README.md` — Index
- One-paragraph system summary, tech stack table (Spring Boot version, Java, DB, messaging, build tool), module map, and links to every section below.

### `01-architecture-overview.md`
- System purpose and bounded context.
- Module/layer breakdown.
- **C4-style component diagram** (Mermaid `graph`/`flowchart`) showing controllers → services → repositories → DB and external systems.

```mermaid
flowchart LR
  Client -->|HTTP| Controller
  Controller --> Service
  Service --> Repository
  Repository --> DB[(Database)]
  Service -->|REST/Feign| ExternalAPI
  Service -->|publish| Broker[(Kafka/RabbitMQ)]
```

### `02-configuration.md`
- Profiles and what each enables.
- Table of every config property (key → purpose → default → where consumed), `@ConfigurationProperties` classes, secrets/externalized config.

### `03-api-reference.md`
- **Endpoint inventory table**: HTTP method · path · controller method (`File:line`) · auth required · request DTO · response DTO · validation rules.
- Group by controller/resource. Note pagination, content types, status codes.
- `@ControllerAdvice` exception → HTTP status mapping table.

### `04-data-model.md`
- Entity catalog with fields, types, constraints.
- **Mermaid ER diagram** of entities and relationships.
- Migration history (Flyway/Liquibase) and notable custom queries.

```mermaid
erDiagram
  ORDER ||--o{ ORDER_ITEM : contains
  CUSTOMER ||--o{ ORDER : places
```

### `05-security.md`
- Auth/authz mechanism, filter chain order, token lifecycle.
- Role/permission matrix vs. endpoints.
- **Mermaid sequence diagram** of the authentication flow (login → token → authorized request).

```mermaid
sequenceDiagram
  participant U as Client
  participant API as Controller
  participant SF as SecurityFilter
  participant AS as AuthService
  U->>API: POST /login (credentials)
  API->>AS: authenticate
  AS-->>U: JWT
  U->>SF: request + Bearer token
  SF->>SF: validate token
  SF-->>API: authorized
```

### `06-key-flows.md`
- 2–4 representative business flows, each with a **Mermaid sequence diagram** (controller → service → repo → external), transaction boundaries marked, and the originating endpoint cited.

### `07-cross-cutting.md`
- Transaction boundaries (where `@Transactional` sits and why it matters), AOP aspects, caching, scheduled jobs, logging/auditing.

### `08-integrations.md`
- Outbound clients (REST/Feign/WebClient) — target, auth, retry/timeout.
- Messaging — topics/queues, producers, listeners, serialization.
- **Mermaid diagram** of the integration landscape.

### `09-build-deploy.md`
- Build commands, profiles, Docker/K8s/Helm, Actuator/observability endpoints, environment matrix.

### `10-testing.md`
- Test slices used, coverage hot/cold spots, Testcontainers/mocks, how to run the suite.

## Final step

Print a short summary to chat: which sections were generated, any `⚠️ Not found` gaps, and the top 3 architectural risks or coupling smells you observed (with file citations).
