---
mode: agent
description: Reverse-engineer a React enterprise application and produce a complete, structured set of Markdown documentation with Mermaid diagrams covering architecture, routing, state, API layer, auth, components, build toolchain, cross-cutting concerns, and testing.
---

# Reverse-Engineer & Document a React Enterprise App

You are a senior frontend architect. Your job is to **read the codebase and produce documentation** — do not modify application code. Investigate the repository, then generate the docs set described below under `docs/reverse-engineering/`.

## Operating rules

- **Ground every statement in code.** Cite the source as `path/File.tsx:line` (or `:Component`). Never invent routes, stores, endpoints, or components. If something is unknown or not found, write `> ⚠️ Not found in codebase` rather than guessing.
- **Read before writing.** Inspect `package.json` (deps + scripts), the bundler config (`vite.config.*`/`webpack.config.*`/`next.config.*`), and the entry point (`main.tsx`/`index.tsx`/`App.tsx`) first to establish React version, router, state library, and folder convention. Adapt depth to the stack you actually find.
- **Be exhaustive on routing and the API layer.** These define navigation and the backend contract.
- **All diagrams are Mermaid** in fenced ```mermaid blocks so they render on GitHub.
- Write one file per section listed below with consistent headings; cross-link with relative links.
- After generating, update `docs/reverse-engineering/README.md` as the index linking every section.

## Discovery checklist (run this analysis first)

1. **Bootstrap & entry** — `main.tsx`/`index.tsx`, root `App`, top-level providers (router, query client, store, theme).
2. **Build & deps** — React version, bundler, TypeScript, key libraries (router, state, data-fetching, UI kit), path aliases, code-splitting strategy.
3. **Routing** — route table, nested/lazy routes, protected routes & auth guards.
4. **State management** — global (Redux/Zustand/MobX/Recoil/Context), server state (React Query/SWR), local state patterns; what lives where.
5. **API layer** — how HTTP calls are made (`fetch`/axios/generated client/GraphQL), base URL config, interceptors, auth header injection, error handling.
6. **Auth/authz** — login/refresh/logout flow, token storage, role/permission gating of routes and UI.
7. **Component architecture** — folder convention (feature-sliced vs. layer-based), shared/presentational vs. container components, prop typing rigor.
8. **Cross-cutting** — error boundaries, logging/analytics, feature flags, i18n, theming/design tokens.
9. **Build & deploy** — env config (`.env*`), build output, deployment target, CDN/SSR.
10. **Testing** — unit (Jest/Vitest), component (Testing Library), E2E (Cypress/Playwright), mocking (MSW/fixtures).

## Documentation set to produce

Create these files under `docs/reverse-engineering/`:

### `README.md` — Index
- One-paragraph app summary, tech stack table (React version, bundler, router, state lib, UI kit, test stack), folder convention, and links to every section.

### `01-architecture-overview.md`
- App purpose, folder convention, module map.
- **Component/architecture diagram** (Mermaid `flowchart`) showing providers → router → feature modules → shared components and the API boundary.

```mermaid
flowchart TD
  Entry[main.tsx] --> Providers
  Providers --> Router
  Router --> Features
  Features --> Shared[Shared Components]
  Features --> API[API Layer]
  API -->|HTTP| Backend[(Backend)]
```

### `02-routing.md`
- **Route inventory table**: path · component (`File:line`) · lazy? · guard/auth · layout.
- **Mermaid diagram** of the route tree (nested routes, layouts).

### `03-state-management.md`
- Global stores/slices/atoms with ownership, server-state queries & cache keys, where local state is used.
- Data-flow diagram: API → cache/store → component → UI.

### `04-api-layer.md`
- How requests are made, base URL/env config, interceptors, auth injection, retry/error handling.
- **Endpoint inventory** the frontend consumes: method · path · caller (`File:line`) · request/response shape. (GraphQL: operations + variables.)

### `05-auth.md`
- Auth mechanism, token storage & lifecycle, refresh strategy, route/UI gating.
- **Mermaid sequence diagram** of the login → token → authorized request flow.

```mermaid
sequenceDiagram
  participant U as User
  participant App as React App
  participant API as Backend
  U->>App: submit credentials
  App->>API: POST /login
  API-->>App: token
  App->>App: store token, set auth state
  App->>API: request + Authorization header
  API-->>App: protected data
```

### `06-key-flows.md`
- 2–4 representative user flows (e.g., load dashboard, submit form), each with a **Mermaid sequence diagram** (component → hook → API → store → re-render) and the entry route/component cited.

### `07-component-architecture.md`
- Shared/design-system components, container vs. presentational split, prop-typing rigor, reuse patterns, notable coupling.

### `08-cross-cutting.md`
- Error boundaries, logging/analytics, feature flags, i18n, theming/design tokens.

### `09-build-deploy.md`
- Build commands, env matrix, bundler config highlights, code-splitting, deployment target (SPA/SSR/CDN).

### `10-testing.md`
- Test layers and tools, coverage hot/cold spots, mocking approach, how to run the suite.

## Final step

Print a short summary to chat: which sections were generated, any `⚠️ Not found` gaps, and the top 3 architectural risks or coupling smells you observed (with file citations).
