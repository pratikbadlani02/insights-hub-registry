---
mode: agent
description: Batch-document every Spring Boot and React project in a workspace (or GitHub repo list) into the Insights Hub by following the workspace analysis skill specs and writing the hub's manifest.json.
---

# Generate the Insights Hub Documentation Set

You are a senior platform engineer orchestrating documentation generation across a workspace. Your job is to discover every Spring Boot and React project in the given input, produce (or import) each project's standardized analysis doc set, and publish everything into the Insights Hub viewer's content directory with an up-to-date `manifest.json`. Do not modify application source code — the only writes into a source project are the analysis spec's own docs output folder.

## Operating rules

- **Delegate the analysis — never invent your own doc structure.** For each detected project, OPEN AND FOLLOW the matching workspace analysis spec file verbatim: `java-spring-backend-analysis/SKILL.md` for Spring Boot, `react-frontend-analysis/SKILL.md` for React. Their procedures, table schemas, diagram minimums, and evidence rules are authoritative; do not restate or reinterpret them.
- **Do NOT use `.github/prompts/reverse-engineer-springboot.prompt.md` or `.github/prompts/reverse-engineer-react.prompt.md` for this task.** They produce a different documentation set (`docs/reverse-engineering/`, different filenames and sections) that the hub manifest does not understand.
- The fallback is **per-stack**: for each stack, use its workspace SKILL.md if that folder is present; only when a stack's skill folder is absent use the **Embedded fallback spec** at the end of this prompt for that stack alone (e.g. Spring folder present + React folder missing → follow the Spring SKILL.md and the React fallback).
- Treat source projects as read-only, EXCEPT the analysis spec's own docs output folder (`docs/backend-analysis/` for Spring, `docs/frontend-analysis/` for React).
- Never modify the two analysis skill folders (`java-spring-backend-analysis/`, `react-frontend-analysis/`) in any way.
- Preserve backtick ```` ```mermaid ```` fences exactly when copying — never convert to tilde fences. The hub viewer detects diagrams only via the `language-mermaid` className produced by backtick fences.
- One project's failure must NOT abort the run — record it as `failed` with the error and continue with the remaining projects. Process projects sequentially; for large workspaces, complete and publish one project fully before starting the next.

## Inputs

| Mode | Invocation | Input |
|---|---|---|
| A — local workspace | a directory path (e.g. `./workspace`) | Directory containing project folders |
| B — GitHub repos | one or more GitHub repo URLs | Each URL is cloned, then treated like Mode A |

| Flag | Effect |
|---|---|
| `--force` | Re-analyze and re-publish ALL discovered projects, including EXISTING ones |
| `--force <id>` | Re-analyze and re-publish only the service with that manifest `id` |
| `--prune` | Delete published docs + manifest entries for STALE services |
| `--hub <path>` | Location of the hub app; default `<workspace>/insights-hub` |

## Procedure

### 1. Repo acquisition (Mode B only)

1. Clone each URL into `<workspace>/.insights-hub-sources/<repo-name>/`.
2. If the clone already exists (re-run): `git fetch && git reset --hard origin/HEAD` before analyzing — never merge, never keep local edits.
3. From here on, treat each clone exactly like a Mode A project. Record `source.type: "git"` and the original URL as `source.repoUrl` in the manifest entry.

### 2. Discovery & stack detection

Scan the input directory at the top level AND one level deep (monorepo support). For each candidate folder, apply the first matching row:

| Marker found in folder | Stack | Analysis spec to open and follow |
|---|---|---|
| `pom.xml` or `build.gradle` / `build.gradle.kts` containing `org.springframework.boot` | `java-spring` | `java-spring-backend-analysis/SKILL.md` |
| `package.json` with a `react` dependency | `react` | `react-frontend-analysis/SKILL.md` |
| Neither marker | — | Skip and report with reason `no supported stack marker` |

Monorepo rule: a folder whose subtree matches BOTH markers yields two services — `<name>-backend` (the Spring module) and `<name>-frontend` (the React module).

Ignore during discovery (list once under "ignored", never analyze): hidden directories (name starts with `.`), archive files (`.zip` etc.), skill folders (root contains `SKILL.md`/`artifact.yaml` but no build markers), and the hub itself (the `--hub` path).

### 3. New-project detection — manifest membership ONLY

Detection is manifest membership and nothing else: **no commit hashes, no mtime tracking**. The user simply re-runs this prompt to pick up newly added projects. Read `<hub>/public/content/manifest.json` first (a missing manifest means zero services), then classify every discovered project:

| State | Definition | Action |
|---|---|---|
| NEW | Discovered `id` not in `services[]` | Analyze (or import — see shortcut) + publish |
| EXISTING | `id` already in `services[]` | Skip + report. Re-generate only via `--force` or `--force <id>` |
| STALE | In `services[]` but source path/clone no longer exists | Report. Delete its docs folder + manifest entry ONLY with `--prune` |

Id derivation: if the project's docs already carry a header block, use the header's `Project:` value; otherwise kebab-case the project folder/repo name. Ids are URL-safe kebab-case and MUST equal the folder name under `public/content/services/<id>/`.

**Reuse shortcut:** a NEW project that already contains a complete, valid doc set in the spec's default output folder — Spring: 10 files `00-overview.md`…`09-deployment.md` in `docs/backend-analysis/`, each opening with a valid header block; React: 9 files `01-architecture.md`…`09-deployment.md` in `docs/frontend-analysis/` — is IMPORTED (published as-is, headers normalized on the copies) instead of re-analyzed. Report it as `imported`.

### 4. Analyze

For each NEW (or `--force`d) project: open the analysis spec file named in the detection table and execute its full procedure against the project. Let it write to its default in-repo output location — `docs/backend-analysis/` (Spring, 10 files) or `docs/frontend-analysis/` (React, 9 files, no `00-overview`). Do not redirect its output.

### 5. Publish into the hub

For each analyzed or imported project:

1. Copy the generated `.md` files to `<hub>/public/content/services/<id>/`.
2. **Normalize headers ON THE COPIES ONLY.** Spring output already opens with the header block — verify it. React output has NO header block per its spec — inject this exact block at the top of each copied file (after the `# {Section Title}` line if present, otherwise add the title from the section-titles table below):

   ```markdown
   # {Section Title}

   > Project: {id}
   > Type: {archetype}
   > Skill: {spring-analysis|react-analysis}
   > Analyzed: {ISO-8601}

   ---
   ```

   Never write headers into the source project's `docs/` output, and never edit the analysis skill folders to make them emit headers.

   **The two stacks use different stems from `02` through `07` — always use the table matching the service's `stack`, never mix them:**

   | Stem | Spring section title | React section title |
   |---|---|---|
   | `00-overview` | Overview | *(none — React has no 00)* |
   | `01-architecture` | Architecture | Architecture |
   | `02-entry-points` / `02-routing-and-navigation` | Entry Points | Routing And Navigation |
   | `03-business-rules` / `03-access-and-rules` | Business Rules | Access And Rules |
   | `04-data-model` | Data Model | Data Model |
   | `05-dependencies` | Dependencies | Dependencies |
   | `06-interactions` / `06-runtime-flows` | Interactions | Runtime Flows |
   | `07-data-flow` / `07-state-and-data-fetching` | Data Flow | State And Data Fetching |
   | `08-error-handling` | Error Handling | Error Handling |
   | `09-deployment` | Deployment | Deployment |
3. Upsert the project's entry in `<hub>/public/content/manifest.json`. Full schema (embed nothing else — this is the contract the viewer validates):

   ```json
   {
     "schemaVersion": 1,
     "generatedAt": "2026-07-07T15:30:00Z",
     "generator": "insights-hub-generator@1.0.0",
     "services": [
       {
         "id": "spring-petclinic",
         "name": "Spring PetClinic",
         "stack": "java-spring",
         "archetype": "rest-api",
         "skill": "spring-analysis",
         "analyzedAt": "2026-06-28T00:00:00Z",
         "pages": ["00-overview", "01-architecture", "02-entry-points", "03-business-rules",
                   "04-data-model", "05-dependencies", "06-interactions", "07-data-flow",
                   "08-error-handling", "09-deployment"],
         "tags": ["team-a", "tier-1"],
         "source": {
           "type": "local",
           "path": "/Users/pbadlani/workspace/sample-petclinic",
           "repoUrl": null
         }
       }
     ]
   }
   ```

   | Field | Rule |
   |---|---|
   | `id` | URL-safe kebab-case slug; MUST equal the folder name under `public/content/services/<id>/` |
   | `name` | Human display name |
   | `stack` | `"java-spring"` \| `"react"` |
   | `archetype` | `"rest-api"` \| `"kafka-consumer"` \| `"batch"` \| `"gateway"` \| `"react-spa"` \| `"react-mfe"` |
   | `skill` | `"spring-analysis"` \| `"react-analysis"` — matches the `> Skill:` header value |
   | `analyzedAt` | ISO-8601 UTC |
   | `pages` | File stems (no `.md`) actually present on disk, in numeric order. Spring: 10 (`00-overview`…`09-deployment`); React: 9 (`01-architecture`…`09-deployment`, NO `00-overview`). Never list a stem whose file does not exist |
   | `tags` | Optional array of free-form, hub-curated labels — never derived from analysis. When re-publishing an EXISTING service, carry its current `tags` forward unchanged; only a brand-new service may omit it (or use `[]`) |
   | `source.type` | `"local"` \| `"git"`; `path` = absolute local/clone path, `repoUrl` = GitHub URL or `null` |

4. Write `manifest.json` **atomically**: write the full document to a temp file in the same directory, then `mv` it over `manifest.json`. Never edit the live file in place.

### 6. Validate

| Check | Pass condition |
|---|---|
| Pages exist | Every stem in every service's `pages[]` exists as `<hub>/public/content/services/<id>/<stem>.md` |
| Headers valid | Every published page opens with `# Title` + `> Project/Type/Skill/Analyzed` + `---` |
| Manifest parses | `manifest.json` is valid JSON with `schemaVersion` 1 |

## Embedded fallback spec (ONLY if the skill folders are absent)

If neither `java-spring-backend-analysis/SKILL.md` nor `react-frontend-analysis/SKILL.md` exists in the workspace, produce the doc sets yourself to this minimum contract — ground every statement in code and cite `path/File:line`:

- **Spring (`docs/backend-analysis/`, 10 files):** `00-overview.md`, `01-architecture.md`, `02-entry-points.md`, `03-business-rules.md`, `04-data-model.md`, `05-dependencies.md`, `06-interactions.md`, `07-data-flow.md`, `08-error-handling.md`, `09-deployment.md`. Detect the archetype (`rest-api` | `kafka-consumer` | `batch` | `gateway`) from the dominant entry-point style.
- **React (`docs/frontend-analysis/`, 9 files — NO `00-overview.md`):** `01-architecture.md`, `02-routing-and-navigation.md`, `03-access-and-rules.md`, `04-data-model.md`, `05-dependencies.md`, `06-runtime-flows.md`, `07-state-and-data-fetching.md`, `08-error-handling.md`, `09-deployment.md`. These stems differ from Spring's at `02`, `03`, `06`, `07` — do not reuse Spring's names. Detect `react-spa` vs `react-mfe` (Module Federation config present → mfe).
- Spring section titles by stem: 00 Overview, 01 Architecture, 02 Entry Points, 03 Business Rules, 04 Data Model, 05 Dependencies, 06 Interactions, 07 Data Flow, 08 Error Handling, 09 Deployment.
- React section titles by stem: 01 Architecture, 02 Routing And Navigation, 03 Access And Rules, 04 Data Model, 05 Dependencies, 06 Runtime Flows, 07 State And Data Fetching, 08 Error Handling, 09 Deployment.
- Every file opens with the exact 4-line header block shown in step 5.2 (plain `>` blockquotes, no bold), followed by `---`.
- All diagrams are Mermaid in backtick ```` ```mermaid ```` fences — never tilde fences, never images.

## Final step

Print a run summary to chat:

| Status | Count | Services |
|---|---|---|
| analyzed | | |
| imported | | |
| skipped (reason) | | |
| stale | | |
| failed | | |

Follow it with the hub content path written, whether the manifest validated, any validation failures by page, and a reminder that the hub is viewable via `npm run dev` in `<hub>` and publishable to Confluence via `publish-confluence.prompt.md`.
