---
mode: agent
description: Publish the Insights Hub documentation set to Confluence as an idempotent three-level page tree using the Confluence REST API v2 via curl and environment-variable credentials.
---

# Publish Insights Hub Docs to Confluence (REST API v2)

You are a senior platform engineer publishing documentation. Your job is to mirror the services in `insights-hub/public/content/manifest.json` into a Confluence space as a three-level page tree, creating pages that don't exist and updating ones that do — never duplicating. You work from the terminal with `curl` against the Confluence Cloud REST API v2.

> **Note:** the Claude `confluence-publisher` skill (Atlassian MCP connector) is the primary supported publishing path. This prompt is a best-effort mirror for GitHub Copilot agent mode, which has no MCP — it uses the raw REST API and requires a markdown → Confluence storage-format conversion (see step 4).

## Operating rules

- **Never hardcode credentials** — not in commands, not in files, not in output. All auth comes from environment variables (step 0). If any is unset, STOP and tell the user how to export them; do not prompt for the token value in chat.
- **Idempotent by construction:** before creating any page, resolve it via the `confluence.json` id cache, then by exact-title lookup in the space. Found → update in place (PUT with `version.number + 1`); not found → create (POST with `parentId`).
- Confluence page titles are unique per space — the `{name} - ` prefix guarantees uniqueness across services. If a title collides with an unrelated existing page, stop and ask rather than overwriting.
- `--dry-run` makes **no write calls**: no POST, no PUT, no `confluence.json` writes. It may use read-only GETs to resolve create-vs-update.
- Write JSON request bodies to a temp file and pass `-d @file.json` — never inline page bodies in shell strings (quoting/escaping hazards).
- A failed page or service is recorded and reported — it must NOT abort the remaining pages or services.
- Persist learned page ids to `confluence.json` after every successful page operation, not only at the end — a crashed run must not lose ids already learned.

## Procedure

### 0. Preflight — credentials and content

Required environment variables (instruct the user to export them first, then re-run; STOP if any is unset):

```bash
export CONFLUENCE_BASE_URL="https://your-org.atlassian.net"   # site root, WITHOUT /wiki
export CONFLUENCE_EMAIL="you@example.com"
export CONFLUENCE_API_TOKEN="<api token from id.atlassian.com/manage-profile/security/api-tokens>"
```

Verify each is non-empty (e.g. `[ -n "$CONFLUENCE_API_TOKEN" ]`). All API calls use basic auth: `curl -s -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" ...` against `$CONFLUENCE_BASE_URL/wiki/api/v2/...`. Smoke-test auth with:

```bash
curl -s -o /dev/null -w '%{http_code}' -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" \
  "$CONFLUENCE_BASE_URL/wiki/api/v2/spaces?limit=1"
```

Expect `200`; on `401`/`403` stop and report a credential problem.

Then verify hub content: `<hub>/public/content/manifest.json` must parse as JSON with `schemaVersion: 1` and at least one service (`<hub>` defaults to `<workspace>/insights-hub`; accept `--hub <path>`). If missing, stop and tell the user to run `generate-insights-hub.prompt.md` first.

### 1. Configuration — `<hub>/confluence.json`

All publisher state lives in one machine-local file:

```json
{
  "siteUrl": "https://your-org.atlassian.net/wiki",
  "spaceKey": "ENG",
  "spaceId": "98304",
  "parentPageId": "123456",
  "parentPageTitle": "Insights Hub",
  "pageIds": {
    "spring-petclinic": "123457",
    "spring-petclinic/00-overview.md": "123457",
    "spring-petclinic/01-architecture.md": "123458"
  },
  "lastPublished": {
    "spring-petclinic": "2026-07-07T00:00:00Z"
  }
}
```

- **First run (file absent):** ask the user for the space key and the parent page (title or URL). Resolve `spaceId` from the key: `GET $CONFLUENCE_BASE_URL/wiki/api/v2/spaces?keys=<KEY>` → `.results[0].id` (API v2 filters pages by numeric `space-id`, not key). Offer to create a new "Insights Hub" page at the space root if none exists. Persist all confirmed/created values immediately.
- `spaceId` is an **optional cached field** used only by this REST-based prompt: it is derived from `spaceKey` via the REST call above on first run and cached so later runs skip the lookup. It is not part of the MCP-based skill's schema — that skill preserves it untouched.
- **`pageIds` is a cache, never authoritative.** Cached id returns 404 → fall back to exact-title lookup, repair the cache, or treat as create if that also misses.
- `lastPublished` per service id drives changed-only mode.

### 2. Inputs & modes

| Invocation | Behavior |
|---|---|
| `<service-id>` | Publish exactly one service by manifest `id` |
| (no args) | **Changed-only (default):** publish every service whose `analyzedAt` is strictly newer than its `lastPublished` (missing `lastPublished` counts as changed) |
| `--all` | Publish every service in the manifest regardless of timestamps |
| `--dry-run` | Combinable with all of the above. Print the full planned page tree — every page with resolved title, parent, and **create** vs **update** — with no write calls |

### 3. Page hierarchy — three levels

```
Insights Hub                                (parentPageId)
├── Spring PetClinic                        (landing = 00-overview.md content)
│   ├── Spring PetClinic - 01 Architecture
│   ├── ...
│   └── Spring PetClinic - 09 Deployment
└── Orders Frontend                         (React: generated summary, no 00-overview)
    ├── Orders Frontend - 01 Architecture
    └── ...
```

- **Service page (level 2):** title = manifest `name`; body = `00-overview.md`. React services have no `00-overview` — generate a short landing summary instead: service name, archetype, and a bullet list naming each section child page.
- **Section pages (level 3):** one per remaining stem in `pages[]`. Title = `{name} - {NN Title}`. The two stacks use different stems (and titles) from `02` through `07` — pick the table matching the service's `stack`, never mix them:
  - Spring titles by stem: 00 Overview, 01 Architecture, 02 Entry Points, 03 Business Rules, 04 Data Model, 05 Dependencies, 06 Interactions, 07 Data Flow, 08 Error Handling, 09 Deployment. Example: `Spring PetClinic - 02 Entry Points`.
  - React titles by stem: 01 Architecture, 02 Routing And Navigation, 03 Access And Rules, 04 Data Model, 05 Dependencies, 06 Runtime Flows, 07 State And Data Fetching, 08 Error Handling, 09 Deployment. Example: `Orders Frontend - 02 Routing And Navigation`.

### 4. Markdown → storage format (required caveat)

The REST API's `body.representation` must be `"storage"` (Confluence XHTML) — it does **not** accept raw markdown. Convert each page body before publishing:

| Markdown | Storage format |
|---|---|
| `# H1` … `###### H6` | `<h1>…</h1>` … `<h6>…</h6>` |
| Paragraphs, `**bold**`, `*italic*`, `` `code` `` | `<p>`, `<strong>`, `<em>`, `<code>` |
| GFM tables | `<table><tbody><tr><th>/<td>…</table>` |
| Bullet / numbered lists | `<ul>/<ol><li>…` |
| Links | `<a href="…">` |
| Fenced code block | code macro: `<ac:structured-macro ac:name="code"><ac:parameter ac:name="language">java</ac:parameter><ac:plain-text-body><![CDATA[…]]></ac:plain-text-body></ac:structured-macro>` |
| `> blockquote` (the doc header block) | `<blockquote><p>…</p></blockquote>` |

XML-escape `&`, `<`, `>` in text nodes; leave code content inside `CDATA` untouched (if the code itself contains `]]>`, split the CDATA section). Do the conversion with a small script (e.g. Node or Python) rather than by hand, and **verify one page visually before bulk publishing**: publish a single page, print its URL, and ask the user to confirm tables, code blocks, and the header blockquote render correctly before continuing.

**Mermaid:** Confluence does not render Mermaid natively. Convert ```` ```mermaid ```` fences to the code macro with `<ac:parameter ac:name="language">text</ac:parameter>` (keep the source verbatim in CDATA), and on any page containing at least one mermaid fence prepend one info line: *"Diagrams below are shown as Mermaid source — rendered diagrams are available in the Insights Hub viewer."* Org Mermaid plugins or `@mermaid-js/mermaid-cli` PNG pre-rendering are out of scope.

### 5. Idempotent publish — per service, in manifest order

1. Read the service's `pages[]` and each `<hub>/public/content/services/<id>/<stem>.md`.
2. Confirm the root: `GET /wiki/api/v2/pages/{parentPageId}`; on 404, title-lookup `parentPageTitle` in the space, else offer to recreate.
3. Build the target list: landing page first (children need its id), then one section page per remaining stem.
4. For each target page:

   a. Resolve id from `pageIds`; verify with `GET $CONFLUENCE_BASE_URL/wiki/api/v2/pages/{id}` (also yields `.version.number`).

   b. On cache miss or 404, exact-title lookup:

   ```bash
   curl -s -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" --get \
     "$CONFLUENCE_BASE_URL/wiki/api/v2/pages" \
     --data-urlencode "title=Spring PetClinic - 02 Entry Points" \
     --data-urlencode "space-id=$SPACE_ID"
   ```

   c. **Found → update** with the incremented version:

   ```bash
   curl -s -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" -X PUT \
     -H "Content-Type: application/json" \
     "$CONFLUENCE_BASE_URL/wiki/api/v2/pages/$PAGE_ID" -d @update.json
   # update.json: {"id":"$PAGE_ID","status":"current","title":"…",
   #   "version":{"number": <current version.number + 1>},
   #   "body":{"representation":"storage","value":"<converted storage XHTML>"}}
   ```

   **Not found → create** under the correct parent (service page under `parentPageId`, section pages under the service page's id):

   ```bash
   curl -s -u "$CONFLUENCE_EMAIL:$CONFLUENCE_API_TOKEN" -X POST \
     -H "Content-Type: application/json" \
     "$CONFLUENCE_BASE_URL/wiki/api/v2/pages" -d @create.json
   # create.json: {"spaceId":"$SPACE_ID","status":"current","title":"…",
   #   "parentId":"$PARENT_ID",
   #   "body":{"representation":"storage","value":"<converted storage XHTML>"}}
   ```

   d. Check the HTTP status (expect 200 create/update); record the returned page `id` and `_links.webui` in `pageIds` and persist `confluence.json` now.
5. After all of a service's pages succeed, set `lastPublished[<id>]` to the current UTC time and persist.
6. Continue to the next service regardless of failures.

## Final step

Print a summary table to chat:

| Page | Action | URL |
|---|---|---|
| Spring PetClinic | updated | $CONFLUENCE_BASE_URL/wiki + webui link |
| Spring PetClinic - 01 Architecture | created | … |
| Orders Frontend - 04 Data Model | FAILED (403) | — |

Actions: `created` / `updated` / `skipped (unchanged)` / `skipped (dry-run: would create)` / `skipped (dry-run: would update)` / `FAILED (<reason>)`. Close with totals (N created / updated / skipped / failed), the exact re-run command for any failed services, and a reminder that rendered Mermaid diagrams live in the Insights Hub viewer.
