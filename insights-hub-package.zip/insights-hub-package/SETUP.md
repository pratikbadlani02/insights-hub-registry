# Insights Hub — Setup Prompt

You are an AI coding agent (Claude Code, GitHub Copilot agent mode, or similar) and the user has asked you to follow this file. Execute the numbered steps below, in order, exactly as written. This is a plain prompt, not a skill — it is designed to run on a machine where nothing from this package has been installed yet.

**Ground rules**

- Work from the package root: the directory containing this `SETUP.md`. All relative paths below (`skills/`, `prompts/`, `insights-hub/`) are relative to it.
- Never overwrite an existing file or folder without asking the user first. When in doubt, skip and report.
- Never modify files inside this package. You copy them out; the package stays pristine so setup can be re-run safely.
- Keep a running record of every action (installed / skipped / failed) — you will summarize it at the end.

---

## Step 1 — Prerequisite check

Run:

```bash
node --version
npm --version
```

Requirements:

- `node --version` must report **major version 20 or higher** (e.g. `v20.x`, `v22.x`).
- `npm --version` must succeed.

If either check fails, **STOP — do not proceed to any later step.** Tell the user exactly what is missing and how to fix it:

> Node.js 20+ is required. Install the current LTS from https://nodejs.org, or via a version manager: `nvm install 20 && nvm use 20` (or on macOS: `brew install node`). Then re-run this setup by saying "Follow SETUP.md" again.

---

## Step 2 — Install the Claude skills

Process each of the four folders under `skills/`, in this order:

1. `skills/insights-hub-generator/`
2. `skills/confluence-publisher/`
3. `skills/java-spring-backend-analysis/`
4. `skills/react-frontend-analysis/`

For **each** folder:

1. **Read that folder's `artifact.yaml`** and extract:
   - `<slug>` — the value of the `slug:` key. Always take the slug from `artifact.yaml`, never from the folder name: two of the folders have slugs that differ from their folder names (`confluence-publisher` → slug `insights-hub-confluence-publisher`, `java-spring-backend-analysis` → slug `spring-boot-service-analysis`).
   - `<desc>` — the value of the `description:` key: collapse the YAML folded block into a single line (join the wrapped lines with single spaces), then keep only the **first two sentences** (split on a period followed by a space; if the second sentence has no closing period, take the rest of the text; if there is only one sentence, use it alone).

2. **Check for an existing install.** If `~/.claude/skills/<slug>/` already exists: **do not touch it.** Record "`<slug>`: already installed — skipped" and move to the next folder. Only replace an existing skill if the user explicitly asks you to.

3. **Copy the skill:**

   ```bash
   mkdir -p ~/.claude/skills/<slug>
   cp -R skills/<folder>/. ~/.claude/skills/<slug>/
   ```

4. **Prepend YAML frontmatter to the installed copy of `SKILL.md`** — i.e. edit `~/.claude/skills/<slug>/SKILL.md` ONLY. Never edit `skills/<folder>/SKILL.md` inside the package (the package copies are intentionally frontmatter-free). The installed file must begin with:

   ```
   ---
   name: <slug>
   description: <desc on one line — wrap the value in double quotes if it contains a colon>
   ---

   ```

   followed by a blank line and then the original file content, unchanged.

5. Record the result.

When all four are done, show the user a table:

| Package folder | Installed as (`~/.claude/skills/…`) | Action |
|---|---|---|
| skills/insights-hub-generator | insights-hub-generator | installed / skipped (already present) |
| skills/confluence-publisher | insights-hub-confluence-publisher | … |
| skills/java-spring-backend-analysis | spring-boot-service-analysis | … |
| skills/react-frontend-analysis | react-frontend-analysis | … |

---

## Step 3 — Install the GitHub Copilot prompts

1. **Ask the user:** "What is the absolute path of the workspace where you want the Copilot prompts and the Insights Hub app installed?" Call the answer `<workspace>`. If the directory does not exist, ask whether to create it. Reuse this same `<workspace>` in Step 4.

2. Create the prompts directory:

   ```bash
   mkdir -p "<workspace>/.github/prompts"
   ```

3. For **every** file matching `prompts/*.prompt.md` in this package: if a file with the same name already exists at `<workspace>/.github/prompts/`, **skip it** and record that; otherwise copy it. Never overwrite an existing prompt file.

4. Report which prompt files were copied and which were skipped.

---

## Step 4 — Stand up the Insights Hub viewer

1. Target location: `<workspace>/insights-hub`.

   **If that folder already exists, upgrade it in place — do not ask, and do not delete it.** It holds data that did NOT come from this package: `public/content/` (every documentation set the generator has published, plus `manifest.json`), `confluence.json` (the publisher's page-id cache), and `.env` (the backend's registry-repo and GitHub-token configuration — a secret). Upgrading replaces everything EXCEPT those three items — safe because the app never reads or imports from `public/content/` at build time; app code and content are fully independent. Tell the user you are upgrading in place and that their documentation, Confluence state, and backend configuration are preserved.

   Procedure: remove the old app files (preserving the three data items and `node_modules`, which `npm install` refreshes anyway), then copy the packaged app in via a temp copy that has had its seeded `public/content/` deleted — so the user's content is never touched:

   ```bash
   cd "<workspace>/insights-hub"
   find . -mindepth 1 -maxdepth 1 \
     ! -name public ! -name confluence.json ! -name .env ! -name node_modules -exec rm -rf {} +

   TMP_APP="$(mktemp -d)/insights-hub"
   cp -R "<package-dir>/insights-hub" "$TMP_APP"
   rm -rf "$TMP_APP/public/content"        # drop the seeded sample — the user's content stays
   cp -R "$TMP_APP/." "<workspace>/insights-hub/"
   rm -rf "$(dirname "$TMP_APP")"
   ```

   (`<package-dir>` = the folder this SETUP.md lives in.)

   After the upgrade copy, verify the preserved data is intact: `<workspace>/insights-hub/public/content/manifest.json` still parses and lists the user's services. If it doesn't, STOP and tell the user before proceeding.

   The ONLY exceptions: if the existing folder is not actually a hub install (no `public/content/manifest.json` and no `package.json` — e.g. an unrelated folder happens to have that name), or the user has explicitly asked for a factory reset, confirm with the user before doing anything destructive; a factory reset is `rm -rf "<workspace>/insights-hub"` followed by a fresh install (their generated content is deleted and only the seeded `spring-petclinic` sample remains).

2. Copy the app — **fresh installs only** (the folder does not exist yet); an upgrade already copied in step 1 (the package ships without `node_modules`):

   ```bash
   cp -R insights-hub "<workspace>/insights-hub"
   ```

3. Install dependencies:

   ```bash
   cd "<workspace>/insights-hub"
   npm install
   ```

   The app now ships with a small backend (`server/`) that serves `/content` and
   `/api`. `npm run dev` starts it automatically alongside Vite — the command and
   its `--port` flags are unchanged.

   **Configure the backend (optional for the seeded sample; required for runtime uploads).**
   The hub can register new projects at runtime — from a GitHub location or an
   uploaded doc set — recording them in a common **registry repo** on github.com so
   nothing needs a redeploy. Copy `.env.example` to `.env` and fill in:

   ```bash
   cd "<workspace>/insights-hub"
   cp -n .env.example .env   # never clobber an existing .env
   ```

   Then edit `.env`:
   - `REGISTRY_OWNER` / `REGISTRY_REPO` — the common repo that holds the registry
     `manifest.json` (the user already has this repo; ask them for owner + name).
   - `REGISTRY_BRANCH` — default `main`.
   - `GITHUB_TOKEN` — a token with **write (contents)** access to the registry repo
     and **read (contents)** access to any repo a project's docs are pointed at.

   If `.env` is absent or the registry is not configured, the hub still runs and
   serves the seeded `spring-petclinic` sample — only the "Add project" button is
   hidden. Never print or commit the token; `.env` is gitignored.

4. **Choose the port.** Default is `5173`. Check whether it is free:

   ```bash
   lsof -nP -iTCP:5173 -sTCP:LISTEN
   ```

   Exit code 0 means the port is **busy** (if `lsof` is unavailable, `curl -s -o /dev/null -m 2 http://localhost:5173/` succeeding also means busy). If busy, obtain a free port:

   ```bash
   node -e 'const s=require("net").createServer();s.listen(0,()=>{console.log(s.address().port);s.close()})'
   ```

   Call the chosen port `<PORT>`. **Use `<PORT>` in every URL in Steps 5 and 6.**

5. **Start the dev server in the background** (use your background-execution capability if you have one; otherwise `nohup … &`):

   ```bash
   cd "<workspace>/insights-hub"
   npm run dev -- --port <PORT> --strictPort
   ```

   nohup form, with a log file you can inspect if startup fails:

   ```bash
   nohup npm run dev -- --port <PORT> --strictPort > "${TMPDIR:-/tmp}/insights-hub-dev.log" 2>&1 &
   ```

   (`--strictPort` makes Vite fail loudly instead of silently hopping ports, so `<PORT>` is guaranteed accurate. If `<PORT>` is 5173 this is equivalent to plain `npm run dev`.)

---

## Step 5 — Verify the hub is up and complete

Perform ALL of the following checks yourself, with your own tools — 5.1–5.3 define the pass conditions, 5.4 tells you how to run them, 5.5 defines the report you must print.

**5.1 — App responds.** Poll the root URL until it returns HTTP 200, for at most ~60 seconds:

```bash
for i in $(seq 1 30); do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:<PORT>/")
  if [ "$code" = "200" ]; then echo "hub is up"; break; fi
  sleep 2
done
```

If it never returns 200, the verification is **FAIL** — inspect the dev-server log and report the error to the user.

**5.2 — Manifest is valid.**

```bash
curl -s "http://localhost:<PORT>/content/manifest.json"
```

The body must parse as JSON, have `schemaVersion` equal to `1`, and have a `services` array with **at least 1** entry.

**5.3 — Every page of every service exists.** For **every** service `s` in `services[]` and **every** stem `p` in that service's `pages[]` array, request:

```bash
curl -s -w "\n%{http_code}" "http://localhost:<PORT>/content/services/<s.id>/<p>.md"
```

A page counts as **OK** only if:

- HTTP status is 200, **and**
- the body does **NOT** start with `<!doctype` or `<html` (case-insensitive). If it does, the SPA fallback served `index.html` — the markdown file is **missing** even though the status was 200, **and**
- the page opens with the standard header block (a `# Title` heading followed by a `> Project:` line within the first few lines). A served page without that header block is a **FAIL** — it does not count toward "Pages OK".

**5.4 — Run the full check yourself.** You (the agent executing this file) perform checks 5.1–5.3 directly with your own tools — there is no script to copy. Do it in this order:

1. Poll `http://localhost:<PORT>/` per 5.1 until it returns 200 (max ~60 s). If it never does, the verdict is `OVERALL: FAIL` — read the dev-server log, report the error, and stop here.
2. Fetch `/content/manifest.json` per 5.2 and validate it (parses as JSON, `schemaVersion` = 1, `services` non-empty). Any violation is `OVERALL: FAIL` — report which condition failed and stop here.
3. From the manifest you just fetched, build the complete list of page URLs: every service `s` in `services[]` × every stem `p` in that service's `pages[]` → `/content/services/<s.id>/<p>.md`. Fetch **every one** — do not sample, do not stop at the first failure — and judge each against the three OK conditions in 5.3 (HTTP 200; body not the SPA HTML fallback; header block present). Keep two lists as you go: *missing* (non-200 or HTML fallback) and *no-header* (served markdown without the `> Project:` block).
4. Count per service: `Pages OK` = pages meeting all three conditions; `Pages expected` = length of that service's `pages[]`.

Rules for this step:
- Simple `curl` commands (one per page, checking status and the first ~200 bytes of the body) are entirely sufficient — a service typically has 9 or 10 pages.
- If you do prefer a helper script for a large manifest, create the file with your **file-writing tool**, never with a shell heredoc (`cat <<EOF`) — heredocs get mangled by some shells, and a corrupted verifier silently invalidates the whole verification.
- If any individual fetch errors, retry it once before counting it as missing.

**5.5 — Report to the user.** Show the verification report table exactly in this shape, followed by the overall verdict:

| Service | Pages expected | Pages OK | Status |
|---|---|---|---|
| spring-petclinic | 10 | 10 | PASS |

A service's Status is **PASS** only when `Pages OK` equals `Pages expected`. The verdict is `OVERALL: PASS` only when every service passes; otherwise `OVERALL: FAIL`. **On FAIL, list exactly which page files are missing and which are served but lack the `> Project:` header block** (the two lists you kept in 5.4) and suggest re-checking that the `insights-hub/public/content/` folder copied intact.

---

## Step 6 — Print next steps

Finish by printing the following to the user (with `<PORT>` and `<workspace>` filled in), plus your action summary from Steps 2–5:

1. **Your Insights Hub is running:** http://localhost:<PORT>/ — the dev server is running in the background (stop it by killing the process; restart later with `cd <workspace>/insights-hub && npm run dev`). The in-app **Help** link (top bar, or http://localhost:<PORT>/help) is a full user guide covering browsing and adding projects.
2. **Document your own projects** with the **insights-hub-generator** skill: give it a workspace path or a list of GitHub repo URLs (e.g. "Use the insights-hub-generator skill on /path/to/your/workspace"). Re-run it any time — it automatically picks up newly added projects and skips services that are already documented.

   **Or add a project at runtime — no redeploy.** If the backend is configured (Step 4.3), the catalog shows an **"+ Add project"** button. Two ways to publish: point at a doc set that already lives on GitHub (repo URL + docs path), or upload the generated `.md` files directly. Either way the project is recorded in the shared registry repo and appears for everyone immediately.
3. **Publish to Confluence** with the **insights-hub-confluence-publisher** skill. It requires the Atlassian MCP connector and walks you through authentication and space/parent-page configuration on first run.

Also mention: GitHub Copilot users have equivalent workflows in `<workspace>/.github/prompts/` — `generate-insights-hub.prompt.md` and `publish-confluence.prompt.md`.
