# Insights Hub Confluence Publisher Skill

Publish the Insights Hub documentation set to Confluence via the Atlassian MCP connector. Reads `insights-hub/public/content/manifest.json`, mirrors each documented service into an idempotent three-level Confluence page tree ("Insights Hub" parent → one page per service → one child page per section file), caches page ids in `confluence.json`, and by default publishes only services that changed since the last publish. Use when the user asks to publish, sync, push, or update service documentation, analysis docs, or the Insights Hub content to Confluence — supports a single service by id, `--all`, and `--dry-run`.

## When To Use

| Situation | Use this skill? |
|---|---|
| "Publish the petclinic docs to Confluence" | Yes — single-service mode |
| "Push all Insights Hub docs to Confluence" | Yes — `--all` |
| "Sync Confluence with the latest analysis" | Yes — default changed-only mode |
| "Show me what would be published, don't change anything" | Yes — `--dry-run` |
| Generating or re-analyzing service documentation | No — use `insights-hub-generator` |
| Browsing/rendering docs locally with diagrams | No — use the Insights Hub viewer (`npm run dev` in `insights-hub/`) |
| Publishing to Confluence without the MCP connector (raw REST) | No — use the Copilot prompt `publish-confluence.prompt.md` |

## Prerequisites

The **Atlassian MCP connector** must be attached to the session. Its tool names are **discovered at runtime** — do not hardcode tool names; different connector versions expose different surfaces (e.g. `createConfluencePage` vs `confluence_create_page`).

1. List the currently available MCP tools and filter for Atlassian/Confluence tools (search for `atlassian`, `confluence` in tool names). Record the exact names of the tools you will use for: search pages, get page, create page, update page.
2. If Atlassian tools are present but calls fail with an authorization error, run the connector's `authenticate` flow, complete it, and retry the tool listing.
3. If no Atlassian/Confluence tools are available at all, **abort** with clear guidance:
   - "The Atlassian MCP connector is not attached to this session. Attach it via claude.ai connector settings (or `claude mcp add` for a local MCP server), authenticate, then re-run `/insights-hub-confluence-publisher`."
   - Do NOT attempt to publish via raw REST calls — that is the Copilot prompt's fallback path, not this skill's.

Also verify the hub content exists: `<hub>/public/content/manifest.json` must parse as JSON with `schemaVersion: 1` and at least one service. If missing, abort and tell the user to run `/insights-hub-generator` first. `<hub>` defaults to `<workspace>/insights-hub`; accept `--hub <path>` to override.

## Configuration — `<hub>/confluence.json`

All publisher state lives in one file next to the hub app (git-ignorable, machine-local):

```json
{
  "siteUrl": "https://your-org.atlassian.net/wiki",
  "spaceKey": "ENG",
  "parentPageId": "123456",
  "parentPageTitle": "Insights Hub",
  "pageIds": {
    "spring-petclinic": "123457",
    "spring-petclinic/00-overview.md": "123457",
    "spring-petclinic/01-architecture.md": "123458"
  },
  "lastPublished": {
    "spring-petclinic": "2026-07-07T00:00:00Z"
  }
}
```

| Field | Meaning |
|---|---|
| `siteUrl` | Confluence site base URL — used to build page URLs in the report |
| `spaceKey` | Target space for all pages |
| `parentPageId` / `parentPageTitle` | The "Insights Hub" root page all service pages nest under |
| `pageIds` | **Cache only.** Keys are `"<service-id>"` (the service landing page) and `"<service-id>/<file>.md"` (section pages); values are Confluence page ids |
| `lastPublished` | ISO-8601 timestamp per service-id of the last successful publish — drives changed-only mode |

Rules:
- **First run (file absent):** ask the user for the space key and the parent page (title or URL). Offer to create a new "Insights Hub" page at the space root if none exists. Persist all choices to `confluence.json` immediately after they are confirmed/created.
- **First run + `--dry-run`:** do NOT prompt, persist config, or create any page. Print the planned tree using placeholder values (`spaceKey: <SPACE>`, parent: `Insights Hub <to be created>`), mark every page as **create**, and note that a real run will ask for configuration first.
- **`pageIds` is a cache, never authoritative.** If a cached id returns 404 (page deleted/moved), fall back to an exact-title lookup in the space, repair the cache entry with the found id, or treat as create if the title lookup also misses.
- **Preserve unknown/extra fields** in `confluence.json` (e.g. `spaceId` cached by the REST-based Copilot mirror `publish-confluence.prompt.md`) when updating the file — never drop fields this skill does not use.
- Write `confluence.json` back after every page operation succeeds, not only at the end — a crashed run must not lose ids already learned.

## Inputs & Modes

| Invocation | Behavior |
|---|---|
| `/insights-hub-confluence-publisher <service-id>` | Publish exactly one service by manifest `id` (e.g. `spring-petclinic`) |
| `/insights-hub-confluence-publisher` | **Changed-only (default):** publish every service whose manifest `analyzedAt` is strictly newer than its `lastPublished` entry (missing `lastPublished` counts as changed) |
| `/insights-hub-confluence-publisher --all` | Publish every service in the manifest regardless of timestamps |
| `... --dry-run` | Combinable with all of the above. Print the **full planned page tree** — every page with its resolved title, its parent, and whether it would be **create** or **update** (resolved via cache + title search, which are read-only). Make **NO write calls**: no create, no update, no config writes |

## Page Hierarchy

Three levels — one parent keeps the space root uncluttered, one page per service gives each service a stable landing URL, and one page per section keeps individual pages small enough to load and link directly:

```
Insights Hub                                (parentPageId)
├── Spring PetClinic                        (landing = 00-overview.md content)
│   ├── Spring PetClinic - 01 Architecture
│   ├── Spring PetClinic - 02 Entry Points
│   ├── ...
│   └── Spring PetClinic - 09 Deployment
└── Orders Frontend                         (React: generated summary, no 00-overview)
    ├── Orders Frontend - 01 Architecture
    └── ...
```

- **Service page (level 2):** title = manifest `name`. Body = the content of `00-overview.md`. React services have no `00-overview` (their `pages[]` starts at `01-architecture`) — for those, generate a short landing summary instead: the service name, its archetype, and a bullet list linking each section child page.
- **Section pages (level 3):** one per remaining file in `pages[]` (everything except `00-overview`). Title = `{name} - {NN Title}` using the page registry titles from `insights-hub-generator`'s SKILL.md — Spring and React have different stems (and titles) from `02` through `07`, so use the table matching this service's `stack`, never mix them. Example: `Spring PetClinic - 02 Entry Points` / `Orders Frontend - 02 Routing And Navigation`.
- Confluence page titles must be **unique per space** — the `{name} - ` prefix guarantees this across services. If a title collision with an unrelated existing page is detected, stop and ask the user rather than overwriting.

## Idempotent Publish Procedure

For each service in scope, in manifest order:

1. Read `<hub>/public/content/manifest.json`; resolve the service entry and its `pages[]` list. Read each `<hub>/public/content/services/<id>/<stem>.md`.
2. Resolve the root: confirm `parentPageId` still exists (cached id → 404 → title lookup for `parentPageTitle` in `spaceKey` → else offer to recreate).
3. Build the target page list: the service landing page + one section page per remaining stem, each with title, parent, and markdown body.
4. For each target page:
   a. Resolve id from `pageIds` cache; verify with a get-page call.
   b. On cache miss or 404: exact-title search in `spaceKey`.
   c. If found → **update** the page in place; if not found → **create** it under the correct parent (service page under `parentPageId`, section pages under the service page's id — so the service page must be published first).
   d. Record the resulting page id in `pageIds` and persist `confluence.json`.
5. After all of a service's pages succeed, set `lastPublished[<id>]` to the current UTC time and persist.
6. Move to the next service. A failed page or service is recorded and reported — it must **not** abort the run.

**Content format:** pass the markdown body directly to the MCP create/update tool — most Atlassian connector versions accept markdown. If the discovered tool requires Confluence storage format or ADF instead, convert headings, tables, and code fences accordingly, then **verify one page visually before bulk publishing**: publish a single page, print its URL, and ask the user to confirm it renders correctly (tables, code blocks, header blockquote) before continuing with the rest.

## Mermaid Handling

Doc pages contain ```` ```mermaid ```` fences (see `06-interactions.md`, `07-data-flow.md`). Confluence does not render Mermaid natively:

1. Publish Mermaid fences as ordinary code blocks, with the language hint `mermaid` where the target format supports one.
2. On diagram-heavy pages (any page containing at least one mermaid fence), prepend a single info line to the page body: *"Diagrams below are shown as Mermaid source — rendered diagrams are available in the Insights Hub viewer."*

Optional upgrades — documented here but **out of scope** for this skill:

| Upgrade | Notes |
|---|---|
| Org-installed Confluence Mermaid plugin | If the org's Confluence has a Mermaid macro/plugin, the published code blocks may render automatically with no changes here |
| Pre-render to PNG | Run `@mermaid-js/mermaid-cli` (`mmdc`) over each fence, attach the PNGs to the page, and replace fences with image references |

## Report

End every run with a summary table:

| Page | Action | URL |
|---|---|---|
| Spring PetClinic | updated | https://…/pages/123457 |
| Spring PetClinic - 01 Architecture | created | https://…/pages/123458 |
| Orders Frontend | skipped (unchanged) | https://…/pages/123470 |
| Orders Frontend - 04 Data Model | FAILED (403) | — |

- Actions: `created` / `updated` / `skipped (unchanged)` / `skipped (dry-run: would create)` / `skipped (dry-run: would update)` / `FAILED (<reason>)`.
- Build URLs from `siteUrl` + the id/webui link returned by the connector.
- Per-page failures are collected and listed here — they never abort the remaining pages or services. Close with totals: N created, N updated, N skipped, N failed, and (if any failed) the exact re-run command to retry just the affected services.

## Install Note

This folder is a standalone workspace skill (`SKILL.md` + `artifact.yaml`, no frontmatter). It is **not** installed into `~/.claude/skills/` here — installation happens later via the distribution package's `SETUP.md`, which prepends the required frontmatter at copy time.
