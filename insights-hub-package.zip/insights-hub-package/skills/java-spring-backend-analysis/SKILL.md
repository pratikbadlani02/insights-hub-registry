# Spring / Java Service Analysis Skill
 
Analyze a Spring Boot / Java backend service and generate a standardized documentation set (overview, architecture, entry points, business rules, data model, dependencies, interactions, data flow, error handling, deployment). Detects the service archetype (REST API, Kafka consumer, Spring Batch, or Spring Cloud Gateway) and tailors each section accordingly. Use when reverse-engineering or documenting Gradle/Maven Spring Boot services, Kafka listeners, batch jobs, or gateway routes — produces Mermaid diagrams, dependency/endpoint tables, and per-environment config from verified source code only.
 
## Tech Stack Alignment
 
Default backend alignment for this workspace:
- Build: Gradle (`build.gradle`) or Maven (`pom.xml`)
- Runtime: Spring Boot REST services, Kafka consumers, Spring Batch jobs
- Integration: Spring Cloud Gateway, Kafka listeners, downstream REST clients (RestTemplate)
- Platform: Actuator/Micrometer, profile-based config, LaunchDarkly feature flags
 
Detect the service archetype first — it determines which sections to emphasize:
- **REST API** — controllers are primary entry point; has JPA entities, database schema
- **Consumer** — `@KafkaListener` or manual `KafkaConsumer` is primary; no database; forwards to downstream REST API
- **Batch** — Spring Batch `Job`/`Step` is primary; has database, thread pools, ADLS output
- **Gateway** — Spring Cloud Gateway routes are primary; no business logic, no database
 
Service analysis rules:
- Record only verifiable claims from source code. Never fabricate enum values, topic names, env var names, or configuration values. If unclear, mark as `⚠️ UNVERIFIED`.
- For consumer-first services, the `@KafkaListener` (or manual `KafkaConsumer`) is the primary entry point — REST endpoints are limited to actuator/health.
- Capture all topic names, consumer groups, retry policies, and DLQ routing with exact property keys from `application.properties` / `application.yml`.
- For downstream REST URLs, always document the env var name that configures the base URL and list all environment endpoints (DEV, UAT, PREPROD, PROD).
- Do not fabricate country-specific or currency rules unless they exist in source code.
 
## Required Outputs
 
- `00-overview.md`
- `01-architecture.md`
- `02-entry-points.md`
- `03-business-rules.md`
- `04-data-model.md`
- `05-dependencies.md`
- `06-interactions.md`
- `07-data-flow.md`
- `08-error-handling.md`
- `09-deployment.md`
 
## Section Header Format
 
Every output file must open with this exact header block:
 
```markdown
# {Section Title}
 
> Project: {project-id}
> Type: {type-slug}
> Skill: spring-analysis
> Analyzed: {ISO-8601-timestamp}
 
---
```
 
Use plain `>` blockquotes (not bold). The Section Title must match: `Overview`, `Architecture`, `Entry Points`, `Business Rules`, `Data Model`, `Dependencies`, `Interactions`, `Data Flow`, `Error Handling`, `Deployment`.
 
## Mermaid Fence Rule
 
Always fence Mermaid blocks with **backtick** syntax (`` ```mermaid ``), never tilde syntax (`~~~mermaid`). The viewer's rehype/highlight.js renderer detects Mermaid via the `language-mermaid` className, which is only produced by backtick fences.
 
## Diagram Count Targets
 
- `01-architecture.md`: **minimum 2 diagrams** — (1) component model (`flowchart LR` for consumers/batch, `graph TB` for REST/gateway), (2) ecosystem position (`graph TB` showing external callers and downstream services)
- `06-interactions.md`: **minimum 2 diagrams** — all `sequenceDiagram` type showing inter-service communication with `participant`, `Note over`, `alt/else`, `loop` blocks
- `07-data-flow.md`: **minimum 3 diagrams** — all `flowchart TD` or `flowchart LR` type showing intra-service logic with decision nodes
- Other files (00, 02–05, 08–09): use tables and prose; add a diagram only where text cannot clearly convey structure
 
---
 
## Detailed Analysis Procedure
 
### A. Build & Architecture Analysis
 
1. Read build file (`build.gradle` or `pom.xml`):
   - Spring Boot version (from parent, BOM, or plugin)
   - Java version
   - All dependencies — group by category for the Dependency Categories section
 
2. Map package structure to Layer Organization:
   - Scan `src/main/java` for all packages
   - Map each package to its pattern and purpose
 
3. Identify the service archetype and key architectural patterns
 
**Output → `00-overview.md` + `01-architecture.md`**
 
### B. Entry Points
 
**For REST API services:**
1. Find all `@RestController` classes
2. Build 7-column HTTP endpoint table: `Method | Path | Auth | Request | Response | Handler | Description`
3. Group endpoints under H3 sub-headings by domain concern
4. Document Kafka published events if any
 
**For Consumer services:**
1. Find `@KafkaListener` annotation — document class, method, topic, group ID, container factory
2. Reproduce the full `@KafkaListener` annotation as a Java code block
3. Build operation routing table showing how each message type maps to an action
4. Document skip/filter conditions
5. Document outbound REST calls with path-only URLs + per-environment base URL table:
 
```markdown
Base URL is configured via `{env_var_name}`:
 
| Environment | Base URL |
|---|---|
| DEV | `https://{service}` |
| UAT | `https://{service}` |
| PREPROD | `https://{service}` |
| PROD | `https://{service}` |
```
 
6. Document outbound headers table: `sysId`, `appName`, `X-Correlation-Id`
7. List operational REST endpoints (actuator only — 3 rows: health, readiness, metrics)
 
**For Batch services:**
1. Document job trigger REST endpoints (start/stop)
2. Document Spring Batch job structure: Job → Steps (partitioned/sequential)
3. Document thread pool configuration table
 
**For Gateway services:**
1. Build route predicate table: `Route ID | HTTP Method | Path Pattern | Destination | Auth Required | Rate Limit`
2. Document gateway actuator endpoints
3. Document injected request headers
 
**Output → `02-entry-points.md`**
 
### C. Business Rules
 
1. Document entity lifecycle and state transitions using ASCII text diagrams:
   ```
   ACTIVE --[DELETE]--> DELETED
   DELETED --[REACTIVATE]--> ACTIVE
   ```
2. Document code/designation tables with columns for code, name, meaning
3. Document rule sets using **bold labels**: `**Rule Set N: {Name}**` followed by bullet list
4. Document feature toggles table: `Toggle Key | Default | Profiles | Effect`
5. Document event processing rules with H3 per event type
 
**Output → `03-business-rules.md`**
 
### D. Data Model
 
**For data-owning services (REST API, Batch):**
1. Document JPA entities as pseudo-Java in plain code fences (no language tag):
   ```
   @Entity
   @Table(name = "TABLE_NAME")
   public class EntityName {
     @Id Long id
     String fieldName  // description
   }
   ```
2. Build database schema table: `Table | Primary Key | Foreign Keys | Indexes`
3. Document DTOs as bullet lists or JSON examples
 
**For stateless services (Consumers):**
1. State explicitly: `**None.** This service is stateless — it does not own or persist any data.`
2. Document Kafka inbound payload models as pseudo-Java code blocks
3. Document outbound REST request models as pseudo-Java code blocks
4. Document outbound headers table
5. Document operational models (`ConsumerStatus`) if the service exposes health/status endpoints
 
**For Gateway:**
1. State explicitly: no data model
2. Document route configuration table showing all routes with inbound path, outbound target (DEV default), and filters
 
**Output → `04-data-model.md`**
 
### E. Dependencies
 
1. Build service call graph table: `From | To | Method | Protocol | Purpose`
2. Document data stores:
   - For data-owning services: H3 with database type → entity/table/queries table + connection pool details
   - For stateless services: state `**None.** This service has no database.`
3. Document Kafka integration:
   - Topics consumed table: `Topic | Property Key | Group ID | Cluster`
   - Topics published table if applicable
4. Document downstream REST clients table: `Client Class | Base URL (DEV) | Endpoints Called | Auth`
   - Add per-environment URL table below (DEV/UAT/PREPROD/PROD) with the env var name
5. Document Kafka SSL configuration table: keystore type, location, broker protocol
6. Document HTTP client configuration: library used (RestTemplate/WebClient/Feign)
 
**Output → `05-dependencies.md`**
 
### F. Interactions
 
Document primary domain flows as **pure Mermaid `sequenceDiagram` blocks** — no prose between diagrams. Each major flow gets its own H2 heading followed immediately by the mermaid block.
 
Use the full sequenceDiagram feature set: `participant` aliases, `Note over`, `alt/else`, `loop`, `par/and`, `-->>` for async returns.
 
Minimum 2 diagrams: happy-path flow + error/recovery flow.
 
**Output → `06-interactions.md`**
 
### G. Data Flow
 
Document intra-service logic flows as **pure Mermaid `flowchart` diagrams** (TD for vertical, LR for horizontal) — minimal prose. Each flow gets its own H2 heading.
 
Use decision nodes (`{condition}`) and labeled edges (`-->|label|`).
 
Minimum 3 diagrams: main data flow + error/recovery flow + additional detail flow.
 
**Output → `07-data-flow.md`**
 
### H. Error Handling
 
**For REST API services:**
1. HTTP status code tables split by H3: `### Success Codes`, `### Client Error Codes`, `### Server Error Codes`
2. Exception hierarchy as ASCII tree: `├──` and `└──` format
3. `@ControllerAdvice` handler as Java code block
4. `@Transactional` boundary documentation
 
**For Consumer services:**
1. Error categories table: `Error Condition | Handling Strategy` (2-column)
2. Kafka error handler configuration as Java code block:
   ```java
   new DefaultErrorHandler(
       new ConsumerRecordRecoverer(...),
       new FixedBackOff(interval, maxAttempts)
   );
   ```
3. FixedBackOff parameter table: `Parameter | Value | Config Key`
4. Consumer event listeners table: `Event | Purpose` listing `NonResponsiveConsumerEvent`, `ConsumerPausedEvent`, etc.
5. HTTP client error handling table: `Parameter | Value | Config Key` for connect/read/request timeouts and connection pool sizes
6. RestTemplate interceptor table if present
7. Error flow summary as ASCII text flow: `Message received → Deserialization → Service call → ... → DLQ`
 
**For Batch services:**
1. Thread pool error handling table: `Pool | Core | Max | Queue Capacity | Rejection Policy`
2. HikariCP pool configuration table
3. Database query timeout table
4. Resilience4j configuration if present
5. Kafka producer error configuration
 
**For Gateway services:**
1. Document as transparent pass-through: `**No custom error handling.** The gateway proxies upstream HTTP status codes directly.`
2. Timeout configuration table
3. Route error scenarios table: `Scenario | Gateway Behavior`
 
**Output → `08-error-handling.md`**
 
### I. Deployment
 
**For all services — Docker configuration table:**
```markdown
| Parameter | Value |
|-----------|-------|
| Base Image | `{registry}/{image}:{tag}` |
| Exposed Port | {port} |
| User | {user} (UID {uid}) |
| Volume | `/tmp` |
| Entry Point | `java` with `JAVA_OPTS` and `FW_OPTS` |
```
 
**For Consumer services:**
1. Environment variables table: `Variable | Default | Purpose` — list Kafka topic, group ID, SSL vars, downstream API hostname/URL, LDAP creds
2. Kafka consumer configuration table: `Parameter | Default | Config Key` — max poll records, fetch wait, concurrency, retry interval, retry count, partition assignment, isolation level
3. SSL/TLS configuration section
4. Actuator endpoints table
 
**For Batch services:**
1. Build/run command code blocks (`bash`)
2. Spring profiles table with profile differences: `Profile | Database | Kafka | Port`
3. Environment variables table with real values from Helm/properties
4. Database configuration section (DB type, HikariCP params)
5. Thread pool configuration table
6. External storage configuration (ADLS) if applicable
 
**For REST API services:**
1. Build/run command code blocks (`bash`)
2. Configuration by profile table
3. Environment variables table
4. Actuator endpoints table
5. Database migration section if applicable
6. K8s probe configuration (inline YAML blocks)
 
**For Gateway services:**
1. Docker configuration table
2. K8s notes (context path, graceful shutdown, probes)
3. Environment variables table with `Default (DEV)` column — note that defaults shown are DEV values, other environments override
4. HTTP client configuration table
5. Health check endpoints table
6. Application identity table: `appl_id`, `appl_na`, `appl_ver`, `service_name`
 
**Output → `09-deployment.md`**
 
---
 
## Per-File Checklists
 
**00-overview.md:**
- [ ] Executive Summary: prose with **bold** key terms describing the service purpose
- [ ] Core capabilities or event processing: table or bullet list
- [ ] Component count table: `| Component | Count |` — list controllers/listeners/services/repos/entities/config files
- [ ] For consumers: Consumer Group Details (topic, group ID, DLQ, concurrency, poll config, retry params)
 
**01-architecture.md:**
- [ ] Component model diagram — `flowchart LR` for consumers/batch showing message flow; `graph TB` for REST/gateway
- [ ] Ecosystem position diagram — `graph TB` showing where this service sits among upstream and downstream services
- [ ] Build Profile table: `Property | Value` — Spring Boot version, Java version, build tool, database, message broker, internal framework version
- [ ] Dependency Categories: **bold category names** followed by bullet list of dependency artifacts
- [ ] Layer Organization table: `Package | Pattern | Purpose` — one row per Java package with exact package names
- [ ] Notes section with key observations about the service (listener base class, payload type, port config, etc.)
- [ ] **Minimum 2 Mermaid diagrams**
 
**02-entry-points.md:**
- [ ] Primary entry point documentation (REST table, Kafka listener table, or route predicate table depending on archetype)
- [ ] For consumers: operation routing table, skip conditions, outbound REST calls with per-environment URL table, outbound headers
- [ ] For REST APIs: 7-column endpoint table grouped by H3 domain concerns
- [ ] Actuator/health endpoints (short table)
 
**03-business-rules.md:**
- [ ] State lifecycle with ASCII transition diagrams (if applicable)
- [ ] Code/designation tables
- [ ] Rule sets as **bold labels** + bullet lists
- [ ] Feature toggle table (if present)
- [ ] Event processing rules with per-event H3 sections
 
**04-data-model.md:**
- [ ] Core Entities (JPA) section — entities as pseudo-Java or `**None.**` for stateless services
- [ ] Kafka payload models (inbound) for consumers — pseudo-Java code blocks
- [ ] REST API models (outbound) for consumers — pseudo-Java code blocks
- [ ] Database schema table for data-owning services
- [ ] Outbound headers table
- [ ] Operational models (`ConsumerStatus`, `KafkaMessage`) if present
 
**05-dependencies.md:**
- [ ] Service call graph table
- [ ] Data stores section — database details or `**None.**` for stateless
- [ ] Kafka integration — topics consumed/published tables with cluster info
- [ ] Downstream REST clients table with `Base URL (DEV)` column
- [ ] Per-environment URL table (DEV/UAT/PREPROD/PROD) with env var name
- [ ] Kafka SSL configuration table
- [ ] HTTP client library noted
 
**06-interactions.md:**
- [ ] Pure Mermaid `sequenceDiagram` blocks — zero prose between diagrams
- [ ] Each major flow as its own H2 + mermaid block
- [ ] Use `participant`, `Note over`, `alt/else`, `loop`, `par/and` features
- [ ] **Minimum 2 sequence diagrams**
 
**07-data-flow.md:**
- [ ] Pure Mermaid `flowchart TD` or `flowchart LR` blocks
- [ ] Decision nodes and labeled edges
- [ ] Each flow as its own H2 + mermaid block
- [ ] **Minimum 3 flowchart diagrams**
 
**08-error-handling.md:**
- [ ] Service-archetype-appropriate error handling (see procedure H above)
- [ ] For consumers: DefaultErrorHandler code block + FixedBackOff table + consumer event listener table + HTTP client table + error flow ASCII summary
- [ ] For REST APIs: HTTP status tables + exception hierarchy ASCII tree + `@ControllerAdvice` Java code + transactional boundaries
- [ ] For batch: thread pool tables + HikariCP tables + Resilience4j config
- [ ] For gateway: transparent pass-through + timeout table + route error scenarios
 
**09-deployment.md:**
- [ ] Docker configuration table (base image, port, user, entry point)
- [ ] Environment variables table with values from source — never fabricate env var names
- [ ] Service-archetype-appropriate sections (see procedure I above)
- [ ] Actuator/health endpoints table
 
---
 
## Gateway-Specific Additions
 
For `type: gateway` (Spring Cloud Gateway):
 
1. Read `application.yml` routes block completely
2. For each route: predicates (Path, Method, Header), filters (StripPrefix, PrefixPath, AddHeader), target URI
3. Document that all target URLs are DEV defaults and configurable per environment via env vars
4. Document that the gateway performs **no authentication** itself — auth is delegated to downstream services or Nginx
5. No custom `GatewayFilter` beans unless found in source — document only built-in filters used
 