
# React / Frontend Analysis Skill

Produce a standardized, table-first documentation set for any React frontend so output is consistent and comparable across teams.

## When To Use

| Trigger | In scope |
|---|---|
| Document an existing React SPA (`react-app`, Vite/Webpack/CRA) | Yes |
| Document a Module Federation micro-frontend (`react-mfe`, host/remote) | Yes |
| Map routes, API boundaries, state, data-fetching, deployment | Yes |
| Greenfield/new-build design, or non-React frontends | No |

## Global Conventions

| Rule | Requirement |
|---|---|
| Evidence | Every fact cites a file path (and line where useful). No claim without a source. |
| Unverified | Anything inferred or unconfirmed is prefixed `⚠️ UNVERIFIED`. Never invent. |
| TS vs JS | TS-only steps (`tsconfig`, interfaces) are skipped for JS apps; reconstruct shapes from usage and mark `⚠️` inferred. |
| Not applicable | If a section's feature is absent (e.g. no MFE, no Markdown), write a one-line **N/A — reason** instead of padding. |
| Output location | All docs into one folder, default `docs/frontend-analysis/`. Confirm if the repo has an existing docs convention. |
| Sizing | Small app (≲10 routes): concise docs, one diagram per file where it adds clarity. Large app: full diagram targets. Never pad. |
| Tables first | Prefer the defined table schemas below over prose. Use prose only for narrative that a table cannot express. |

## Required Outputs

| File | Purpose | Mandatory diagrams |
|---|---|---|
| `01-architecture.md` | Stack, build config, state/data layers, component tree | 2 (component architecture; system context) |
| `02-entry-points.md` | Bootstrap, route map, auth gating, deep-linking | 0 (tables) |
| `03-business-rules.md` | Flags, auth/authz, scoping, validation, real-time rules | 0 (tables) |
| `04-data-model.md` | Store shape, DTOs, client vs server state | 0 (tables) |
| `05-dependencies.md` | Runtime/dev deps, router/HTTP/state/MFE wiring | 0 (tables) |
| `06-interactions.md` | Lifecycle and interaction sequences | 2 (happy path; error/recovery) |
| `07-data-flow.md` | End-to-end data movement | 3 (main flow; error flow; routing/transform) |
| `08-error-handling.md` | Network/HTTP/boundary/validation handling | 0 (tables) |
| `09-deployment.md` | Dev/build/preview, hosting, env, CI/CD | 0 (tables) |

Diagrams use Mermaid in ` ```mermaid ` fences. Minimums relax for small apps (see Sizing).

## Analysis Procedure

Work top to bottom; each step feeds specific output files.

| # | Step | Read | Capture | Feeds |
|---|---|---|---|---|
| 1 | Build & runtime | `package.json`, `vite.config.*`/`webpack.*`, `tsconfig.json`/`jsconfig.json` | versions, scripts, port, base path, aliases, env prefix, chunking | 01, 05, 09 |
| 2 | Routing | `main.*`, `App.*`, router config | router type, layout/shell, route tree, guards, lazy boundaries | 02 |
| 3 | API boundary | `src/services/*`, `lib/api.*`, HTTP client | base URL, interceptors, endpoint catalog, auth header | 04, 05, 08 |
| 4 | State | store + context modules | store slices, selectors, actions, persistence, client vs server split | 03, 04 |
| 5 | Data fetching | query hooks / fetch callers | library, cache/invalidation, real-time (WS/poll/SSE), optimistic updates | 06, 07 |
| 6 | Errors | error boundary, request wrapper, forms | boundary scope, status→action map, validation, telemetry | 08 |
| 7 | Federation (if MFE) | federation plugin config | role, `remotes`/`exposes`, `shared` singletons | 05 |
| 8 | Deployment | Dockerfile, CI, host config, `.env*` | build output, serving model, env matrix, health check | 09 |

## Standard Table Schemas

Use these exact column sets so docs are comparable across applications. Add columns only when the codebase demands it; do not remove columns (use `—` or `N/A`).

### Route map (`02`)
| Route | Component | Access | Guard | Params | Data source | Loading strategy | Purpose |
|---|---|---|---|---|---|---|---|

`Access` = Public / Private / Admin. `Loading strategy` = loader / useEffect / store / static.

### API endpoint catalog (`04`/`05`)
| Method | Path | Caller (fn) | Request shape | Response shape | Auth | Notes |
|---|---|---|---|---|---|---|

### State store (`04`)
| Slice / key | Shape | Origin (server/client) | Updated by | Persisted to | Consumers |
|---|---|---|---|---|---|

### Context / client state (`04`)
| Context | Shape | Storage key | Cross-tab sync | Consumers |
|---|---|---|---|---|

### Dependencies (`05`)
| Package | Version | Role | Notes |
|---|---|---|---|

### Business rules (`03`)
| Rule | Behavior | Enforced where (file) | Scope (route/feature) |
|---|---|---|---|

### Error handling (`08`)
| Trigger | Condition | Handler | User-facing result | Source |
|---|---|---|---|---|

### HTTP status map (`08`)
| Status | Action | Source |
|---|---|---|

### Real-time events (`03`/`06`)
| Channel | Event / message type | Effect on state | Source |
|---|---|---|---|

### Deployment matrix (`09`)
| Stage | Command / mechanism | Output / target | Env vars | Notes |
|---|---|---|---|---|

### Module Federation map (`05`, MFE only)
| Role | Module name | Remote entry | Exposes | Consumes | Shared singletons |
|---|---|---|---|---|---|

## Conditional Modules

### Module Federation (only if a federation plugin is present)
Detect: `@module-federation/*`, `@originjs/vite-plugin-federation`, or Webpack `ModuleFederationPlugin`. Capture role (host/remote/both), `name`, `filename`, `remotes`, `exposes`, `shared` (singleton + version), runtime load strategy (static/dynamic import, Suspense/error-boundary fallback), and shared-context propagation (auth/theme/store). Record in the Federation map. If absent: `N/A — no Module Federation`.

### Markdown / Mermaid rendering (only if the app renders content Markdown)
Detect: `react-markdown`, `remark-*`, `rehype-*`, `mermaid`. Capture renderer, remark/rehype plugins, sanitization (DOMPurify), and Mermaid init/theme. Most apps (dashboards, CRUD, trading UIs) do not render content Markdown — then: `N/A — no content Markdown pipeline`.

## Per-File Acceptance Criteria

A file is complete when every applicable row is filled with a cited source and gaps are marked `⚠️ UNVERIFIED` or `N/A`.

| File | Must contain |
|---|---|
| `01` | Stack/versions table; build-config table; state+data-layer summary; component-tree diagram; system-context diagram |
| `02` | Bootstrap sequence; full route-map table; auth-gating rule; deep-link/param handling; external entry points or N/A |
| `03` | Business-rules table; auth/authz scheme; scoping/multi-tenant; validation approach; real-time-events table; feature flags or N/A |
| `04` | State-store table; context table; API endpoint catalog; client-vs-server-state split; DTOs (typed or `⚠️` inferred) |
| `05` | Dependencies table; router/HTTP/state wiring; MFE map or N/A; dev ports/proxy; testing/lint tooling or note of absence |
| `06` | Page-lifecycle description; happy-path sequence diagram; error/recovery sequence diagram; real-time sync path or N/A |
| `07` | Main data-flow diagram; error/recovery diagram; routing/transform diagram; mutation flow; optimistic behavior or note of absence |
| `08` | HTTP status map; error-handling table; error-boundary scope; validation handling; telemetry or note of absence |
| `09` | Deployment matrix; serving model (CDN/static/server); env-var matrix; Docker/K8s if present; health check/smoke test |