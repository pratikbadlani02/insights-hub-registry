# Insights Hub Generator Skill

Batch-document an entire workspace into the Insights Hub: discover every Spring Boot and React project (from a local directory or a list of GitHub repo URLs), delegate each one to the matching analysis skill, and publish the resulting doc sets into `insights-hub/public/content/` with an up-to-date `manifest.json`. Re-run it whenever the workspace changes — new projects are detected by manifest membership and only they get analyzed. Use when documenting many services at once, keeping the hub in sync with a growing workspace, or importing services that already carry a complete analysis doc set.

## When To Use

| Trigger | Action |
|---|---|
| Batch-document a workspace (or repo list) into the Insights Hub | Yes — this skill |
| Analyze a single Spring Boot service, no hub involved | No — use `spring-boot-service-analysis` (workspace folder `java-spring-backend-analysis/`) directly |
| Analyze a single React app, no hub involved | No — use `react-frontend-analysis` directly |
| Non-Java / non-React projects in the workspace | Skipped and reported with a reason — never analyzed |

## Inputs

| Mode | Invocation | Input |
|---|---|---|
| A — local workspace | `/insights-hub-generator ./workspace` | Path to a directory containing project folders |
| B — GitHub repos | `/insights-hub-generator https://github.com/org/repo1 https://github.com/org/repo2` | One or more GitHub repo URLs |

| Flag | Effect |
|---|---|
| `--force` | Re-analyze and re-publish ALL discovered projects, including EXISTING ones |
| `--force <id>` | Re-analyze and re-publish only the service with that manifest `id` |
| `--prune` | Delete published docs + manifest entries for STALE services (see detection table) |
| `--hub <path>` | Location of the hub app; default `<workspace>/insights-hub` |

## Repo Acquisition (Mode B)

In Mode B there is no input directory, so `<workspace>` = the current working directory where the skill is invoked: clones go to `<cwd>/.insights-hub-sources/<repo-name>/` and the default `--hub` is `<cwd>/insights-hub`.

1. Clone each URL into `<workspace>/.insights-hub-sources/<repo-name>/`.
2. If the clone already exists (re-run): `git fetch && git reset --hard origin/HEAD` before analyzing — never merge, never keep local edits.
3. From here on, treat each clone directory exactly like a Mode A project. Record `source.type: "git"` and the original URL as `source.repoUrl` in the manifest entry.

## Discovery & Stack Detection

Scan the input directory at the top level AND one level deep (monorepo support). For each candidate folder, apply the first matching row:

| Marker found in folder | Stack | Delegate skill |
|---|---|---|
| `pom.xml` or `build.gradle` / `build.gradle.kts` containing `org.springframework.boot` | `java-spring` | `spring-boot-service-analysis` |
| `package.json` with a `react` dependency | `react` | `react-frontend-analysis` |
| Neither marker | — | Skip and report with reason `no supported stack marker` |

Monorepo rule: a folder whose subtree matches BOTH markers yields two services — `<name>-backend` (the Spring module) and `<name>-frontend` (the React module).

React archetype derivation: `react-mfe` if a Module Federation plugin is present — a `@module-federation/*` dependency, `@originjs/vite-plugin-federation`, or webpack's `ModuleFederationPlugin` in the build config — otherwise `react-spa`.

Ignore during discovery (never analyze, never report as skipped-project noise — list them once under "ignored"):

| Ignored | How to recognize |
|---|---|
| Hidden directories | Name starts with `.` |
| Archives | `.zip` and other archive files |
| Skill folders | Root contains `SKILL.md` / `artifact.yaml` but NO build markers |
| The hub itself | The `--hub` path (default `<workspace>/insights-hub`) |
| Hub copies | Any directory that itself looks like a hub copy — it contains `public/content/manifest.json` (e.g. a packaged `insights-hub-package/insights-hub`) — even if it also matches a stack marker |
| Dependency & build output dirs | `node_modules/` and build output directories (`dist/`, `build/`, `target/`, etc.) |

## New-Project Detection — Manifest Membership ONLY

Detection is manifest membership and nothing else: **no commit hashes, no mtime tracking**. The user simply re-runs this skill to pick up newly added projects. Read `<hub>/public/content/manifest.json` first (treat a missing manifest as zero services), then classify every discovered project:

| State | Definition | Action |
|---|---|---|
| NEW | Discovered `id` not in `services[]` | Analyze (or import — see shortcut) + publish |
| EXISTING | `id` already in `services[]` | Skip + report. Re-generate only via `--force` or `--force <id>` |
| STALE | In `services[]` but source path/clone no longer exists | Report. Delete its docs folder + manifest entry ONLY with `--prune` |

Id derivation: if the project's docs already carry a header block, use the header's `Project:` value; otherwise kebab-case the project folder/repo name. Ids are URL-safe kebab-case.

**Reuse shortcut:** a NEW project that already contains a complete, valid doc set in the delegate's default output folder — every expected file for its stack present (Spring: 10 files `00-overview.md`…`09-deployment.md` in `docs/backend-analysis/`, each opening with a valid header block; React: 9 files `01-architecture.md`…`09-deployment.md` in `docs/frontend-analysis/`) — is IMPORTED (published as-is, headers normalized on the copies) instead of re-analyzed. Report it as `imported`.

## Delegation

**Do NOT restate analysis logic in any form.** Locate the delegate SKILL.md for the detected stack and follow it verbatim — its procedure, table schemas, diagram minimums, and evidence rules are authoritative.

Lookup order (first hit wins):

| # | Location | java-spring | react |
|---|---|---|---|
| 1 | Installed skill by slug | `spring-boot-service-analysis` | `react-frontend-analysis` |
| 2 | Sibling workspace folder | `java-spring-backend-analysis/SKILL.md` | `react-frontend-analysis/SKILL.md` |
| 3 | User skills dir | `~/.claude/skills/spring-boot-service-analysis/SKILL.md` | `~/.claude/skills/react-frontend-analysis/SKILL.md` |

Let each delegate write to its default in-repo output location — `docs/backend-analysis/` (Spring, 10 files) or `docs/frontend-analysis/` (React, 9 files, no `00-overview`). Do not redirect delegate output.

## Publish

For each analyzed or imported project:

1. Copy the generated `.md` files to `<hub>/public/content/services/<id>/`.
2. **Normalize headers ON THE COPIES ONLY.** Spring output already opens with the header block — verify it. React output has NO header block per its skill spec — inject this exact 4-line block at the top of each copied file (after the `# {Section Title}` line if present, otherwise add the title from the page registry too):

   ```markdown
   # {Section Title}

   > Project: {id}
   > Type: {react-spa|react-mfe}
   > Skill: react-analysis
   > Analyzed: {ISO-8601}

   ---
   ```

   Never write headers into the source project's `docs/` output, and never edit the analysis skills to make them emit headers.

   Page registries (stem → Section Title — used for header titles and by the viewer's navigation). **The two stacks use different stems from `02` through `07` — always use the table matching the service's `stack`, never mix them:**

   Spring page registry (10 stems):

   | Stem | Section Title |
   |---|---|
   | `00-overview` | Overview |
   | `01-architecture` | Architecture |
   | `02-entry-points` | Entry Points |
   | `03-business-rules` | Business Rules |
   | `04-data-model` | Data Model |
   | `05-dependencies` | Dependencies |
   | `06-interactions` | Interactions |
   | `07-data-flow` | Data Flow |
   | `08-error-handling` | Error Handling |
   | `09-deployment` | Deployment |

   React page registry (9 stems, no `00-overview` — matches `react-frontend-analysis`'s actual filenames):

   | Stem | Section Title |
   |---|---|
   | `01-architecture` | Architecture |
   | `02-routing-and-navigation` | Routing And Navigation |
   | `03-access-and-rules` | Access And Rules |
   | `04-data-model` | Data Model |
   | `05-dependencies` | Dependencies |
   | `06-runtime-flows` | Runtime Flows |
   | `07-state-and-data-fetching` | State And Data Fetching |
   | `08-error-handling` | Error Handling |
   | `09-deployment` | Deployment |

3. **Lint Mermaid on the copies.** Mermaid rejects node labels containing `{}`, `()`, or `|` unless the label text is wrapped in double quotes. On each copy, wrap any offending square-bracket node label in quotes (`A[POST /owners/{id}/edit]` → `A["POST /owners/{id}/edit"]`). Quote label text only — never alter diagram structure, node ids, or edge definitions, and never edit the source project's originals.
4. Upsert the project's entry in the manifest. Full schema (`<hub>/public/content/manifest.json`, `schemaVersion` 1):

   ```json
   {
     "schemaVersion": 1,
     "generatedAt": "2026-07-07T15:30:00Z",
     "generator": "insights-hub-generator@1.0.0",
     "services": [
       {
         "id": "spring-petclinic",
         "name": "Spring PetClinic",
         "stack": "java-spring",
         "archetype": "rest-api",
         "skill": "spring-analysis",
         "analyzedAt": "2026-06-28T00:00:00Z",
         "pages": ["00-overview", "01-architecture", "02-entry-points", "03-business-rules",
                   "04-data-model", "05-dependencies", "06-interactions", "07-data-flow",
                   "08-error-handling", "09-deployment"],
         "tags": ["team-a", "tier-1"],
         "source": {
           "type": "local",
           "path": "/Users/pbadlani/workspace/sample-petclinic",
           "repoUrl": null
         }
       }
     ]
   }
   ```

   Field rules:

   | Field | Rule |
   |---|---|
   | `id` | URL-safe kebab-case slug; MUST equal the folder name under `public/content/services/<id>/`. When importing docs that carry a header block, use the header's `Project:` value; otherwise kebab-cased project folder/repo name |
   | `name` | Human display name |
   | `stack` | `"java-spring"` \| `"react"` |
   | `archetype` | `"rest-api"` \| `"kafka-consumer"` \| `"batch"` \| `"gateway"` \| `"react-spa"` \| `"react-mfe"` |
   | `skill` | `"spring-analysis"` \| `"react-analysis"` — matches the `> Skill:` header value |
   | `analyzedAt` | ISO-8601 UTC. Provenance: fresh analysis → current UTC time at publish; import of an existing doc set → the header block's `Analyzed:` value (fall back to current UTC if absent). This value drives the Confluence publisher's changed-only mode — never backdate it |
   | `pages` | File stems (no `.md`) actually present on disk, in numeric order. Spring services have 10 (`00-overview` … `09-deployment`); React services have 9 (`01-architecture` … `09-deployment`, NO `00-overview`). Never write stems for files that do not exist |
   | `tags` | Optional array of free-form labels (team, domain, tier, …). Never derived from source code — hub-curated only, normally set via the hub's Edit-project UI. **When re-analyzing/re-publishing an EXISTING service (`--force`), carry its current `tags` forward unchanged** — analysis has no way to produce them, so overwriting with `[]` would silently erase a user's curation. Omit (or `[]`) only for a brand-new service |
   | `source.type` | `"local"` \| `"git"`; `path` = absolute local path (or clone path), `repoUrl` = GitHub URL or `null` |

5. Write `manifest.json` **atomically**: write the full document to a temp file in the same directory, then `mv` it over `manifest.json`. Never edit the live file in place.

## Validate & Report

After publishing, before reporting success:

| Check | Pass condition |
|---|---|
| Pages exist | Every stem in every service's `pages[]` exists as `<hub>/public/content/services/<id>/<stem>.md` |
| Headers valid | Every published page opens with the `# Title` + `> Project/Type/Skill/Analyzed` + `---` block |
| Manifest parses | `manifest.json` is valid JSON with `schemaVersion` 1 |

End every run with a summary table:

| Status | Count | Services |
|---|---|---|
| analyzed | | |
| imported | | |
| skipped (reason) | | |
| stale | | |
| failed | | |

One project's failure must NOT abort the run — record it as `failed` with the error, and continue with the remaining projects. Large workspaces: process projects sequentially, or delegate each project's analysis to a subagent to preserve context.

## Rules

- Treat source projects as read-only, EXCEPT the delegate skill's own docs output folder (`docs/backend-analysis/` / `docs/frontend-analysis/`).
- Never modify the two analysis skills (`java-spring-backend-analysis/`, `react-frontend-analysis/`) — not their SKILL.md, not their artifact.yaml.
- Preserve backtick ```` ```mermaid ```` fences exactly when copying — never convert to tilde fences; the viewer detects diagrams via the `language-mermaid` className produced by backtick fences only.
- Service ids are kebab-case and must equal the content folder name under `public/content/services/<id>/`.
